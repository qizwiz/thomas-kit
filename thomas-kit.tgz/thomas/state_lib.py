#!/usr/bin/env python3
""

from __future__ import annotations

import json
import os
import sys
import tempfile
from typing import Any, NamedTuple


class State(NamedTuple):
    status: str  # "absent" | "corrupt" | "ok" (redis_get adds "error")
    value: Any = None
    error: str | None = None  # "TypeName: msg" when corrupt/error


class CorruptState(Exception):
    ""


class AmbiguousFormat(CorruptState):
    ""


def _err(e):
    return f"{type(e).__name__}: {e}"


def read_state(path, parse=json.loads):
    ""
    try:
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
    except FileNotFoundError:
        return State("absent")
    except (OSError, UnicodeDecodeError) as e:
        return State("corrupt", None, _err(e))
    try:
        return State("ok", parse(text))
    except Exception as e:  # noqa: BLE001 -- any parser failure is "corrupt", with its text kept
        return State("corrupt", None, _err(e))


def read_lines(path, parse=json.loads):
    ""
    rows, bad = [], []
    try:
        with open(path, encoding="utf-8") as fh:
            for i, line in enumerate(fh, 1):
                if not line.strip():
                    continue
                try:
                    rows.append(parse(line))
                except Exception:  # noqa: BLE001 -- reported in `bad`, not dropped
                    bad.append(i)  # the line number goes to the caller in `bad`
    except FileNotFoundError:
        pass  # an absent file is ([], []) by this function's contract
    return rows, bad


def _bare_scalar(text):
    ""
    try:
        return not isinstance(json.loads(text), (dict, list))
    except ValueError:  # not JSON at all is not a bare JSON scalar (the answer is False)
        return False


def _parser_for(dump, text, value=None):
    ""
    if dump is json.dumps:
        return json.loads
    try:
        return json.loads if isinstance(json.loads(text), (dict, list)) else str
    except ValueError:  # output that is not JSON is a text format: judged as text
        return str


def write_state_atomic(path, value, dump=json.dumps, force=False, parse=None):
    ""
    text = dump(value)  # before any file exists: a failing dump leaves nothing behind
    if not force:
        if parse is None and dump not in (json.dumps, str, repr) and _bare_scalar(text):
            if read_state(path, parse=json.loads).status == "corrupt":
                raise AmbiguousFormat(f"{path}: this dump wrote a bare scalar ({text[:24]!r}), which names no format, "
                                      "and the existing file is not JSON -- pass parse=str (text) or parse=json.loads")
            parse = json.loads
        parse = parse or _parser_for(dump, text, value)
        cur = read_state(path, parse=parse)
        if cur.status == "corrupt":
            raise CorruptState(f"{path}: {cur.error}")
    d = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".state-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:  # best-effort temp cleanup; the original error is re-raised below
            pass
        raise


def redis_get(r, key):
    ""
    try:
        v = r.get(key)
    except Exception as e:  # noqa: BLE001
        return State("error", None, _err(e))
    if v is None:
        return State("absent")
    if isinstance(v, (bytes, bytearray)):
        try:
            v = bytes(v).decode("utf-8")
        except UnicodeDecodeError as e:
            return State("corrupt", None, _err(e))
    return State("ok", v)


def selftest():
    n = f = 0

    def ck(name, fn, want):
        nonlocal n, f
        n += 1
        try:
            got = fn()
        except Exception as e:  # noqa: BLE001 -- a case that raises is a case that fails, with the error shown
            got = f"raised {type(e).__name__}: {e}"
        if got != want:
            f += 1
            print(f"  FAIL {name}  got={got!r} want={want!r}")

    class Boom:
        def get(self, key):
            raise ConnectionError("redis down")

    class Fake:
        def __init__(self, d):
            self.d = d

        def get(self, key):
            return self.d.get(key)

    def raises(exc, fn):
        try:
            fn()
        except exc:
            return True
        return False

    def raises_corrupt(fn):
        try:
            fn()
        except CorruptState:
            return True
        except Exception as e:  # noqa: BLE001
            return f"raised {type(e).__name__}"
        return False

    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "s.json")
        ck("absent file -> absent", lambda: read_state(p).status, "absent")
        ck("absent file has no error", lambda: read_state(p).error, None)
        with open(p, "w") as fh:
            fh.write("{not json")
        def s():
            return read_state(p)

        ck("garbage file -> corrupt", lambda: s().status, "corrupt")
        ck("corrupt error names the parse failure", lambda: s().error.startswith("JSONDecodeError: "), True)
        ck("corrupt value is None", lambda: s().value, None)
        ck("a directory at the path -> corrupt, not a raise", lambda: read_state(d).status, "corrupt")
        ck("write over a corrupt file is refused", lambda: raises_corrupt(lambda: write_state_atomic(p, {"a": 1})), True)
        ck("the refused write left the corrupt bytes alone", lambda: read_state(p, parse=str).value, "{not json")
        ck("force=True overwrites a corrupt file", lambda: (write_state_atomic(p, {"a": 1}, force=True),
                                                            read_state(p).value)[1], {"a": 1})
        ck("good file -> ok", lambda: read_state(p).status, "ok")
        ck("ok value is the parsed value", lambda: read_state(p).value, {"a": 1})
        ck("a falsy but valid value is ok, not absent", lambda: (write_state_atomic(p, {}), read_state(p))[1].status,
           "ok")
        ck("custom parse: a failing parser -> corrupt", lambda: read_state(p, parse=int).status, "corrupt")
        ck("write over an ok file needs no force", lambda: (write_state_atomic(p, [1, 2]), read_state(p).value)[1],
           [1, 2])
        q = os.path.join(d, "new.json")
        ck("write to an absent path creates it", lambda: (write_state_atomic(q, {"n": 2}), read_state(q).value)[1],
           {"n": 2})
        ck("atomic write leaves no temp file", lambda: sorted(os.listdir(d)), ["new.json", "s.json"])
        ck("a failing dump raises TypeError", lambda: raises(TypeError, lambda: write_state_atomic(q, object())), True)
        ck("... the old value survived the failed dump", lambda: read_state(q).value, {"n": 2})
        ck("... and no temp file remained", lambda: sorted(os.listdir(d)), ["new.json", "s.json"])

        j = os.path.join(d, "r.jsonl")
        with open(j, "w") as fh:
            fh.write('{"a": 1}\n{"a": 2}\n{"a": 3')
        ck("JSONL with a torn last line -> rows plus bad=[3]", lambda: read_lines(j), ([{"a": 1}, {"a": 2}], [3]))
        with open(j, "w") as fh:
            fh.write('{"a": 1}\n\nnope\n{"a": 2}\n')
        ck("JSONL: blank lines skipped, bad line numbered by file line", lambda: read_lines(j),
           ([{"a": 1}, {"a": 2}], [3]))
        ck("JSONL: absent file -> no rows, no bad", lambda: read_lines(os.path.join(d, "none.jsonl")), ([], []))

    ck("redis ConnectionError -> error status", lambda: redis_get(Boom(), "k").status, "error")
    ck("redis error text kept", lambda: redis_get(Boom(), "k").error, "ConnectionError: redis down")
    ck("redis missing key -> absent", lambda: redis_get(Fake({}), "k").status, "absent")
    ck("redis present key -> ok with value", lambda: (redis_get(Fake({"k": "v"}), "k").status,
                                                      redis_get(Fake({"k": "v"}), "k").value), ("ok", "v"))
    ck("redis bytes are decoded", lambda: redis_get(Fake({"k": b"v"}), "k").value, "v")
    ck("redis undecodable bytes -> corrupt", lambda: redis_get(Fake({"k": b"\xff\xfe"}), "k").status, "corrupt")

    def refused(existing, value, kw):  # kw positional: a table row is typed object, ** of it is not a mapping
        with tempfile.TemporaryDirectory() as td:
            tp = os.path.join(td, "t")
            with open(tp, "w") as fh:
                fh.write(existing)
            return raises_corrupt(lambda: write_state_atomic(tp, value, **kw))

    ind = lambda v: json.dumps(v, indent=2)
    txt = "host=alpha\nmode=fast\n"
    for name, existing, value, kw, want in [
        ("json.dumps dict over torn json", "{not json", {"a": 1}, {}, True),
        ("json.dumps scalar over torn json (near-miss)", "{not json", 42, {}, True),
        ("indent=2 json dump over torn json", "{not json", {"a": 1}, {"dump": ind}, True),
        ("indent=2 json dump of a list over torn json", "[1,", [1], {"dump": ind}, True),
        ("text dump str(42) over healthy text: a bare scalar is no evidence of JSON", txt, 42, {"dump": str}, False),
        ("text dump of a non-JSON string over healthy text", txt, "x", {"dump": str}, False),
        ("text dump of a dict repr over healthy text", txt, {"a": 1}, {"dump": str}, False),
        ("text dump str([1]) is JSON by accident: judged as JSON, so a refusal, never a lost file", txt, [1],
         {"dump": str}, True),
        ("... and parse=str says it is text", txt, [1], {"dump": str, "parse": str}, False),
        ("explicit parse=json.loads beats the dump's shape", txt, 42, {"dump": str, "parse": json.loads}, True),
        ("explicit parse=str accepts anything", "{not json", {"a": 1}, {"parse": str}, False),
        ("json.dumps over healthy json", '{"a": 1}', {"b": 2}, {}, False),
        ("force over torn json", "{not json", 42, {"force": True}, False),
        ("custom bare-scalar dump over a non-JSON file: AmbiguousFormat, refused", "[core]\nmode=fast\n", 42,
         {"dump": lambda v: f"{v:d}"}, True),
        ("... and parse=str declares it text", "[core]\nmode=fast\n", 42, {"dump": lambda v: f"{v:d}", "parse": str},
         False),
    ]:
        ck("corruption judged in the file's format: " + name, lambda e=existing, v=value, k=kw: refused(e, v, k), want)

    def ambiguous_message():
        with tempfile.TemporaryDirectory() as td:
            tp = os.path.join(td, "t")
            with open(tp, "w") as fh:
                fh.write("[core]\n")
            try:
                write_state_atomic(tp, 7, dump=lambda v: f"{v:d}")
            except AmbiguousFormat as e:
                return "parse=str" in str(e) and "parse=json.loads" in str(e)
            return False
    ck("the ambiguous refusal names both fixes", ambiguous_message, True)

    print(f"state_lib --selftest RESULT: {'PASS' if f == 0 else 'FAIL'} -- {n - f}/{n} cases")
    return 1 if f else 0


if __name__ == "__main__":
    sys.exit(selftest() if "--selftest" in sys.argv[1:] else 0)
