#!/usr/bin/env python3
""
import os
import sys

KINDS = ("bug", "idea")
FIELDS = ("kind", "thomas-version", "what", "repro", "expected", "got", "test")
REQUIRED = {"bug": ("kind", "what", "repro", "expected", "got"), "idea": ("kind", "what")}
CAP = {"what": 2000, "repro": 4000, "expected": 1000, "got": 4000, "test": 8000, "thomas-version": 64, "kind": 8}
FENCE = "```sexpr"


def _q(s):
    ""
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def build(fields):
    ""
    parts = ["report"]
    for k in FIELDS:
        if fields.get(k) in (None, ""):
            continue
        parts.append(":" + k)
        parts.append(fields[k] if k == "kind" else _q(fields[k]))
    return "(" + " ".join(parts) + ")"


def parse(body, read_typed=None):
    ""
    if read_typed is None:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import sexpr_lib
        read_typed = sexpr_lib.read_typed
    start = (body or "").find(FENCE)
    if start < 0:
        return None
    form, end = None, body.find("```", start + len(FENCE))
    while True:
        try:
            form = read_typed(body[start + len(FENCE):end if end >= 0 else len(body)].strip())
            if isinstance(form, list) and not all(str(k).startswith(":") for k in form[1::2]):
                raise ValueError("a report form's keys are :keywords")
            break
        except (ValueError, IndexError):
            if end < 0:
                return None
            end = body.find("```", end + 3)
    if not isinstance(form, list) or not form or form[0] != "report" or len(form) % 2 != 1:
        return None
    out = {}
    for k, v in zip(form[1::2], form[2::2]):
        key = str(k)[1:] if str(k).startswith(":") else ""
        if key in FIELDS:
            out[key] = str(v)
    return out


def problems(fields, holds_secret=None):
    ""
    if holds_secret is None:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import key_shapes_lib
        holds_secret = key_shapes_lib.has_secret_value
    out = []
    kind = fields.get("kind", "")
    if kind not in KINDS:
        out.append(f"kind must be one of {', '.join(KINDS)}, got {kind!r}")
        return out
    out += [f"missing :{k}" for k in REQUIRED[kind] if not str(fields.get(k, "")).strip()]
    out += [f":{k} is over {CAP[k]} characters" for k in FIELDS if len(str(fields.get(k, ""))) > CAP[k]]
    out += [f":{k} holds something shaped like a credential -- remove it before filing"
            for k in FIELDS if fields.get(k) and holds_secret(str(fields[k]))]
    return out


_HOMES = ("/Us" + "ers/", "/home/")  # the macOS prefix is written in two pieces, so this file's own text holds no home path
_ROOT = "/root"  # the root account's home: no NAME follows it
_NAME_CHARS = "._-"
_NAME_TAIL = ".,;:!?)]}>\"'"  # sentence punctuation and closers ending a run: they are not part of a name
_MAIL_STOP = "()[]{}<>'\"`,;:\u2018\u2019\u201c\u201d"  # brackets, quotes, commas, semicolons, colons end an address
_MAIL_TAIL = ".!?-"  # a trailing dot, dash, bang or question mark is the sentence's, not the address's
_FILE_URL = "file://"  # a path after it starts at the third slash, which the prefix's own slash is


def _is_word(c, extra):
    return c.isalnum() or c in extra


def _scrub_emails(text):
    ""
    out, n, i = [], 0, 0
    while i < len(text):
        at = text.find("@", i)
        if at < 0:
            break
        lo = at
        while lo > i and not (text[lo - 1].isspace() or text[lo - 1] in _MAIL_STOP):
            lo -= 1
        hi = at + 1
        while hi < len(text) and not (text[hi].isspace() or text[hi] in _MAIL_STOP):
            hi += 1
        while hi > at + 1 and text[hi - 1] in _MAIL_TAIL:
            hi -= 1
        if lo == at or "." not in text[at + 1 : hi]:
            out.append(text[i : at + 1])
            i = at + 1
            continue
        if lo > i and text[lo - 1] == "<" and text[hi : hi + 1] == ">":
            lo, hi = lo - 1, hi + 1
        out.append(text[i:lo] + "<email>")
        n += 1
        i = hi
    return "".join(out) + text[i:], n


def _scrub_paths(text):
    ""
    out, n, i = [], 0, 0
    while i < len(text):
        hits = [(k, p) for p in _HOMES + (_ROOT,) for k in [text.find(p, i)] if k >= 0]
        if not hits:
            break
        k, p = min(hits)
        j = k + len(p)
        if p == _ROOT:
            while j < len(text) and _is_word(text[j], _NAME_CHARS):
                j += 1
            while j > k + len(p) and text[j - 1] in _NAME_CHARS and not (text[j - 1].isalnum() or text[j - 1] == "_"):
                j -= 1  # a trailing dot or dash belongs to the sentence
            d = k + len(p)  # dots straight after it are the sentence's; the character after them decides
            while d < len(text) and text[d] == ".":
                d += 1
            j = k + len(p) if j == k + len(p) and (d >= len(text) or text[d] not in _NAME_CHARS + "_") else -1
        else:
            while j < len(text) and not text[j].isspace() and text[j] != "/":
                j += 1
            while j > k + len(p) and text[j - 1] in _NAME_TAIL:
                j -= 1
        after_file_url = text[max(k - len(_FILE_URL), 0) : k].lower() == _FILE_URL
        path_before = bool(k) and not after_file_url and (text[k - 1].isalnum() or text[k - 1] in "_-./")
        if j == k + len(p) and p != _ROOT or j < 0 or (p == _ROOT and path_before):
            out.append(text[i : k + 1])
            i = k + 1
            continue
        out.append(text[i : k + 1] + "~" if p != _ROOT and path_before else text[i:k] + "~")
        n += 1
        i = j
    return "".join(out) + text[i:], n


def scrub_counted(text):
    ""
    text, mails = _scrub_emails(str(text))
    text, paths = _scrub_paths(text)
    return text, paths, mails


def scrub(text):
    ""
    return scrub_counted(text)[0]


def selftest():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import sexpr_lib
    rt = sexpr_lib.read_typed
    full = {"kind": "bug", "thomas-version": "0.4", "what": 'thomas ask hangs on "hi"', "repro": "thomas ask hi",
            "expected": "an answer", "got": "no output after 60 s", "test": "assert run('hi') != ''"}
    body = "Sample body.\n\n" + FENCE + "\n" + build(full) + "\n```\nend"
    key = "sk-ant-" + "api03-" + "Zq9Xw8Vu7Ts6Rq5Po4Nm3Lk2Ji1Hg0Fe9Dc8Ba7"
    import ast
    with open(os.path.abspath(__file__), encoding="utf-8") as fh:
        source = fh.read()
    imported = {a.name for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Import) for a in n.names}
    cases = [
        ("comments: this file names no build tool of ours (the home-prefix note says what the code does)",
         ("pack" + "er") not in source.lower()),
        ("the default floor is key_shapes_lib's: it is imported, and the maintainer's whole-file floor is not",
         "key_shapes_lib" in imported and ("sensitive" + "_lib") not in imported),
        ("build then parse returns every field, quotes intact", parse(body, rt) == full),
        ("a body with no sexpr block, or another form, parses to None",
         parse("just prose", rt) is None and parse(FENCE + '\n(issue :what "x")\n```', rt) is None),
        ("a complete bug has no problems", problems(full, lambda t: False) == []),
        ("an idea needs only :what", problems({"kind": "idea", "what": "a sidebar"}, lambda t: False) == []),
        ("a bug without :repro is refused", "missing :repro" in problems({**full, "repro": ""}, lambda t: False)),
        ("an unknown kind is refused", problems({**full, "kind": "rant"}, lambda t: False)[0].startswith("kind must")),
        ("a field over its cap is refused", any("over" in p for p in problems({**full, "what": "x" * 2001},
                                                                              lambda t: False))),
        ("a pasted API key is refused by the real floor", any("credential" in p for p in problems({**full, "got": key}))),
        ("negative control: a clean report passes the real floor", problems(full) == []),
    ]
    def sc(text):
        try:
            return scrub(text.replace("%U", _HOMES[0]))  # %U stands for the mac home prefix, kept out of the source
        except NameError:  # the function is absent: the case fails instead of the whole run crashing
            return None

    def counted(text):
        try:
            return scrub_counted(text.replace("%U", _HOMES[0]))
        except NameError:
            return None

    cases += [
        ("scrub: a home path at the start, middle and end of a line is shortened",
         (sc("%Usam/a.py failed"), sc("see /home/sam/proj/x.py now"), sc("cwd is %Usam"))
         == ("~/a.py failed", "see ~/proj/x.py now", "cwd is ~")),
        ("scrub: two paths on one line, and a path followed by punctuation",
         (sc("cp %Usam/a /home/lee/b"), sc("in %Usam, then /home/lee."), sc('("%Usam/x")'))
         == ("cp ~/a ~/b", "in ~, then ~.", '("~/x")')),
        ("scrub: an address in angle brackets, with dots and a plus sign",
         (sc("Sam <sam@example.org> wrote"), sc("a.b+tag@mail.example.org."), sc("x sam@example.org, y"))
         == ("Sam <email> wrote", "<email>.", "x <email>, y")),
        ("scrub: an at-sign that is not an address, and a path-like word that is not a home, are left alone",
         all(sc(t) == t.replace("%U", _HOMES[0]) for t in ("@name", "a @ b", "sample @ noon", "x@", "%U", "user@host",
                                  "/Usersx/sam", "/myhome/sam", "/home", "/home/", "%U/x", "/mnt/home//x"))),
        ("scrub: counts are paths and addresses, and a clean text counts zero",
         (counted("%Usam/a /home/lee sam@example.org"), counted("nothing here"))
         == (("~/a ~ <email>", 2, 1), ("nothing here", 0, 0))),
        ("scrub: running it twice changes nothing more", sc(sc("%Usam/a sam@example.org")) == "~/a <email>"),
        ("scrub: the root account's home is shortened at the start, middle and end, and counted once each",
         (sc("/root/.ssh/x failed"), sc("cd /root"), sc("in /root, ok"), counted("/root/a and /root"))
         == ("~/.ssh/x failed", "cd ~", "in ~, ok", ("~/a and ~", 2, 0))),
        ("scrub: /root before a sentence-ending dot, a colon, a bracket, a newline or the end becomes ~",
         (sc("it is in /root."), sc("it is in /root. Next"), sc("in /root.\nnext"), sc("(/root)"), sc("/root: full"),
          sc("/root...?"), counted("/root. and /root."))
         == ("it is in ~.", "it is in ~. Next", "in ~.\nnext", "(~)", "~: full", "~...?", ("~. and ~.", 2, 0))),
        ("scrub: a word that only starts with root, or a root folder inside another path, is left alone",
         all(sc(t) == t for t in ("/rootfs/x", "/rooted", "/root-x", "/srv/root/x", "a/root", "/roots", "/root.bak",
                                  "/root.d/x", "/root.txt."))),
        ("scrub: KNOWN GAP -- a home folder name with a space leaves its second word ('~ jr/x' today)",
         (sc("%Usam jr/x"), sc("%Usam jr"), counted("%Usam jr/x")[1]) == ("~ jr/x", "~ jr", 1)),
        ("scrub: a home folder name with a non-ASCII letter goes whole, at the start, middle and end of a line",
         (sc("%Us\u00e4m/a.py failed"), sc("see /home/l\u00e9e/x"), sc("cd %Us\u00e9m."), sc("%Ul\u00e9\u00eb, ok"))
         == ("~/a.py failed", "see ~/x", "cd ~.", "~, ok")),
        ("scrub: a home folder name with a plus sign, or any other sign, goes whole",
         (sc("cp %Usam+dev/a /home/lee+x"), sc("%Ua+b=c/x"), sc("(%Uo'x/x)"))
         == ("cp ~/a ~", "~/x", "(~/x)")),
        ("scrub: an address with a non-ASCII letter in its local part or its domain is replaced whole",
         (sc("s\u00e4m@example.org wrote"), sc("to l\u00e9e.b@mail.example.org."), sc("x sam@b\u00fccher.example, y"),
          sc("<s\u00f6m@example.org>"), sc("a@\u00e9.example"))
         == ("<email> wrote", "to <email>.", "x <email>, y", "<email>", "<email>")),
        (("scrub: an address ends at a bracket, quote, comma, semicolon or colon, and needs something before the at-sign "
          "and a dot after it"),
         (sc("(sam@example.org)"), sc("'sam@example.org';"), sc("sam@example.org:25"), sc("sam@example"), sc("@example.org"))
         == ("(<email>)", "'<email>';", "<email>:25", "sam@example", "@example.org")),
        ("scrub: a home path after file:// (three slashes in all) is shortened, and so is one after =, a comma or a bracket",
         (sc("open file://%Usam/a.py now"), sc("file://%Usam"), sc("path=%Usam/x,(/home/lee/y)"), sc("[file://%Usam/z]"),
          counted("file://%Usam/a s\u00e4m@example.org"))
         == ("open file://~/a.py now", "file://~", "path=~/x,(~/y)", "[file://~/z]", ("file://~/a <email>", 1, 1))),
        ("scrub: a prefix inside another word or path after file:// is still not a home",
         all(sc(t) == t for t in ("file:///rootfs/x", "file:///root.bak", "file:///Usersx/sam"))),
        ("scrub: a home pair after other path segments keeps them and becomes ~ (seven shapes)",
         (sc("/mnt/c%Usam/x"), sc("/var/home/sam/x"), sc("/Volumes/X%Usam"), sc("/private%Usam"), sc("/data/home/sam/x"),
          sc("ssh://h%Usam"), sc("a%Usam"))
         == ("/mnt/c/~/x", "/var/~/x", "/Volumes/X/~", "/private/~", "/data/~/x", "ssh://h/~", "a/~")),
        ("scrub: the segment must be exactly home or Users, and a pair with no NAME is left alone",
         all(sc(t) == t for t in ("/Usersx/sam", "/myhome/sam", "/a/Usersx/sam", "/a/myhome/sam", "/a/home", "/a/home/", "/a/home//x"))),
        ("scrub: two home pairs in one run, and in one line, are both shortened and counted",
         (sc("/mnt/c%Usam/x/home/lee/y"), counted("cp /mnt/c%Usam/a /var/home/lee/b"), sc("/srv/home/sam/x"), sc("file:///srv/home/sam/x"))
         == ("/mnt/c/~/x/~/y", ("cp /mnt/c/~/a /var/~/b", 2, 0), "/srv/~/x", "file:///srv/~/x")),
    ]
    nm = "zqwname"
    prefixes = ("", "/mnt/c", "/var", "/Volumes/X", "/private", "/data", "ssh://h", "a", "file://", "file:///srv", "X=", "(",
                '"', "C:", "/a/b/c/d", "..", "-", "_x")
    segs = ("home", _HOMES[0].strip("/"))
    ends = ("", "/x", "/x/y.py", ".", ",", "]")
    probe = [pre + "/" + sg + "/" + nm + en for pre in prefixes for sg in segs for en in ends]
    left = [t for t in probe if nm in scrub(t)]
    keeps = (_HOMES[0][:-1] + "x/" + nm, "/myhome/" + nm)
    label = (f"scrub: the name never survives {len(probe)} generated home paths ({len(prefixes)} prefixes x {len(segs)} "
             f"segments x {len(ends)} endings); the near-misses /Usersx/NAME and /myhome/NAME keep it")
    cases.append((label, not left and all(nm in scrub(k) for k in keeps)))
    for t in left:
        print("  LEFT BEHIND: " + t)
    bad = [n for n, ok in cases if not ok]
    for n in bad:
        print("  FAIL " + n)
    print(f"report_lib --selftest RESULT: {'PASS' if not bad else 'FAIL'} -- {len(cases) - len(bad)}/{len(cases)}")
    return 0 if not bad else 1


try:
    import didyoumean_lib
except ImportError:  # optional helper; a lib on a machine without it keeps working
    pass
else:
    didyoumean_lib.install(globals())


if __name__ == "__main__":
    sys.exit(selftest() if "--selftest" in sys.argv else 0)
