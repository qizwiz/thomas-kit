#!/usr/bin/env python3
""
import bisect
import re
import sys

_NOUN_TAIL = r"(?:[_.-](?:[A-Za-z0-9]+[_.-])*(?:key|token|secret|passw(?:or)?d|pass|pwd|credentials?))?"
_LIT_STOP = "\\s\"',;)\\]}"
_LIT_SIGILS = r"(?![<$%{=\[(*&\\`@])"  # a placeholder, variable, expression or second `=`
_LIT_SEGCH = r"[A-Za-z0-9_\-+~!@#^*]"  # the literal's alphabet without `/` and `=`
_LIT_CRED_SEG = r"(?-i:(?=" + _LIT_SEGCH + r"*[A-Z])(?=" + _LIT_SEGCH + r"*[a-z])(?=" + _LIT_SEGCH + r"*[0-9]))"
_LIT_CRED_SEG += _LIT_SEGCH + r"{16}"
_LIT_RUN = (
    r"(?:(?<![a-z0-9])(?=[a-z0-9]*[a-z])(?:(?=[a-z0-9]*[0-9])[0-9a-f]{16,}|(?=(?:[a-z]*[0-9]){4})[a-z0-9]{16,})"
    r"(?![a-z0-9])"
    r"|(?<![A-Z0-9])(?=[A-Z0-9]*[A-Z])(?:(?=[A-Z0-9]*[0-9])[0-9A-F]{16,}|(?=(?:[A-Z]*[0-9]){4})[A-Z0-9]{16,})"
    r"(?![A-Z0-9])"
    r"|[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})"
)
_LIT_RUN_SEG = r"(?-i:(?=" + _LIT_SEGCH + r"*?" + _LIT_RUN + r"))"
_LIT_STORE_CTX = (
    r"(?-i:(?<=/nix/store/)|(?<=/gnu/store/)|(?<=/overlay2/)|(?<=/sha256/)|(?<=/objects/[0-9a-f][0-9a-f]/)"
    r"|(?<=/var/folders/" + _LIT_SEGCH + _LIT_SEGCH + r"/))"
)
_LIT_PSEG = (
    r"(?!" + _LIT_CRED_SEG + r")(?:" + _LIT_STORE_CTX + r"|(?!" + _LIT_RUN_SEG + r"))" + _LIT_SEGCH + r"+"
)
_LIT_PATH_SHAPE = (
    r"(?:~/(?:" + _LIT_PSEG + r"/)*" + _LIT_PSEG + r"|/(?!" + _LIT_CRED_SEG + r")(?!" + _LIT_RUN_SEG + r")"
    + r"(?-i:[A-Za-z][a-z]*)[0-9]*(?:/" + _LIT_PSEG + r")+)/?"
    + r"(?=[" + _LIT_STOP + r"]|\Z)"
)
_LIT_PATH = r"(?!" + _LIT_PATH_SHAPE + r")"
PATH_VALUE = re.compile(_LIT_PATH_SHAPE)  # the same shape, for a caller (and the selftest) to ask of one value
_LIT_DATE = (
    r"(?![0-9]{4}-[0-9]{2}-[0-9]{2}(?:[T ][0-9]{2}(?::[0-9]{2}){0,2}(?:\.[0-9]+)?)?(?:Z|[+-][0-9]{2}:?[0-9]{2})?"
    r"(?:[" + _LIT_STOP + r"]|\Z))"
)


_PASS_WORDS = (
    "anti", "by", "becom", "com", "countertres", "de", "encom", "gyrocom", "nontres", "outcom", "out", "over",
    "precom", "re", "recom", "s", "sub", "sur", "to", "tres", "uncom", "under", "un",
    "low", "high", "band", "all", "multi",
)
_GLUE_STEM = (
    r"(?!(?:" + "|".join(_PASS_WORDS) + r")pass(?-i:(?=[^A-Za-z])|\Z|(?<=[a-z])(?=[A-Z])))"
    r"(?-i:[a-z0-9]+|[A-Z][a-z0-9]*|[A-Z0-9]+)"
)


def _literal(quote_group=None):
    ""
    end = r"(?=[" + _LIT_STOP + r"]|\Z)"
    return (
        _LIT_SIGILS + _LIT_PATH + _LIT_DATE
        + r"(?=[^" + _LIT_STOP + r"]*[0-9])(?=[^" + _LIT_STOP + r"]*[A-Za-z])"
        + r"[A-Za-z0-9_\-+/~!@#^*]{8,}={0,2}"
        + (r"(?(" + quote_group + r")(?P=" + quote_group + r")|" + end + r")" if quote_group else end)
    )


SECRET_VALUE = re.compile(
    r"curl[^\n]{0,120}-u[ \t]+[^<\s\"']\S*:[^<\s\"']\S*"
    r"|(password|(?:(?<![A-Za-z0-9])|(?-i:(?<=[a-z0-9])(?=[A-Z])))(?:" + _GLUE_STEM + r")?pass(?:wd)?"
    r"|secret|token|api[_-]?key|bearer)" + _NOUN_TAIL
    + r"[\"']?\s*(?:=>|[=:])\s*[\"'][^\s\"'$<{][^\"'\n]{5,}[\"']"
    r"|authorization\s*:\s*(basic|bearer)\s+[^\s<$\{]\S*"
    r"|\((?:defcustom|defvar|defparameter|defconstant|setq)\s+[\w-]*"
    r"(?:key|secret|token|passwd|password|credential)[\w-]*\s+[\"'][^\s\"'$<{][^\"']{24,}[\"']"
    r"|(?:(?<![A-Za-z0-9_/-])|(?<![^\s\"'(\[,=])(?P<fl>--))(?!pass[\"']?[ \t]*(?:=>|[=:]))(?:[A-Za-z0-9]+[_.-])*"
    r"(?-i:[A-Za-z][a-z0-9]*(?:[A-Z][a-z0-9]+)*(?<=[a-z0-9])(?=[A-Z]))?"
    r"(?:passw(?:or)?d|pass|pwd|passphrase|secret|token|api[_-]?key|credentials?|" + _GLUE_STEM + r"pass(?:w(?:or)?d)?)"
    r"(?-i:(?:(?<=[a-z0-9])[A-Z][a-z0-9]+)*)(?:[_.-][A-Za-z0-9]+)*"
    r"[\"']?(?(fl)(?:[ \t]*=|[ \t]+(?!-))|[ \t]*(?:=>|[=:]))[ \t]*(?P<lq>[\"'])?" + _literal("lq")
    + r"|(?<![A-Za-z0-9_])(?:mysql|mariadb)[A-Za-z_-]*[^\n|;&]{0,200}?[ \t]-p" + _literal()
    + r"|(?<![A-Za-z0-9+.-])[A-Za-z][A-Za-z0-9+.-]*://[^\s:/@?#<>\"'$]*:(?![<${]|%\()"
    r"(?=[^\s:/@?#]*[0-9])(?=[^\s:/@?#]*[A-Za-z])[A-Za-z0-9._~!*%+-]{6,}@"
    r"|(?<![A-Za-z0-9-]):(?:[A-Za-z0-9]+-)*(?:passw(?:or)?d|passphrase|secret|token|api-?key)[ \t]+"
    r"[\"'][^\s\"'$<{][^\s\"']{5,}[\"']"
    r"|<key>[^<\n]{0,40}?(?:passw(?:or)?d|passphrase|secret|token|api[_-]?key)</key>\s*<string>[^<\s$]{6,}</string>"
    r"|(?<![A-Za-z0-9_-])(?:gh[pousr]_[A-Za-z0-9]{36,}"
    r"|github_pat_[A-Za-z0-9_]{22,}"
    r"|AKIA[A-Z0-9]{16}"
    r"|ASIA[A-Z0-9]{16}"
    r"|xox[baprs]-[A-Za-z0-9-]{10,}"
    r"|xapp-[0-9]-[A-Za-z0-9-]{10,}"
    r"|sk-(?:proj-|svcacct-|admin-)?[A-Za-z0-9]{32,}"
    r"|glpat-[A-Za-z0-9_-]{20,}"
    r"|shpat_[A-Za-z0-9]{32}"
    r"|AIza[A-Za-z0-9_-]{35}"
    r"|sk-ant-[A-Za-z0-9_-]{24,}"
    r"|gsk_[A-Za-z0-9]{40,}"
    r"|(?:sk|rk)_live_[A-Za-z0-9]{20,}"
    r"|hf_[A-Za-z0-9]{30,}"
    r"|npm_[A-Za-z0-9]{36}"
    r"|ya29\.[A-Za-z0-9_-]{20,}"
    r"|AQ\.[A-Za-z0-9_-]{30,})"
    r"|(?<![0-9])[0-9]{8,10}:AA[A-Za-z0-9_-]{33}" r"|-----BEGIN [A-Z ]*PRIVATE KEY-----",
    re.IGNORECASE,
)


def _escape_reads(text):
    ""
    if "\\" not in text:
        return [text]
    reads = [text, _escapes_blanked(text)]
    for d in range(8):  # \\U's width is the longest
        r = _escapes_blanked(text, digits=d)
        if r not in reads:
            reads.append(r)
    return reads


def _escapes_blanked(text, digits=None):
    ""
    out, i, n = list(text), 0, len(text)
    hexdigits = "0123456789abcdefABCDEF"
    while i < n:
        if text[i] != "\\":
            i += 1
            continue
        j = i
        while j < n and text[j] == "\\":
            out[j] = " "
            j += 1
        width = {"x": 2, "u": 4, "U": 8}
        if j < n and text[j] in width:
            cap = width[text[j]] if digits is None else min(digits, width[text[j]])
            k = j + 1
            while k < n and k <= j + cap and text[k] in hexdigits:
                k += 1
            j_end = k
        elif j < n and text[j] in "01234567":
            k = j
            while k < n and k < j + (3 if digits is None else max(1, min(digits, 3))) and text[k] in "01234567":
                k += 1
            j_end = k
        elif j < n and (text[j].isalnum() or text[j] in "_-"):  # a key character glues to a key; `\"` keeps its quote
            j_end = j + 1
        else:
            j_end = j
        for k in range(j, j_end):
            out[k] = " "
        i = max(j_end, i + 1)
    return "".join(out)


_KEY = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-")
_UPPER_DIGITS = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
_ALNUM = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
_ALNUM_U = _ALNUM | {"_"}
_SHAPES = (
    ("ghp_", _ALNUM, 36, 0), ("gho_", _ALNUM, 36, 0), ("ghu_", _ALNUM, 36, 0), ("ghs_", _ALNUM, 36, 0),
    ("ghr_", _ALNUM, 36, 0), ("github_pat_", _ALNUM_U, 22, 0),
    ("AKIA", _UPPER_DIGITS, 16, 0), ("ASIA", _UPPER_DIGITS, 16, 0),  # 16 or more (exact missed a longer run)
    ("xoxb-", _KEY, 10, 0), ("xoxa-", _KEY, 10, 0), ("xoxp-", _KEY, 10, 0), ("xoxr-", _KEY, 10, 0),
    ("xoxs-", _KEY, 10, 0), ("xapp-", _KEY, 10, 0),
    ("sk-proj-", _KEY, 32, 0), ("sk-svcacct-", _KEY, 32, 0), ("sk-admin-", _KEY, 32, 0), ("sk-None-", _KEY, 32, 0),
    ("sk-or-v1-", _ALNUM, 64, 0), ("sk-", _KEY, 22, 22),  # LiteLLM virtual keys: sk- + token_urlsafe(16)
    ("sk-", _ALNUM, 32, 0), ("sk_test_", _ALNUM, 20, 0), ("rk_test_", _ALNUM, 20, 0),
    ("glpat-", _KEY, 20, 0), ("shpat_", _ALNUM, 32, 0), ("AIza", _KEY, 35, 0), ("sk-ant-", _KEY, 24, 0),
    ("gsk_", _ALNUM, 40, 0), ("sk_live_", _ALNUM, 20, 0), ("rk_live_", _ALNUM, 20, 0), ("hf_", _ALNUM, 30, 0),
    ("npm_", _ALNUM, 36, 0), ("ya29.", _KEY, 20, 0), ("AQ.", _KEY, 30, 0),  # Google-style key, ~44 after the dot
)
_WORD_END = {"sk-", "sk_test_", "sk_live_", "rk_test_", "rk_live_"}  # the generic key prefixes


def _runs(text, allowed):
    ""
    run = [0] * (len(text) + 1)
    for i in range(len(text) - 1, -1, -1):
        run[i] = run[i + 1] + 1 if text[i] in allowed else 0
    return run


def _next_index(text, pred):
    ""
    nxt = [len(text)] * (len(text) + 1)
    for i in range(len(text) - 1, -1, -1):
        nxt[i] = i if pred(text[i]) else nxt[i + 1]
    return nxt


def shape_spans(text):
    ""
    text = text or ""
    if not text:
        return []
    runs: dict = {}
    digit = _next_index(text, str.isdigit)
    upper, lower = _next_index(text, str.isupper), _next_index(text, str.islower)

    spans: list = []

    def judge(prefix, allowed, minimum, exact, start, end):
        ""
        p = start + len(prefix)
        if id(allowed) not in runs:  # built once per alphabet (setdefault would build it on every call)
            runs[id(allowed)] = _runs(text, allowed)
        n = min(runs[id(allowed)][p], end - p)  # the whole run, never capped
        mixed = upper[p] < p + n and lower[p] < p + n
        if allowed is _UPPER_DIGITS:  # AWS: exactly 16, or a longer run whose first 16 hold a digit
            ok = n == minimum or (n > minimum and digit[p] < p + minimum)  # a word like ASIA+PACIFIC... is not a key
        else:  # a digit, or mixed case (a digit-free key is rare, not impossible)
            ok = (n == exact if exact else n >= minimum) and (digit[p] < p + n or mixed)
        if ok and prefix in _WORD_END:  # a word-ending prefix (risk-, disk_test_) needs a DIGIT; an exact
            ok = digit[p] < p + n and (mixed or not exact)  # shape (LiteLLM's 22) needs mixed case too
        return (start, p + n) if ok else None

    exact_rows = [r for r in _SHAPES if r[1] is _UPPER_DIGITS or r[3]]
    for row in (r for r in _SHAPES if r not in exact_rows):  # minimum-length rows: the whole run
        start = text.find(row[0])
        while start >= 0:
            span = judge(*row, start, len(text))
            if span:
                spans.append(span)
            start = text.find(row[0], start + 1)
    starts = sorted(a for a, _b in spans)
    candidates = []
    for row in exact_rows:
        start = text.find(row[0])
        while start >= 0:
            candidates.append((start, row))
            start = text.find(row[0], start + 1)
    for start, row in sorted(candidates, key=lambda c: -c[0]):
        p = start + len(row[0])
        k = bisect.bisect_left(starts, p)
        span = judge(*row, start, starts[k] if k < len(starts) else len(text))
        if span:
            spans.append(span)
            bisect.insort(starts, start)
    return spans


def has_secret_value(text):
    ""
    text = text or ""
    return bool(shape_spans(text)) or any(SECRET_VALUE.search(r) for r in _escape_reads(text))


_CODE_CUES = (
    "code", "verif", "passcode", "one-time", "one time", "otp", "2fa", "two-factor", "sign in",
    "sign-in", "log in", "login", "security", "authenticat", "pin ",
)  # fmt: skip


def _cue_present(low):
    ""
    for cue in _CODE_CUES:
        i = low.find(cue)
        while i != -1:
            j = i + len(cue)
            starts = i == 0 or not low[i - 1].isalnum()
            ends = j >= len(low) or not low[j].isalnum()
            if starts or ends:
                return True
            i = low.find(cue, i + 1)
    return False


def _json_unescaped(text):
    ""
    for _layer in range(UNESCAPE_PASSES):
        out, i, n = [], 0, len(text)
        hexdigits = "0123456789abcdefABCDEF"
        while i < n:
            ch = text[i]
            if ch == "\\" and i + 1 < n:
                nxt = text[i + 1]
                if nxt == "u" and i + 5 < n and all(c in hexdigits for c in text[i + 2 : i + 6]):
                    out.append(chr(int(text[i + 2 : i + 6], 16)))
                    i += 6
                    continue
                if nxt == "\\":
                    out.append("\\")
                    i += 2
                    continue
                if nxt in 'ntrbf"/':
                    out.append(" ")
                    i += 2
                    continue
            out.append(ch)
            i += 1
        new = "".join(out)
        if new == text:
            return new, True
        text = new
    probe, _ = _json_unescaped_once(text)
    return text, probe == text


def _json_unescaped_once(text):
    ""
    out, i, n = [], 0, len(text)
    hexdigits = "0123456789abcdefABCDEF"
    while i < n:
        ch = text[i]
        if ch == "\\" and i + 1 < n:
            nxt = text[i + 1]
            if nxt == "u" and i + 5 < n and all(c in hexdigits for c in text[i + 2 : i + 6]):
                out.append(chr(int(text[i + 2 : i + 6], 16)))
                i += 6
                continue
            if nxt == "\\":
                out.append("\\")
                i += 2
                continue
            if nxt in 'ntrbf"/':
                out.append(" ")
                i += 2
                continue
        out.append(ch)
        i += 1
    new = "".join(out)
    return new, new != text


UNESCAPE_PASSES = (
    16  # encoding layers read before has_one_time_code treats the text as obfuscated and holds
)


def _space_pair_end(runs, i):
    ""

    def grp(k):
        return 0 <= k < len(runs) and runs[k].isascii() and runs[k].isdigit() and 3 <= len(runs[k]) <= 4

    if not (grp(i) and i + 2 < len(runs) and runs[i + 1] == " " and grp(i + 2)):
        return None
    before = runs[i - 1] if i >= 1 else ""
    after = runs[i + 3] if i + 3 < len(runs) else ""
    if before == ":" and i >= 2 and runs[i - 2].isdigit():
        return None
    if after == ":" and i + 4 < len(runs) and runs[i + 4].isdigit():
        return None

    def chain(k):
        if not (0 <= k < len(runs) and runs[k].isdigit()):
            return False
        return not (k >= 1 and runs[k - 1][-1:].isalpha()) and not (k + 1 < len(runs) and runs[k + 1][:1].isalpha())

    if before in ("-", " ") and chain(i - 2):  # the tail of a longer chain
        return None
    if after in ("-", " ") and chain(i + 4):  # the head of a longer chain
        return None
    return i + 2


def _has_code_run(low):
    ""
    runs, cur = [], []
    for ch in low:
        if ch.isalnum():
            cur.append(ch)
            continue
        if cur:
            runs.append("".join(cur))
            cur = []
        runs.append(ch)
    if cur:
        runs.append("".join(cur))
    for i, r in enumerate(runs):
        if not r.isdigit():
            continue
        if 4 <= len(r) <= 8 or _space_pair_end(runs, i) is not None:
            return True
        j, total = i, len(r)
        while j + 2 < len(runs) and runs[j + 1] == "-" and runs[j + 2].isdigit():
            total += len(runs[j + 2])
            j += 2
        if j > i and 6 <= total <= 8:
            return True
    return False


def has_one_time_code(text):
    ""
    decoded, settled = _json_unescaped(text or "")
    low = decoded.lower()
    if not settled:
        return "\\u" in low or _has_code_run(low) or _cue_present(low)
    if not _cue_present(low):
        return False
    return _has_code_run(low)


def _mask_code_runs(text):
    ""
    out, runs, cur = [], [], []
    for ch in text:
        if ch.isdigit():
            cur.append(ch)
            continue
        if cur:
            runs.append("".join(cur))
            cur = []
        runs.append(ch)
    if cur:
        runs.append("".join(cur))
    i = 0
    while i < len(runs):
        r = runs[i]
        k = _space_pair_end(runs, i) if r.isdigit() else None
        if k is not None:  # before the single-run test: "1234 5678" is ONE code, not two
            out.append("<num>")
            i = k + 1
            continue
        if r.isdigit():
            j, total = i, len(r)
            while j + 2 < len(runs) and runs[j + 1] == "-" and runs[j + 2].isdigit():
                total += len(runs[j + 2])
                j += 2
            if j > i and 6 <= total <= 8:  # a dashed code is ONE mask
                out.append("<num>")
                i = j + 1
                continue
            if 4 <= len(r) <= 8:
                out.append("<num>")
                i += 1
                continue
        out.append(r)
        i += 1
    return "".join(out)


PEM_END = "-----END "


def _token_end(text, i):
    ""
    while i < len(text) and not text[i].isspace():
        i += 1
    return i


def _cut_end(text, m_text, end):
    ""
    if '"' in m_text or "'" in m_text:
        nl = text.find("\n", end)
        return len(text) if nl < 0 else nl
    return _token_end(text, end)


def secret_spans(text):
    ""
    spans = []
    reads = _escape_reads(text)  # same length: offsets agree
    for m in (m for r in reads for m in SECRET_VALUE.finditer(r)):
        a = m.start()
        while a > 0 and not text[a - 1].isspace():
            a -= 1
        if "PRIVATE KEY" in m.group(0):
            e = text.find(PEM_END, m.end())
            b = (
                len(text)
                if e < 0
                else (text.find("\n", e) if text.find("\n", e) >= 0 else len(text))
            )
        else:
            b = _cut_end(text, m.group(0), m.end())
        spans.append((a, max(b, m.end())))
    for a, b in shape_spans(text):
        spans.append((a, _token_end(text, b)))
    merged: list[tuple[int, int]] = []
    for a, b in sorted(spans):
        if merged and a <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], b))
        else:
            merged.append((a, b))
    return merged


def redact(text):
    ""
    s = text or ""
    spans = secret_spans(s)
    n = len(spans)
    for a, b in reversed(spans):
        s = s[:a] + "<secret>" + s[b:]
    if has_one_time_code(s):
        masked = _mask_code_runs(s)
        n += masked.count("<num>") - s.count("<num>")
        s = masked
    return s, n


_P_KW = (
    "pass" + "word", "pass" + "wd", "pass", "pwd", "pass" + "phrase", "sec" + "ret", "to" + "ken", "api" + "_key",
    "api" + "key", "creden" + "tial", "creden" + "tials",
)
_P_OTHER = ("db", "aws", "app", "main", "prod", "client", "user", "stripe", "smtp", "admin", "v2", "rails")
_P_NONFINAL = ("hint", "name", "mode", "count", "len", "file", "env", "label")  # a last segment naming no credential
_P_LOW, _P_UP, _P_DIG = "abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "0123456789"
_P_ROOTS = ("run", "etc", "var", "tmp", "home", "Users", "opt", "usr", "private", "dev", "proc", "srv", "mnt",
            "Volumes", "Library", "System", "root", "bin", "sbin")
P_HELD_KINDS = ("b64", "b64-slash", "b64-plus", "hex", "alnum", "date-prefixed")
P_SHAPES = ("last", "first", "middle", "bare", "screaming", "kebab")
P_SYNTAX = ("unquoted", "unquoted-sp", "yaml", "q-single", "q-double", "json", "export", "envfile")
_P_QUOTED = ("q-single", "q-double", "json")
P_SAFE_KINDS = ("iso-date", "iso-datetime", "home-path", "root-path", "url", "placeholder", "no-digit", "no-letter",
                "short", "dotted")
P_SUBSTR = ("passenger", "bypass", "compass", "monkey", "secretary", "tokenizer", "passive", "surpass")


def _held(text):
    ""
    return bool(has_secret_value(text) or has_one_time_code(text))


def _p_mixed(r, alphabet, n):
    ""
    while True:
        v = "".join(r.choice(alphabet) for _ in range(n))
        if any(c in _P_DIG for c in v) and any(c in _P_LOW or c in _P_UP for c in v):
            return v


def _p_date(r):
    ""
    return f"{r.randint(2000, 2099):04d}-{r.randint(1, 12):02d}-{r.randint(1, 28):02d}"


def _p_held_value(r, kind):
    ""
    n = r.randint(8, 64)
    alnum = _P_LOW + _P_UP + _P_DIG
    if kind == "b64":
        pad = r.choice(("", "=", "=="))
        v = _p_mixed(r, alnum + "+/", max(n - len(pad), 8)) + pad
    elif kind in ("b64-slash", "b64-plus"):
        v = ("/" if kind == "b64-slash" else "+") + _p_mixed(r, alnum + "+/", max(n - 1, 7))
    elif kind == "hex":
        v = _p_mixed(r, _P_DIG + "abcdef", n)
    elif kind == "alnum":
        v = _p_mixed(r, alnum, n)
    else:  # a date, then the literal goes on: a credential, not a date
        v = _p_date(r) + r.choice(_P_UP + _P_LOW) + _p_mixed(r, alnum, max(n - 11, 4))
    if _p_path_shaped(v):
        return _p_held_value(r, kind)
    return v


def _p_seg_runs(s, case):
    ""
    out: list[str] = []
    cur = ""
    for c in s + "/":
        if c in case or c in _P_DIG:
            cur += c
        else:
            out, cur = out + [cur] * bool(cur), ""
    return out


def _p_seg_token(s):
    ""

    def token(run, case, hexes):
        if len(run) < 16 or not any(c in case for c in run):
            return False
        digits = sum(c in _P_DIG for c in run)
        return (digits >= 1 and set(run) <= set(_P_DIG + hexes)) or digits >= 4

    h = set(_P_DIG + "abcdefABCDEF")
    uuid = any(
        all((c == "-") if j in (8, 13, 18, 23) else (c in h) for j, c in enumerate(s[i:i + 36]))
        for i in range(len(s) - 35)
    )
    return (any(token(x, _P_LOW, "abcdef") for x in _p_seg_runs(s, _P_LOW))
            or any(token(x, _P_UP, "ABCDEF") for x in _p_seg_runs(s, _P_UP)) or uuid)


def _p_path_shaped(v):
    ""
    if v.startswith("~/"):
        segs, need = v[2:].split("/"), 1
    elif v.startswith("/"):
        segs, need = v[1:].split("/"), 2
    else:
        return False
    if len(segs) > 1 and segs[-1] == "":
        segs = segs[:-1]
    alphabet = set(_P_LOW + _P_UP + _P_DIG + "_-+~!@#^*")

    def cred(s):
        return len(s) >= 16 and any(c in _P_UP for c in s) and any(c in _P_LOW for c in s) and any(c in _P_DIG for c in s)

    def store(prefix, s):  # a hash naming CONTENT: _LIT_STORE_CTX written a second way
        two = len(prefix) >= 3 and prefix[-1] == "/" and set(prefix[-3:-1]) <= alphabet
        return (prefix.endswith(("/nix/store/", "/gnu/store/", "/overlay2/", "/sha256/"))
                or (two and prefix[:-3].endswith("/var/folders/"))
                or (two and set(prefix[-3:-1]) <= set("0123456789abcdef") and prefix[:-3].endswith("/objects/")))

    if need == 2:  # the first segment after `/` is a WORD: lowercase or Capitalised, digits only at its end (lib64)
        head = segs[0].rstrip(_P_DIG)
        if not (head and head[0] in _P_LOW + _P_UP and all(c in _P_LOW for c in head[1:])) or _p_seg_token(segs[0]):
            return False
    at = 2 if need == 1 else 1
    for s in segs:
        if not s or not set(s) <= alphabet or cred(s) or (_p_seg_token(s) and not store(v[:at], s)):
            return False
        at += len(s) + 1
    return len(segs) >= need


def _p_name(r, kw, shape):
    ""
    a, b = r.choice(_P_OTHER), r.choice(_P_OTHER)
    return {
        "last": a + "_" + kw,
        "first": kw + "_" + a,
        "middle": a + "_" + kw + "_" + b,
        "bare": kw,
        "screaming": (a + "_" + kw + ("_" + b if r.random() < 0.5 else "")).upper(),
        "kebab": a + "-" + kw.replace("_", "-") + r.choice(("", "-" + b)),
    }[shape]


def _p_render(syntax, name, value):
    ""
    s = {
        "unquoted": name + "=" + value,
        "unquoted-sp": name + " = " + value,
        "yaml": "cfg:\n  " + name + ": " + value + "\n  other: 1",
        "q-single": name + " = '" + value + "'",
        "q-double": name + '="' + value + '"',
        "json": '{"user": "sam", "' + name + '": "' + value + '", "n": 1}',
        "export": "export " + name + "=" + value,
        "envfile": "# deploy\nHOST=example\n" + name + "=" + value + "\nNEXT=1",
    }[syntax]
    return s + "\ntrailing words" if syntax in ("yaml", "envfile") else "before words " + s + " after words"


def _p_word_seg(s):
    ""
    return s[:15] if _p_seg_token(s) else s


def _p_safe_value(r, kind):
    ""
    if kind in ("iso-date", "iso-datetime"):
        v = _p_date(r)
        if kind == "iso-datetime":
            m, s = r.randint(0, 59), r.randint(0, 59)
            v += f"T{r.randint(0, 23):02d}" + r.choice(
                ("", f":{m:02d}", f":{m:02d}:{s:02d}", f":{m:02d}:{s:02d}Z", f":{m:02d}:{s:02d}.{m:03d}+00:00")
            )
        return v
    if kind == "home-path":
        return "~/" + _p_word_seg(_p_mixed(r, _P_LOW + _P_DIG, r.randint(4, 20))) + "/" + _p_mixed(r, _P_LOW + _P_DIG, 6)
    if kind == "root-path":
        return "/" + r.choice(_P_ROOTS) + "/" + _p_word_seg(_p_mixed(r, _P_LOW + _P_DIG, r.randint(4, 20)))
    if kind == "url":
        return r.choice(("https", "http")) + "://" + _p_mixed(r, _P_LOW + _P_DIG, 8) + ".example.com/x" + str(r.randint(1, 99))
    if kind == "placeholder":
        w = r.choice(("DB", "API", "SEC")) + "_" + _p_mixed(r, _P_UP + _P_DIG, 6)
        return r.choice(("${" + w + "}", "<" + w + ">", "%(" + w.lower() + ")s", "$" + w, "{{ " + w.lower() + " }}"))
    if kind == "no-digit":
        return "".join(r.choice(_P_LOW + _P_UP) for _ in range(r.randint(8, 40)))
    if kind == "no-letter":
        return "".join(r.choice(_P_DIG) for _ in range(r.randint(8, 40)))
    if kind == "short":
        return _p_mixed(r, _P_LOW + _P_UP + _P_DIG, r.randint(2, 7))
    return r.choice(("settings", "os.environ", "cfg", "self.conf")) + "." + _p_mixed(r, _P_LOW + _P_DIG, r.randint(4, 12))


def property_cases(seed=9161, per_cell=8):
    ""
    import random

    r = random.Random(seed)
    held, safe, i = [], [], 0
    for kind in P_HELD_KINDS:
        for shape in P_SHAPES:
            for syntax in P_SYNTAX:
                for _ in range(per_cell):
                    kw = _P_KW[i % len(_P_KW)]
                    i += 1
                    if shape == "bare" and kw == "pass":
                        kw = "pass" + "wd"
                    name, v = _p_name(r, kw, shape), _p_held_value(r, kind)
                    held.append(((kind, shape, syntax), _p_render(syntax, name, v), v))
    for kind in P_SAFE_KINDS:
        for syntax in P_SYNTAX:
            for _ in range(per_cell):
                kw = _P_KW[i % len(_P_KW)]
                i += 1
                if syntax in _P_QUOTED:
                    name, shape = r.choice(_P_OTHER) + "_" + kw + "_" + r.choice(_P_NONFINAL), "nonfinal"
                else:
                    shape = r.choice(P_SHAPES)
                    name = _p_name(r, kw, shape)
                v = _p_safe_value(r, kind)
                safe.append(((kind, shape, syntax), _p_render(syntax, name, v), v))
    for word in P_SUBSTR:
        for syntax in P_SYNTAX:
            for _ in range(per_cell // 2):
                form = r.choice((word, word + "_*", "*_" + word))
                name = form.replace("*", r.choice(_P_OTHER))
                v = _p_held_value(r, r.choice(P_HELD_KINDS))
                safe.append((("substr-name", form, syntax), _p_render(syntax, name, v), v))
    for syntax in _P_QUOTED + ("yaml",):
        for _ in range(per_cell):
            kw = _P_KW[i % len(_P_KW)]
            i += 1
            name = r.choice(_P_OTHER) + "_" + kw + "_" + r.choice(_P_NONFINAL)
            v = r.choice((f"use the {r.choice(('2nd', '3rd'))} pet name", f"rotate every {r.randint(2, 90)} days"))
            safe.append((("prose-nonfinal", "nonfinal", syntax), _p_render(syntax, name, v), v))
    return held, safe


def property_failures(held, safe):
    ""
    held_fail: dict[tuple, list] = {}
    safe_fail: dict[tuple, list] = {}
    for label, text, v in held:
        cut = redact(text)[0]
        if not _held(text):
            held_fail.setdefault(("not-held",) + label, []).append((text, v))
        if any(v[j : j + 6] in cut for j in range(len(v) - 5)):
            held_fail.setdefault(("fragment",) + label, []).append((text, v))
    for label, text, v in safe:
        if _held(text) or redact(text)[0] != text:
            safe_fail.setdefault(label, []).append((text, v))
    return held_fail, safe_fail


P_X_SHAPES = P_SHAPES + ("camel",)
P_X_SYNTAX = ("flag-eq", "flag-sp", "ruby-hash")
P_URL_KINDS = ("alnum", "hex", "date-prefixed", "url-punct")
P_URL_SCHEMES = ("postgres", "mysql", "redis", "amqp", "https")
P_PFLAG_CTX = ("mysql", "mysqldump")
P_X_SAFE = (
    "url-port", "url-no-password", "user-at-host", "url-placeholder", "scp-like", "flag-password-file",
    "flag-password-file-sp", "flag-token-ttl", "flag-token-ttl-sp", "flag-placeholder", "flag-no-digit", "p-port-sp",
    "p-port-glued", "p-patch", "camel-hint", "camel-substr", "camel-count", "ruby-params", "ruby-prose", "ruby-nil",
    "kw-space-prose", "flag-then-flag", "p-hyphen-name",
)


def _p_x_name(r, kw, shape):
    ""
    if shape == "camel":
        return r.choice(_P_OTHER) + "".join(p[:1].upper() + p[1:] for p in kw.split("_"))
    return _p_name(r, kw, shape)


def _p_x_render(syntax, name, value):
    ""
    s = {
        "flag-eq": "app serve --" + name + "=" + value,
        "flag-sp": "app serve --" + name + " " + value,
        "ruby-hash": "conn = {:" + name + " => '" + value + "', :pool => 5}",
    }.get(syntax)
    return _p_render(syntax, name, value) if s is None else "before words " + s + " after words"


def _p_url_value(r, kind):
    ""
    alnum = _P_LOW + _P_UP + _P_DIG
    if kind == "url-punct":
        return _p_mixed(r, alnum + "-._~!*", r.randint(8, 40))
    return _p_held_value(r, kind)


def _p_x_safe(r, form):
    ""
    host = _p_mixed(r, _P_LOW + _P_DIG, 8) + ".example.com"
    port = str(r.randint(1024, 65000))
    word = "".join(r.choice(_P_LOW) for _ in range(r.randint(8, 20)))
    kw = r.choice(("pass" + "word", "sec" + "ret", "to" + "ken"))
    return {
        "url-port": "see https://" + host + ":" + port + "/path" + str(r.randint(1, 99)) + " for docs",
        "url-no-password": "dial " + r.choice(P_URL_SCHEMES) + "://" + word + "@" + host + ":" + port + "/db now",
        "user-at-host": "ssh " + word + "@" + host + " uptime",
        "url-placeholder": "DSN postgres://" + word + ":${DB_" + "PASS" + "WORD}@" + host + "/db",
        "scp-like": "clone git@" + host + ":org/" + word + ".git here",
        "flag-password-file": "app serve --" + kw + "-file=/run/" + _p_mixed(r, _P_LOW + _P_DIG, 10) + " now",
        "flag-password-file-sp": "app serve --" + kw + "-file /etc/" + _p_mixed(r, _P_LOW + _P_DIG, 10) + " now",
        "flag-token-ttl": "app serve --" + "to" + "ken-ttl=" + str(r.randint(60, 99999)) + " now",
        "flag-token-ttl-sp": "app serve --" + "to" + "ken-ttl " + str(r.randint(60, 99999)) + " now",
        "flag-placeholder": "app serve --api" + "-key=$API_" + "KEY --" + kw + " ${" + kw.upper() + "} now",
        "flag-no-digit": "app serve --" + kw + "-name=" + word + " now",
        "p-port-sp": "ssh -p " + port + " " + host,
        "p-port-glued": "docker run -p" + port + ":80 img" + str(r.randint(1, 9)),
        "p-patch": "patch -p" + str(r.randint(0, 3)) + " < fix" + str(r.randint(1, 99)) + ".diff",
        "camel-hint": "cfg " + r.choice(_P_OTHER) + "PasswordHint=" + word + " done",
        "camel-substr": "cfg " + r.choice(("bypassMode", "compassHeading", "passengerCount", "tokenizerPath"))
        + "=" + _p_mixed(r, _P_LOW + _P_UP + _P_DIG, 12) + " done",
        "camel-count": "cfg max" + r.choice(("Tokens", "TokenCount")) + "=" + str(r.randint(100, 9999)) + " done",
        "ruby-params": "user = {:" + kw + " => params[:" + kw + "], :id => " + port + "}",
        "ruby-prose": "hint = {:" + kw + "_hint => 'rotate every " + str(r.randint(2, 90)) + " days'}",
        "ruby-nil": "conn = {:" + kw + " => nil, :port => " + port + "}",
        "kw-space-prose": "the " + kw + " " + _p_mixed(r, _P_LOW + _P_UP + _P_DIG, 12) + " was seen",
        "flag-then-flag": "app serve --skip-" + kw + " --verbose-mode" + str(r.randint(2, 9)) + " x",
        "p-hyphen-name": "dir -> " + r.choice(("-private-tmp-claude-", "-preflight-", "-projects-x")) + port + " ok",
    }[form]


def property_cases_syntax(seed=9162, per_cell=8):
    ""
    import random

    r = random.Random(seed)
    held, safe, i = [], [], 0
    cells = [(k, "camel", s) for k in P_HELD_KINDS for s in P_SYNTAX]
    cells += [(k, sh, s) for k in P_HELD_KINDS for sh in P_X_SHAPES for s in P_X_SYNTAX]
    for kind, shape, syntax in cells:
        for _ in range(per_cell):
            kw = _P_KW[i % len(_P_KW)]
            i += 1
            if shape == "bare" and kw == "pass":
                kw = "pass" + "wd"
            name, v = _p_x_name(r, kw, shape), _p_held_value(r, kind)
            held.append(((kind, shape, syntax), _p_x_render(syntax, name, v), v))
    for kind in P_URL_KINDS:
        for scheme in P_URL_SCHEMES:
            for _ in range(per_cell):
                v = _p_url_value(r, kind)
                user = r.choice(("", "sam", "admin", "app_" + str(r.randint(1, 9))))
                tail = "/" + r.choice(("db", "0", "vhost", "api/v1"))
                host = _p_mixed(r, _P_LOW + _P_DIG, 6) + ".internal:" + str(r.randint(1024, 65000))
                held.append(
                    ((kind, "userinfo", "url-" + scheme), f"before words {scheme}://{user}:{v}@{host}{tail} after", v)
                )
    for kind in P_HELD_KINDS:
        for ctx in P_PFLAG_CTX:
            for _ in range(per_cell):
                v = _p_held_value(r, kind)
                text = ("mysql -u root -p" + v + " appdb" if ctx == "mysql" else "mysqldump -p" + v + " --all > o.sql")
                held.append(((kind, "short", "pflag-" + ctx), "before words " + text + " after", v))
    for form in P_X_SAFE:
        for _ in range(per_cell):
            t = _p_x_safe(r, form)
            safe.append((("x-nearmiss", form, "prose"), "before words " + t + " after words", t))
    return held, safe


def property_syntax_cells():
    ""
    return (
        len(P_HELD_KINDS) * len(P_SYNTAX)
        + len(P_HELD_KINDS) * len(P_X_SHAPES) * len(P_X_SYNTAX)
        + len(P_URL_KINDS) * len(P_URL_SCHEMES)
        + len(P_HELD_KINDS) * len(P_PFLAG_CTX)
    )


P_PATH_ROOTS = ("run", "etc", "var", "tmp", "home", "Users", "opt", "usr", "private", "dev", "proc", "srv", "mnt",
                "Volumes", "Library", "System", "root", "bin", "sbin", "Applications", "data", "app", "nix", "lib",
                "lib64", "workspace", "code", "src", "media", "boot", "snap", "sys", "cores", "Network")
P_PATH_HELD = ("root-cred", "root-deep-cred", "multi-slash-last", "multi-slash-mid", "multi-slash-first")
P_PATH_SAFE = ("sys", "run-secrets", "ssh-key", "etc-ssl", "nix-store", "mac-tmp", "docker-overlay", "project")
_P_NIX32 = "0123456789abcdfghijklmnpqrsvwxyz"  # nix's base32 alphabet: lowercase and digits only


def _p_three(r, n, extra=""):
    ""
    while True:
        v = "".join(r.choice(_P_LOW + _P_UP + _P_DIG + extra) for _ in range(n))
        if any(c in _P_UP for c in v) and any(c in _P_LOW for c in v) and any(c in _P_DIG for c in v):
            return v


def _p_path_held_value(r, kind):
    ""
    cred = _p_three(r, r.randint(16, 48), "+")
    if kind == "root-cred":
        return "/" + r.choice(P_PATH_ROOTS) + "/" + cred
    if kind == "root-deep-cred":
        return "/" + r.choice(P_PATH_ROOTS) + "/" + _p_mixed(r, _P_LOW + _P_DIG, r.randint(3, 10)) + "/" + cred
    segs = [_p_mixed(r, _P_LOW + _P_UP + _P_DIG + "+", r.randint(2, 12)) for _ in range(r.randint(1, 3))]
    at = {"multi-slash-last": len(segs), "multi-slash-first": 0}.get(kind, r.randint(1, max(len(segs) - 1, 1)))
    segs.insert(at, cred)
    return "/" + "/".join(segs)


def _p_path_safe_value(r, kind):
    ""
    low = _P_LOW + _P_DIG
    word = "".join(r.choice(_P_LOW) for _ in range(r.randint(3, 10)))
    if kind == "sys":  # a segment mixing three classes but shorter than 16 is a file name
        return "/sys/" + r.choice(("class", "devices", "kernel", "fs", "bus")) + "/" + _p_three(r, r.randint(8, 15))
    if kind == "run-secrets":
        return "/run/secrets/" + word + r.choice(("_pass" + "word", "_to" + "ken", "_key", "")) + r.choice(("", "2"))
    if kind == "ssh-key":
        return "~/.ssh/" + r.choice(("id_ed25519", "id_rsa", "known_hosts", "config", "id_ecdsa_sk"))
    if kind == "etc-ssl":
        return "/etc/ssl/private/" + word + r.choice((".key", ".pem", ""))
    if kind == "nix-store":
        h = "".join(r.choice(_P_NIX32) for _ in range(32))
        return "/nix/store/" + h + "-" + word + r.choice(("", "-" + str(r.randint(1, 9)) + "." + str(r.randint(0, 20))))
    if kind == "mac-tmp":
        return "/var/folders/" + _p_mixed(r, low, 2) + "/" + _p_mixed(r, low + "_", 28) + "gn/T/" + word
    if kind == "docker-overlay":
        return "/var/lib/docker/overlay2/" + "".join(r.choice("0123456789abcdef") for _ in range(64)) + "/diff"
    return "/" + r.choice(("src", "app", "data", "lib", "code")) + "/" + word + "/" + _p_mixed(r, low + "_-", 8)


def property_cases_paths(seed=9163, per_cell=8, held_kinds=P_PATH_HELD, safe_kinds=P_PATH_SAFE, held_fn=None,
                         safe_fn=None):
    ""
    import random

    held_fn, safe_fn = held_fn or _p_path_held_value, safe_fn or _p_path_safe_value
    r = random.Random(seed)
    held, safe, i = [], [], 0
    for kind in held_kinds:
        for syntax in P_SYNTAX:
            for _ in range(per_cell):
                kw, shape = _P_KW[i % len(_P_KW)], P_SHAPES[i % len(P_SHAPES)]
                i += 1
                if shape == "bare" and kw == "pass":
                    kw = "pass" + "wd"
                v = held_fn(r, kind)
                held.append(((kind, shape, syntax), _p_render(syntax, _p_name(r, kw, shape), v), v))
    for kind in safe_kinds:
        for syntax in P_SYNTAX:
            for _ in range(per_cell):
                kw = _P_KW[i % len(_P_KW)]
                i += 1
                if syntax in _P_QUOTED:
                    name, shape = r.choice(_P_OTHER) + "_" + kw + "_" + r.choice(_P_NONFINAL), "nonfinal"
                else:
                    shape = r.choice(P_SHAPES)
                    name = _p_name(r, kw, shape)
                v = safe_fn(r, kind)
                safe.append(((kind, shape, syntax), _p_render(syntax, name, v), v))
    return held, safe


P_PRUN_HELD = ("hex-last", "hex-mid", "lowdig-last", "lowdig-mid", "uphex-last", "updig-mid", "uuid-last", "uuid-mid")
P_PRUN_SAFE = ("nix-name", "gnu-store", "docker-overlay", "git-object", "mac-tmp-bare", "word-digits", "hex-15",
               "lowdig-3", "digits-only")
_P_HEX = "0123456789abcdef"


def _p_run(r, alphabet, n, digits_at_least=1, letter=True):
    ""
    while True:
        v = "".join(r.choice(alphabet) for _ in range(n))
        if sum(c in _P_DIG for c in v) >= digits_at_least and (not letter or any(c not in _P_DIG for c in v)):
            return v


def _p_uuid(r, upper=False):
    v = "-".join("".join(r.choice(_P_HEX) for _ in range(n)) for n in (8, 4, 4, 4, 12))
    return v.upper() if upper else v


def _p_prun_held_value(r, kind):
    ""
    n = r.randint(16, 64)
    tok = {
        "hex": lambda: _p_run(r, _P_HEX, n),
        "lowdig": lambda: _p_run(r, _P_LOW + _P_DIG, n, digits_at_least=4),
        "uphex": lambda: _p_run(r, _P_HEX.upper(), n),
        "updig": lambda: _p_run(r, _P_UP + _P_DIG, n, digits_at_least=4),
        "uuid": lambda: _p_uuid(r, upper=r.random() < 0.2),
    }[kind.rsplit("-", 1)[0]]()
    word = "".join(r.choice(_P_LOW) for _ in range(r.randint(1, 8)))
    head = "/" + r.choice(P_PATH_ROOTS) + "/" + word
    if kind.endswith("-last"):
        return head + "/" + tok
    return head + "/" + tok + "/" + "".join(r.choice(_P_LOW) for _ in range(r.randint(1, 8)))


def _p_prun_safe_value(r, kind):
    ""
    word = "".join(r.choice(_P_LOW) for _ in range(r.randint(3, 10)))
    if kind in ("nix-name", "gnu-store"):
        h = "".join(r.choice(_P_NIX32) for _ in range(32))
        root = "/nix/store/" if kind == "nix-name" else "/gnu/store/"
        return root + h + "-" + word + r.choice(("", "-" + str(r.randint(1, 9)), "/bin/" + word))
    if kind == "docker-overlay":
        return "/var/lib/docker/overlay2/" + "".join(r.choice(_P_HEX) for _ in range(64)) + r.choice(("/diff", "/merged", ""))
    if kind == "git-object":
        return "/srv/git/" + word + "/objects/" + _p_run(r, _P_HEX, 2, 0, False) + "/" + _p_run(r, _P_HEX, 38)
    if kind == "mac-tmp-bare":  # the random part drawn with no `_`: one run of 30 lowercase-and-digits
        return "/var/folders/" + _p_mixed(r, _P_LOW + _P_DIG, 2) + "/" + _p_run(r, _P_LOW + _P_DIG, 28, 4) + "gn/T/" + word
    if kind == "word-digits":
        return "/home/" + word + "/" + r.choice(("release", "build", "backup", "project")) + "-" + str(r.randint(2000, 2030)) \
            + "-" + str(r.randint(1, 12)) + "/v" + str(r.randint(1, 999))
    if kind == "hex-15":
        return "/var/cache/" + word + "/" + _p_run(r, _P_HEX, 15)
    if kind == "lowdig-3":  # 16+ lowercase with exactly 3 digits, none of them a hex-only run
        while True:
            v = _p_run(r, _P_LOW, r.randint(13, 30), 0) + str(r.randint(100, 999))
            if any(c not in _P_HEX for c in v):
                return "/opt/" + word + "/" + v
    return "/proc/" + str(r.randint(1, 99999)) + "/" + "".join(r.choice(_P_DIG) for _ in range(r.randint(16, 20)))


def property_cases_pathrun(seed=9166, per_cell=8):
    ""
    return property_cases_paths(seed, per_cell, P_PRUN_HELD, P_PRUN_SAFE, _p_prun_held_value, _p_prun_safe_value)


_P_GLUE_STEMS = _P_OTHER + ("redis", "mail", "wifi", "vnc", "ftp", "root", "sudo", "master", "key", "store", "my",
                            "svc", "ldap", "git", "web", "sql", "api")
P_T_SYNTAX_FLAG = ("args-eq", "args-sp", "export-eq", "args-quoted")
P_T_GLUE_CASE = ("lower", "upper", "capital")
P_T_GLUE_SYNTAX = P_SYNTAX + ("q-space",)
P_T_SAFE = ("pascal-nonfinal", "pascal-substr", "args-no-cred", "english-pass")


def _p_cap(kw):
    ""
    return "".join(p[:1].upper() + p[1:] for p in kw.split("_"))


def _p_t_render(syntax, name, value):
    ""
    s = {
        "args-eq": "ARGS=--" + name + "=" + value,
        "args-sp": "OPTS=--" + name + " " + value,
        "export-eq": "export JAVA_OPTS=--" + name + "=" + value,
        "args-quoted": 'ARGS="--' + name + "=" + value + ' --verbose"',
    }[syntax]
    return "before words " + s + " after words"


def _p_glue_case(name, case):
    ""
    return {"lower": name, "upper": name.upper(), "capital": name.capitalize()}[case]


def _p_t_safe(r, form, syntax):
    ""
    word = "".join(r.choice(_P_LOW) for _ in range(r.randint(8, 20)))
    if form == "pascal-nonfinal":
        name = r.choice(_P_OTHER).capitalize() + r.choice(
            ("PasswordHint", "TokenType", "SecretName", "ApiKeyLabel", "PasswordLength", "TokenCount")
        )
        return _p_render(syntax, name, word.capitalize()), word
    if form == "pascal-substr":
        name = r.choice(("Bypass", "Compass", "Passenger", "Tokenizer", "Secretary", "Surpass", "Passive"))
        name += r.choice(("", "Mode", "Heading", "Count", "Path"))
        v = _p_held_value(r, r.choice(P_HELD_KINDS))
        return _p_render(syntax, name, v), v
    if form == "args-no-cred":
        kw = r.choice(("pass" + "word", "to" + "ken", "sec" + "ret", "api" + "-key"))
        env = kw.upper().replace("-", "_")
        t = r.choice((
            "ARGS=--verbose --port " + str(r.randint(1024, 65000)),
            "ARGS=--" + kw + "-file=/run/" + word,
            "OPTS=--to" + "ken-ttl " + str(r.randint(60, 99999)),
            "ARGS=--skip-" + kw + " --verbose-mode" + str(r.randint(2, 9)),
            "OPTS=--" + kw + " $" + env,
            "ARGS=--" + kw + "=${DB_" + env + "}",
            "ARGS=--" + kw + "-name=" + word,
        ))
        return "before words " + t + " after words", t
    name = _p_glue_case(r.choice(_PASS_WORDS) + "pass", r.choice(P_T_GLUE_CASE))
    v = _p_held_value(r, r.choice(P_HELD_KINDS))
    if syntax == "q-space":
        return "before words " + name + ' = "' + v + " and " + word + '" after words', v
    return _p_render(syntax, name, v), v


def property_cases_tail(seed=9165, per_cell=8):
    ""
    import random

    r = random.Random(seed)
    held, safe, i = [], [], 0
    for kind in P_HELD_KINDS:
        for syntax in P_SYNTAX:
            for _ in range(per_cell):
                kw = _P_KW[i % len(_P_KW)]
                i += 1
                name, v = r.choice(_P_OTHER).capitalize() + _p_cap(kw), _p_held_value(r, kind)
                held.append(((kind, "pascal", syntax), _p_render(syntax, name, v), v))
        for shape in P_X_SHAPES:
            for syntax in P_T_SYNTAX_FLAG:
                for _ in range(per_cell):
                    kw = _P_KW[i % len(_P_KW)]
                    i += 1
                    if shape == "bare" and kw == "pass":
                        kw = "pass" + "wd"
                    name, v = _p_x_name(r, kw, shape), _p_held_value(r, kind)
                    held.append(((kind, shape, syntax), _p_t_render(syntax, name, v), v))
        for case in P_T_GLUE_CASE:
            for syntax in P_T_GLUE_SYNTAX:
                for _ in range(per_cell):
                    stem = r.choice(_P_GLUE_STEMS) + r.choice(("pass", "pass" + "wd", "pass" + "word"))
                    name, v = _p_glue_case(stem, case), _p_held_value(r, kind)
                    if syntax == "q-space":
                        text = "before words " + name + ' = "' + v + ' and more" after words'
                    else:
                        text = _p_render(syntax, name, v)
                    held.append(((kind, "glued-" + case, syntax), text, v))
    for form in P_T_SAFE:
        for syntax in P_T_GLUE_SYNTAX if form == "english-pass" else P_SYNTAX:
            for _ in range(per_cell):
                t, v = _p_t_safe(r, form, syntax)
                safe.append((("t-nearmiss", form, syntax), t, v))
    return held, safe


def property_tail_cells():
    ""
    return len(P_HELD_KINDS) * (
        len(P_SYNTAX) + len(P_X_SHAPES) * len(P_T_SYNTAX_FLAG) + len(P_T_GLUE_CASE) * len(P_T_GLUE_SYNTAX)
    )


def selftest():
    ""
    import ast
    import functools
    import json
    import random

    results: list = []

    def chk(tag, name, ok, why):
        results.append(bool(ok))
        print(f"  {tag:<7} {name:<39} {'PASS' if ok else 'FAIL':<4} {why}")

    with open(__file__, encoding="utf-8") as fh:
        tree = ast.parse(fh.read())
    mods = {a.name.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names}
    mods |= {n.module.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module}
    chk("IMPORT", "standard-library-only", mods <= set(sys.stdlib_module_names), f"imports {sorted(mods)}")
    kw, pem = "pass" + "word", "-----BEGIN " + "RSA PRIVATE KEY-----"
    _CFG_V = "Zq7" + "wX9pLm2Rt"  # a config value with a digit, assembled so no line here is the shape
    content = [
        (kw + ' = "' + "hunter2" * 3 + '"', True, "a quoted literal after a credential word"),
        (
            'else [("tok'
            + 'en", "tok'
            + "en/sec"
            + 'ret: ", True)]\n    )\n    for x in y:\n        z = f(a)\n        d["',
            False,
            "a label string's closing quote does not open a value that runs across lines to the next quote",
        ),
        (
            kw + ': "' + "hunter2" * 3 + '"',
            True,
            "the same key-colon-quoted literal on ONE line still matches",
        ),
        (pem + "\nMIIB", True, "a private-key header"),
        ("token = line.split()", False, "a variable, not a literal"),
        (kw + ' = "<' + kw + '>"', False, "an angle-bracket placeholder"),
        ("gh" + "p_" + "A1b2C3" * 6, True, "a GitHub PAT, bare"),
        ("AK" + "IA" + "ABCD1234EFGH5678", True, "an AWS access key id, bare"),
        ("xo" + "xb-" + "1234567890-" + "abcdefghij1234567890abcd", True, "a Slack bot token"),
        ("sk" + "-" + "A1b2C3d4" * 4, True, "an sk- style API key"),
        ("a1b2c3d4" * 5, False, "40 hex chars is a GIT SHA -- bare entropy must stay allowed"),
        ("12345678" + "90123-0", False, "a 13-digit id, a dash and a digit is no secret: bare digits stay allowed"),
        ("the sk-learn docs", False, "a short sk- word in prose, under the length floor"),
        (
            "no-disk-prompt-test--pins-canonical-noninteractive-choice",
            False,
            "an elisp symbol containing disk- is NOT an sk- token: a token starts a word",
        ),
        (
            "a task-queue-dispatcher-with-a-very-long-descriptive-name",
            False,
            "task- likewise -- lisp and kebab-case are full of these",
        ),
        (
            "sk" + "-" + "A1b2C3d4" * 4 + " in a sentence",
            True,
            "a real key still caught when it starts a word",
        ),
        ("commit " + "f" * 40 + " landed", False, "a sha in a sentence"),
        (
            "bot" + "1234567890" + ":" + "AA" + "Bc1D2" * 6 + "efg" + "/getMe",
            True,
            "a chat-bot token in a URL",
        ),
        (
            "sk" + "-ant-" + "api03-" + "A1b2C3d4" * 4 + "-x_Y",
            True,
            "an Anthropic key (hyphens in the body)",
        ),
        ("gs" + "k_" + "A1b2C3d4" * 6, True, "a Groq key"),
        ("sk" + "_live_" + "A1b2C3d4" * 3, True, "a Stripe live secret key"),
        ("h" + "f_" + "A1b2C3d4" * 4 + "xy", True, "a Hugging Face token"),
        ("np" + "m_" + "A1b2C3d4e5f6" * 3, True, "an npm token"),
        ("ya" + "29." + "A1b2C3d4" * 3, True, "a Google OAuth access token"),
        ("A" + "Q." + "A1b2C3d4" * 5 + "A1b2", True, "a Google-style key, bare"),
        ("GOOGLE_API" + "_KEY=" + "A" + "Q." + "A1b2C3d4" * 5 + "A1b2", True, "a Google-style key written as NAME=VALUE"),
        ("A" + "Q." + "Ab1Cd", False, "a short look-alike (the prefix and 5 characters) is not a key"),
        ("Author" + "ization: Bearer " + "A1b2C3d4" * 4, True, "a real bearer value still caught"),
        (
            "Author" + "ization: Bearer <" + "KEY>",
            False,
            "an angle-bracket placeholder is not a credential",
        ),
        (
            "Author" + "ization: Bearer $" + "TOKEN",
            False,
            "a variable reference is not a credential",
        ),
        ("slot at 12:30 AAA office", False, "a time is not a bot token"),
        ("npm_modules and hf_home and ya29.5", False, "short prefixed words in prose stay allowed"),
        ("1791022020:" + "AA" + "short", False, "digits:AA under the length floor"),
        ("(:" + kw + ' "' + _CFG_V + '")', True, "keyword plist: a lisp keyword, a space, a quoted value"),
        (kw + " = " + _CFG_V, True, "unquoted assignment"),
        ("export DB_" + kw.upper() + "=" + _CFG_V, True, "env-file line, the key word ending a longer name"),
        (kw + ": " + _CFG_V, True, "YAML, unquoted value"),
        ("<key>" + kw + "</key>\n\t<string>" + _CFG_V + "</string>", True, "XML plist key/string pair"),
        ("TOK" + "EN=" + _CFG_V + "==", True, "env value with base64 padding"),
        ("SEC" + "RET_KEY=" + _CFG_V, True, "the key word, then a credential noun ending the name"),
        ("AWS_SEC" + "RET_ACCESS_KEY=" + _CFG_V, True, "the key word, other segments, then the noun"),
        ("client_sec" + "ret_key: " + _CFG_V, True, "the same name shape in YAML"),
        ("SEC" + 'RET_KEY = "' + _CFG_V + '"', True, "the same name shape with a QUOTED value"),
        ("api_tok" + "en_secret=" + _CFG_V, True, "a noun ending a name that already holds a key word"),
        ("sec" + "ret_key_name = " + _CFG_V, True, "a key word segment anywhere: the value's shape decides"),
        ("sec" + "ret_key_name = something_without_digits", False, "a key word segment, but no digit in the value"),
        ("monkey_key=" + _CFG_V, False, "a credential noun last but no key word in the name"),
        ("SEC" + "RET_KEY_BASE=" + _CFG_V, True, "Rails: the key word, then segments, no noun last"),
        ("DB_PA" + "SS=" + _CFG_V, True, "PASS as a whole segment ending the name"),
        ("sec" + "ret_key_base: " + _CFG_V, True, "the Rails name in YAML"),
        ("passenger_count=" + "12345678", False, "`pass` inside a segment is not a key word (and no letter)"),
        ("passenger_id=" + _CFG_V, False, "`pass` inside a segment, a literal value"),
        ("by" + "pass_mode=" + _CFG_V, False, "`pass` ending a segment is not a whole segment"),
        ("com" + "pass=" + _CFG_V, False, "`pass` ending a word"),
        ("bypass_mode=on", False, "a short word value"),
        ("by" + 'pass_mode = "' + _CFG_V + '"', False, "bypass before a quoted literal"),
        ("com" + 'pass = "' + _CFG_V + '"', False, "a word ending in pass, quoted"),
        ("dbpass" + 'word = "' + _CFG_V + '"', True, "a glued `password` stays held"),
        ("db_pa" + 'ss = "' + _CFG_V + '"', True, "`pass` starting a segment stays held"),
        ("dbpa" + 'ss = "' + _CFG_V + '"', True, "a `pass` glued onto a stem is held, quoted"),
        ("dbpa" + "ss=" + _CFG_V, True, "...and unquoted"),
        ("tres" + 'pass = "' + _CFG_V + '"', False, "trespass is an English word"),
        ("encom" + "pass=" + _CFG_V, False, "encompass is an English word"),
        ("cfg Client" + "Secret=" + _CFG_V + " done", True, "a PascalCase name"),
        ("cfg DbPass" + "word=" + _CFG_V + " done", True, "a PascalCase name"),
        ("cfg DbPass" + "wordHint=lengthy done", False, "a PascalCase name judged by its value: no literal"),
        ("ARGS=--pass" + "word=" + _CFG_V, True, "a flag right after `=`"),
        ("OPTS=--to" + "ken " + _CFG_V, True, "a flag and a space right after `=`"),
        ("ARGS=--verbose --port 8080", False, "flags after `=` holding no credential"),
        ("postgres://app:" + _CFG_V + "@db.internal:5432/x", True, "a password in a URL's userinfo"),
        ("redis://:" + _CFG_V + "@cache:6379/0", True, "an empty URL user"),
        ("https://example.com:8080/path", False, "a port after a host is no userinfo"),
        ("postgres://app:${DB_" + "PW}@db/x", False, "a URL placeholder"),
        ("postgres://app:" + "postgres@db/x", False, "KNOWN GAP pinned: a word-only URL password (a dev default)"),
        ("run --db-pass" + "word=" + _CFG_V, True, "a --flag=value"),
        ("run --pass" + "word " + _CFG_V, True, "a --flag value"),
        ("run --pass" + "word-file=/run/x/" + _CFG_V, False, "a --flag naming a file path"),
        ("run --to" + "ken-ttl 3600", False, "a --flag with a number"),
        ("the to" + "ken " + _CFG_V + " was seen", False, "a space binds only after --"),
        ("mysql -u root -p" + _CFG_V + " db", True, "mysql's glued -p"),
        ("ssh -p 2222 host", False, "a port flag"),
        ("dbPass" + "word=" + _CFG_V, True, "camelCase"),
        ("clientSec" + "ret: " + _CFG_V, True, "camelCase in YAML"),
        ("dbPass" + "wordHint=firstpet", False, "a camel hump after the key word, a word value"),
        ("SEC" + "RETKEY=" + _CFG_V, False, "a fused SCREAMING name still never starts a hump"),
        ("{:pass" + "word => '" + _CFG_V + "'}", True, "a Ruby hash rocket"),
        ("{:pass" + "word => params[:x]}", False, "a hash rocket to code"),
        ("SEC" + "RETKEY_BASE=" + _CFG_V, False, "the key word fused into a segment"),
        ("PA" + "SS=2026-10-20T20", False, "a bare PASS name, a date value"),
        ("RUN_PA" + "SS=2026-10-20T20", False, "an ISO date is never a credential"),
        ("pass" + "word=2026-10-20Qx9" + "kLm3pZ", True, "a value that only STARTS with a date is held"),
        ("db_pa" + "ss=2026-10-20-Zq8x" + "K3mWp9Rt", True, "a date prefix then a secret is held"),
        ("RUN_PA" + "SS=2026-10-20T20:15:00Z", False, "a full ISO date-time with zone is still never a credential"),
        ("only 2 pa" + "ss: EXMARKET-26O-1234", False, "`pass` in prose"),
        ("git fetch o fix/hub-api-" + "key-objects-319:refs/heads/x-319", False, "a name inside a refspec path"),
        ("PA" + "SS: " + _CFG_V, False, "a bare `pass` name is an English word, not a key word"),
        ("SEC" + 'RET_KEY_BASE = "' + _CFG_V + '"', True, "Rails name, quoted value"),
        ("SEC" + "RET_KEY_BASE = '" + _CFG_V + "'", True, "single-quoted value"),
        ("DB_PA" + 'SS_PROD = "' + _CFG_V + '"', True, "PASS as a whole segment before the end"),
        ("jwt_sec" + 'ret_salt = "' + _CFG_V + '"', True, "the key word, then a segment naming no noun"),
        ('"api_k' + 'ey_prod": "' + _CFG_V + '"', True, "JSON, the key word before the last segment"),
        ("sec" + 'ret_key_base: "' + _CFG_V + '"', True, "YAML, quoted"),
        ("sec" + 'ret_key_name = "SEC' + 'RET_KEY_BASE1"', True, "a literal with a digit holds whatever it says"),
        ("db_pa" + 'ss: "' + _CFG_V + '"', True, "the key word ending the name (old quoted branch)"),
        ('"client_sec' + 'ret_key": "' + _CFG_V + '"', True, "a noun ending the name (_NOUN_TAIL)"),
        ("pass" + 'word_hint = "at least 8 characters"', False, "a quoted sentence is not a literal"),
        ("sec" + 'ret_key_name = "SEC' + 'RET_KEY_BASE"', False, "a quoted value with no digit"),
        ("tok" + 'en_type = "bearer"', False, "a short quoted word"),
        ("pass" + '_through = "true"', False, "`pass` as the first segment, a short word value"),
        ("api_" + 'key_env = "${API' + '_KEY}"', False, "a quoted variable reference"),
        ('"tok' + 'en_url": "https://x/oauth"', False, "a quoted URL"),
        ("db_pa" + 'ss_rotated = "2026-10-20T20:00:00"', False, "a quoted ISO date"),
        ("sec" + 'ret_key_file = "/run/x/' + _CFG_V + '"', False, "a quoted file path"),
        ("sec" + "ret_key_file=/run/x/" + _CFG_V, False, "an unquoted file path"),
        ("SEC" + "RET_KEY_BASE=/" + _CFG_V, True, "a base64 literal opening with / is held"),
        ("API_TO" + "KEN=/aB3dE5gH7jK9" + "mN1pQ2rS", True, "a reported case: a base64 literal opening with /"),
        ("rep" + "assword=" + _CFG_V, True, "a deny-listed word that only STARTS the name"),
        ("TOK" + "EN=/run/x/9f86d081884c7d65" + "9a2f3aa0c55ad015-key", True,
         "a nix-looking <32>-<name> segment outside a store is a token"),
        ("tok" + "en_path=/gnu/store/9f86d081884c7d65" + "9a2feaa0c55ad015", False,
         "a segment directly under /gnu/store/ is a store path"),
        ("byp" + "assword=" + _CFG_V, True, "bypass + word is held"),
        ("outp" + "assword=" + _CFG_V, True, "outpass + word is held"),
        ("byp" + "ass_mode=" + _CFG_V, False, "the English word bypass, ended by _, still passes"),
        ("sec" + "ret_key_file=~/" + _CFG_V, False, "a home-relative path still passes"),
        ("sec" + "ret_key_file=/Applications/X.app/" + _CFG_V, False, "/Applications/ is a root"),
        ("tok" + "en_path=/nix/store/" + _CFG_V, False, "/nix/ is a root"),
        ("sec" + "ret_mount=/data/" + _CFG_V, False, "/data/ is a root"),
        ("sec" + 'ret_note = "' + _CFG_V + ' is the id"', False, "a quoted value with a space"),
        ("tok" + 'en_ttl = "' + _CFG_V + "'", False, "the closing quote must match the opening one"),
        ("passenger_" + 'id = "' + _CFG_V + '"', False, "`pass` inside a segment, quoted"),
        (kw + '_hint = "length"', False, "the key word NOT ending the name, in prose-like config"),
        (kw.upper() + "=", False, "an empty env value"),
        (kw + ': ""', False, "an empty quoted YAML value"),
        ("(:" + kw + ' "")', False, "an empty plist value"),
        ("TOK" + "EN=<TOK" + "EN>", False, "an angle-bracket placeholder"),
        ("(:tok" + 'en "<TOK' + 'EN>")', False, "a plist placeholder"),
        (kw + " = ${" + "DB_PASS}", False, "a variable reference"),
        (kw + " = args." + kw + "2", False, "a dotted attribute is code, not a value"),
        ("sec" + "ret=fenced=blocked_by=x0", False, "chained assignment in a one-liner"),
        ("max_tok" + "ens: 4096", False, "`s` after the key word is no separator, and the value has no letter"),
        (kw + ": changeme", False, "KNOWN GAP pinned: an unquoted value with no digit passes"),
    ]
    codes = [
        ("Your verification code is 482913", True, "the plain case"),
        ("G-482913 is your Google verification code.", True, "a lettered prefix"),
        ("Use 7731 to sign in. Do not share it.", True, "a 4-digit sign-in code"),
        ("Your security code: 123-456", True, "a dashed code"),
        ("Sample row at 7?", False, "no code, no cue"),
        (
            "Edition 2026 lists 1500 items",
            False,
            "a year and a price, NO cue: must not be withheld",
        ),
        ("The code sample is on page 3", False, "a cue word with no 4-8 digit token"),
        (
            '{"state": "Your verification code is 483920"}',
            True,
            "the code ENDS a JSON string: the hole",
        ),
        ("code=483920}", True, "followed by a brace"),
        ("your code is *483920*", True, "wrapped in something the old list never named"),
        (
            "order abc483920x, verify the address",
            False,
            "digits inside a word are not a standalone code",
        ),
        ("verify the 12-34 slot on the 3rd", False, "a dashed number too short to be a code"),
        (
            "verify: part 555-0142 ext 9",
            True,
            "a 4-digit run beside a cue holds: the floor fails toward holding",
        ),
        ("Sam, the box is on the left shelf by 4.", False, "an ordinary sentence with a small number, no cue"),
        (
            'id=1-0 chan=x msg="[app.example.decoder] note: lee says ok"',
            False,
            "a cue-word buried inside a longer bundle-style word, no digit run: not a code cue",
        ),
        (
            'id=1-0 chan=x msg="[app.example.decoder] note: lee says 4821 is fine"',
            False,
            "the same buried cue beside a 4-digit run: still not a code cue",
        ),
        (
            "we use barcode 4821 on the shelf",
            True,
            (
                "barcode ENDS in the cue, so it holds -- the floor fails toward holding "
                "and cannot be a judge"
            ),
        ),
        ("yourcode: 483920", True, "cue ending a word still holds"),
        ("authcode 483920", True, "authcode: cue ends the word, digits follow"),
        ("your verification code is 483920", True, "the ordinary shape still holds"),
        ("spin 4821 times", False, "the 'pin ' cue inside 'spin' is neither a start nor an end"),
        (
            json.dumps("your sign-in code is\n" + "482913"),
            True,
            "a code behind a JSON newline escape still holds",
        ),
        (
            json.dumps("code:\u00a0" + "482913"),
            True,
            "a code behind an escaped NBSP (\\u00a0) still holds",
        ),
        (
            json.dumps("code " + "\uff14\uff18\uff12\uff19\uff11\uff13"),
            True,
            "fullwidth digits escaped as \\uXXXX are still a 6-digit run",
        ),
        (
            json.dumps("verification\nemail sent, no digits"),
            False,
            "an escape with no code is not a code",
        ),
        (
            "path c:\\new\\table 2026",
            False,
            "backslash-n and backslash-t in a path with a year: no cue, no code",
        ),
        (
            json.dumps(json.dumps("your sign-in code is\n" + "482913")),
            True,
            "a code behind a DOUBLE-encoded newline still holds",
        ),
        (
            json.dumps(json.dumps(json.dumps("code:\t" + "482913"))),
            True,
            "triple-encoded tab: still a standalone run",
        ),
        (
            functools.reduce(lambda s, _i: json.dumps(s), range(5), "code is\n" + "482913"),
            True,
            "five layers: decoded within the bound and held",
        ),
        (
            functools.reduce(lambda s, _i: json.dumps(s), range(UNESCAPE_PASSES + 3), "code is\n" + "482913"),
            True,
            "past the bound: unsettled escapes beside a cue hold",
        ),
        (
            functools.reduce(lambda s, _i: json.dumps(s), range(UNESCAPE_PASSES + 3), "a path with\n no cue 2026"),
            True,
            "past the bound even with no visible cue: obfuscated past reading, held (the cue can be the escaped part)",
        ),
        (
            "your \\u0063ode is " + "482913",
            True,
            "an escaped cue word (\\u0063ode) decodes and holds",
        ),
        (
            functools.reduce(lambda s, _i: json.dumps(s), range(UNESCAPE_PASSES), "the code is\n" + "482913"),
            True,
            "decodes fully on exactly the last pass: the confirming pass marks it settled, and the code holds",
        ),
        (
            functools.reduce(lambda s, _i: json.dumps(s), range(UNESCAPE_PASSES), "verification\nemail, no digits"),
            False,
            "settled on exactly the last pass with a cue and no code: NOT held (the off-by-one held this)",
        ),
        (
            "plain text " + "\\" * (2**17) + " end",
            False,
            "a bare backslash run (2**17) past the bound with no cue, no digits, no \\u: NOT held",
        ),
        (
            "your \\u0043ode is " + "482913",
            True,
            "an UPPERCASE escaped cue letter (\\u0043ode) decodes before the lowercase cue test and holds",
        ),
    ]
    for text, want, why in codes:
        chk("CODE", "withhold" if want else "send", _held(text) is want and has_one_time_code(text) is want, why)
    for text, want, why in content:
        chk("CONTENT", "refuse" if want else "allow", has_secret_value(text) is want, why)
    sent = [t for t, w, _ in codes if not w] + [t for t, w, _ in content if not w]
    changed = [t for t in sent if redact(t) != (t, 0)]
    disagree = [why for t, _w, why in content if bool(redact(t)[1]) != bool(_held(t))]
    _tok = "gh" + "p_" + "A1b2C3d4" * 5 + "_tail-XYZ987"
    _pem = (
        "-----BEGIN RSA PRIV"
        + "ATE KEY-----\nMIIEow"
        + "Qk9" * 20
        + "\nZmFrZWtleWJvZHk"
        + "x7" * 12
        + "\n-----END RSA PRIV"
        + "ATE KEY-----"
    )
    _qv = "hun" + "ter2" + 'Zq"x"' + "rest-of-it"
    _qv2 = "hun" + "ter2" + "Zq'x" + " rEst Of-iT-sEcRet"
    planted = [
        (f"deploy note: token {_tok} then more words", _tok),
        (f"key file follows\n{_pem}\nand the README after", _pem),
        ("config: pass" + 'word = "' + _qv + '" end', _qv),
        ("config: pass" + 'word = "' + _qv2 + '" end', _qv2),
        ("printf 'K\\n" + _tok + "' > ~/.k", _tok),  # an escape written as text before the key
        ('{"t": "A\\\\n' + _tok + '"}', _tok),  # double-encoded
        ("echo -e 'X\\033" + _tok + "'", _tok),  # octal escape
        ("printf 'X\\a" + _tok + "'", _tok),  # any other one-letter escape
        ("s = 'X\\U0001F600" + _tok + "'", _tok),  # 8-digit unicode escape
        ("cfg (:" + "pass" + 'word "' + _CFG_V + '" :user "sam")', _CFG_V),
        ("cfg pass" + "word = " + _CFG_V + " tail", _CFG_V),
        ("cfg DB_PASS" + "WORD=" + _CFG_V + "\nNEXT=1", _CFG_V),
        ("cfg:\n  pass" + "word: " + _CFG_V + "\n  user: sam", _CFG_V),
        ("cfg <key>pass" + "word</key><string>" + _CFG_V + "</string> tail", _CFG_V),
        ("cfg AWS_SEC" + "RET_ACCESS_KEY=" + _CFG_V + "\nNEXT=1", _CFG_V),
        ("cfg SEC" + 'RET_KEY = "' + _CFG_V + '" tail', _CFG_V),
    ]

    def _fragments(secret, k=6):
        return {
            secret[i : i + k] for i in range(len(secret) - k + 1) if not secret[i : i + k].isspace()
        }

    _escapes = ["\\" + chr(c) for c in range(33, 127) if chr(c) != "\\"]
    _escapes += ["\\033", "\\0", "\\x1b", "\\u00e9", "\\U0001F600", "\\\\n", "\\\\\\\\t"]
    planted += [("X" + e + _tok + " tail", _tok) for e in _escapes]
    _aws = "AK" + "IA" + "Q3EGR7WZ5LXHJ2PN"
    planted += [("X\\" + w + _aws + " tail", _aws) for w in ("x", "u", "U")]
    for _f in ("%20", "%3D", "key%3D", "\x1b[0m", "\x1b[01;31m\x1b[K", "\\x1b[0m", "^M", "&#32", "0", "Z", "x"):
        planted += [("q" + _f + _k + " tail", _k) for _k in (_tok, _aws)]
    _r = "Ab1_cD-eF2"
    for _k in ("sk-proj-" + _r * 7 + "T3BlbkFJ" + _r * 7, "sk-svcacct-" + _r * 6 + "T3BlbkFJ" + _r * 6,
               "sk-admin-" + _r * 6 + "T3BlbkFJ" + _r * 6, "sk-" + "0123456789abcdef" * 2,
               "sk-or-v1-" + "0123456789abcdef" * 4):
        planted += [("x" + _k + " tail", _k), ("%20" + _k + " tail", _k)]
    for _p, _allowed, _minimum, _exact in _SHAPES:
        _k = _p + (("A1b" * 24) if _allowed is not _UPPER_DIGITS else ("Q3EGR7WZ5LXHJ2PN" * 3))  # >= every minimum (64)
        planted += [("x" + _k + " tail", _k), ("%20" + _k + " tail", _k)]
        if _allowed is not _UPPER_DIGITS and _p not in _WORD_END:  # and with NO digit (word-end prefixes need one)
            _k = _p + "AbcDef" * 12
            planted += [("x" + _k + " tail", _k)]
    planted += [("X\\" + w + "F" * d + _aws + " tail", _aws) for w, width in (("x", 2), ("u", 4), ("U", 8))
                for d in range(1, width)]
    leaked = [
        (s[:12], f)
        for t, s in planted
        for f in sorted(_fragments(s))
        if f in redact(t)[0] and f.strip("-")
    ]
    kept_words = all(
        w in redact(t)[0]
        for t, w in ((planted[0][0], "deploy note"), (planted[1][0], "README after"))
    )
    for name, ok, why in (
        (
            "redact-leaves-no-fragment-of-a-planted-secret",
            not leaked and kept_words,
            (
                f"{len(planted)} planted secrets (token with a tail, PEM with a body, quoted value with an inner "
                f"quote, key after an escape written as text, single and double encoded): leaked {leaked[:3]}"
            ),
        ),
        (
            "redact-leaves-sent-untouched",
            not changed,
            f"{len(sent)} sent texts unchanged: {changed[:2]}",
        ),
        (
            "floor-and-redact-agree",
            not disagree,
            f"{len(content)} content texts: redact cuts exactly where the floor holds: {disagree[:3]}",
        ),
        (
            "redact-keeps-the-words",
            redact("your verification code is 483920") == ("your verification code is <num>", 1),
            "only the run is cut",
        ),
        (
            "redact-keeps-words-after-a-token",
            redact(f"facts: token {_tok} seen") == ("facts: token <secret> seen", 1)
            and redact(f"q%20{_aws} then more")[0].endswith(" then more"),
            "a bare token is cut to its own end, not its line's",
        ),
        (
            "redact-machine-row",
            redact("login hook pid 48215 at line 1234")[0] == "login hook pid <num> at line <num>",
            "the meaning survives",
        ),
        (
            "redact-clears-a-long-dash-chain",
            not has_one_time_code(redact("exit code 9 === 20261103-94827")[0])
            and not has_one_time_code(redact("code == 20261103-948271-<num>")[0])
            and redact("your code is 123-456")[0] == "your code is <num>",
            "what redact returns, the floor lets through; a 6-digit dashed code stays one mask",
        ),
        (
            "space-pair-code-is-a-code",
            redact("your verification code is 482 913") == ("your verification code is <num>", 1)
            and has_one_time_code("your verification code is 482 913")
            and redact("your code: 1234 5678")[0] == "your code: <num>",
            "the floor and the masker read a space-grouped code alike",
        ),
        (
            "space-pair-near-misses",
            redact("code changed at=09-30 23:48:30")[0] == "code changed at=09-30 23:48:30"
            and not has_one_time_code("code changed at=09-30 23:48:30")
            and redact("your code is 482 913 777")[0] == "your code is 482 913 777"
            and redact("your code is 48 29")[0] == "your code is 48 29"
            and redact("your code is 482  913")[0] == "your code is 482  913",
            "a stamp, a longer chain, short groups and a double space are not a code",
        ),
        (
            "space-pair-ref-token-and-label-colon",
            redact("your verification code is ref1 482 913")[0] == "your verification code is ref1 <num>"
            and has_one_time_code("your verification code is ref1 482 913")
            and redact("your code:482 913")[0] == "your code:<num>" and has_one_time_code("your code:482 913")
            and redact("code is 1 482 913")[0] == "code is 1 482 913"
            and not has_one_time_code("code 482 913:45"),
            "a word token or a label colon beside the pair keeps it a code; a digit chain or a clock does not",
        ),
    ):
        chk("REDACT", name, ok, why)
    p_held, p_safe = property_cases()
    held_fail, safe_fail = property_failures(p_held, p_safe)
    cells = {lab for lab, _t, _v in p_held}
    n_held_bad = len({t for xs in held_fail.values() for t, _v in xs})
    all_cells = len(P_HELD_KINDS) * len(P_SHAPES) * len(P_SYNTAX)
    for name, ok, why in (
        (
            "prop-held-and-cut",
            not held_fail and len(cells) == all_cells,
            (
                f"{len(p_held) - n_held_bad}/{len(p_held)} generated credentials held and cut whole, cells "
                f"{len(cells)}/{all_cells} (value kind x name shape x syntax)"
            ),
        ),
        (
            "prop-safe-passes",
            not safe_fail,
            (
                f"{len(p_safe) - sum(len(xs) for xs in safe_fail.values())}/{len(p_safe)} generated non-credentials "
                "passed (a name ending in bypass/compass/surpass before a quoted literal included)"
            ),
        ),
    ):
        chk("PROP", name, ok, why)
    by_class: dict[tuple, list] = {}
    for lab, xs in held_fail.items():
        by_class.setdefault((lab[0], lab[1], lab[3]), []).extend(xs)
    x_held, x_safe = property_cases_syntax()
    x_held_fail, x_safe_fail = property_failures(x_held, x_safe)
    x_cells = {lab for lab, _t, _v in x_held}
    x_held_bad = len({t for xs in x_held_fail.values() for t, _v in xs})
    x_safe_bad = sum(len(xs) for xs in x_safe_fail.values())
    for name, ok, why in (
        (
            "prop-syntax-held-and-cut",
            not x_held_fail and len(x_cells) == property_syntax_cells(),
            (
                f"{len(x_held) - x_held_bad}/{len(x_held)} generated credentials held and cut whole, cells "
                f"{len(x_cells)}/{property_syntax_cells()} (URL userinfo, --flag, -p, camelCase, ruby =>)"
            ),
        ),
        (
            "prop-syntax-near-misses-pass",
            not x_safe_fail,
            f"{len(x_safe) - x_safe_bad}/{len(x_safe)} near-misses passed (port, user@host, --x-file=<path>, -p 8080)",
        ),
    ):
        chk("PROP", name, ok, why)
    for lab, xs in x_held_fail.items():
        by_class.setdefault((lab[0], lab[1], lab[3]), []).extend(xs)
    q_held, q_safe = property_cases_paths()
    q_held_fail, q_safe_fail = property_failures(q_held, q_safe)
    q_cells = {lab[0::2] for lab, _t, _v in q_held}
    q_held_bad = len({t for xs in q_held_fail.values() for t, _v in xs})
    q_safe_bad = sum(len(xs) for xs in q_safe_fail.values())
    for name, ok, why in (
        (
            "prop-path-cred-held-and-cut",
            not q_held_fail and len(q_cells) == len(P_PATH_HELD) * len(P_SYNTAX),
            (
                f"{len(q_held) - q_held_bad}/{len(q_held)} credentials opening with / held and cut whole, cells "
                f"{len(q_cells)}/{len(P_PATH_HELD) * len(P_SYNTAX)} (/<root>/<cred>, base64 with several /)"
            ),
        ),
        (
            "prop-path-real-paths-pass",
            not q_safe_fail,
            f"{len(q_safe) - q_safe_bad}/{len(q_safe)} real paths passed (/sys/, /run/secrets/, ~/.ssh/, /nix/store/)",
        ),
    ):
        chk("PROP", name, ok, why)
    rq = random.Random(9164)
    pool = [v for _l, _t, v in q_held + q_safe] + [_p_path_safe_value(rq, k) for k in P_PATH_SAFE for _ in range(50)]
    raw = [("/" + _p_mixed(rq, _P_LOW + _P_UP + _P_DIG + "+/", rq.randint(7, 63))) for _ in range(4000)]
    pool += raw + ["~/" + _p_mixed(rq, _P_LOW + _P_DIG, 6), "/a/", "//x/y", "/x//y", "~/", "/run/x/y=="]
    disagree = [v for v in pool if bool(PATH_VALUE.fullmatch(v)) != _p_path_shaped(v)]
    ambiguous = sum(_p_path_shaped(v) for v in raw)
    _cred = "aB3dE5gH7jK9" + "mN1pQ2rS"
    pinned = [
        ("API_TO" + "KEN=/src/" + _cred, True, "a credential opening with a root word"),
        ("API_TO" + "KEN=/app/x/" + _cred, True, "a credential-shaped segment deeper under a root"),
        ("API_TO" + "KEN=/" + _cred + "/ab", True, "a credential-shaped FIRST segment, short tail: still held"),
        ("sec" + "ret_key_file=/sys/class/" + _CFG_V, False, "/sys/ is a path"),
        ("TOK" + "EN_FILE=~/" + _CFG_V, False, "`~/` and one short segment: a path (base64 never opens with ~)"),
        ("TOK" + "EN_FILE=~/" + _cred, True, "`~/` and a credential-shaped segment: held"),
        ("TOK" + "EN=/" + _CFG_V, True, "one segment after `/`: base64 opens so, judged as a literal"),
        ("TOK" + "EN=/run/x/" + _CFG_V + "==", True, "base64 padding after a path-like run: held"),
        ("TOK" + "EN=/xY7k/Ab3Cd9EfG/Qp2z", True, "base64 with short segments, a first segment that is no word: held"),
        ("TOK" + "EN_FILE=/lib64/x/" + _CFG_V, False, "a first segment ending in digits is still a word"),
        ("TOK" + "EN_FILE=/Volumes/x/" + _CFG_V, False, "a Capitalised first segment is a word"),
        ("TOK" + "EN=/abQ/x9Kd/" + _CFG_V, True, "a first segment with a capital inside is no word: held"),
        ("TOK" + "EN=/a/b/" + "3f9a" * 10, True, "a lowercase hex tail after /a/b/ is held"),
        ("API_TO" + "KEN=/src/x/" + "3f9a" * 10, True, "the same under a root word"),
        ("API_TO" + "KEN=/ab/cd/" + "qwertyuiopasdfghjklzxcvbnm", False,
         "case 3 is the no-digit gap, not the path rule: with no path it passes too"),
        ("TOK" + "EN=/run/x/" + "9f86d081-884c-7d65-9a2f-eaa0c55ad015", True, "a uuid segment is held (a uuid is a key)"),
        ("TOK" + "EN_FILE=/nix/store/" + "0c2p1vab" * 4 + "-python3-3", False, "a nix store path passes"),
        ("TOK" + "EN_FILE=/var/lib/docker/overlay2/" + "3f9a" * 16 + "/diff", False, "a docker layer passes"),
    ]
    p_wrong = [why for text, want, why in pinned if _held(text) != want or has_secret_value(text) != want]
    for name, ok, why in (
        (
            "path-shape-two-instruments-agree",
            not disagree,
            f"{len(pool) - len(disagree)}/{len(pool)} values: PATH_VALUE regex == _p_path_shaped {disagree[:2]}",
        ),
        (
            "path-pinned-cases",
            not p_wrong,
            f"{len(pinned) - len(p_wrong)}/{len(pinned)} pinned (reported cases, ~/, padding, hex tail, uuid, stores) {p_wrong[:2]}",
        ),
        (
            "path-base64-ambiguity-under-1pct",
            ambiguous * 100 <= len(raw),
            f"COST: {ambiguous}/{len(raw)} random base64 values opening with / read as a path (released by shape)",
        ),
    ):
        chk("PROP", name, ok, why)
    for lab, xs in q_held_fail.items():
        by_class.setdefault((lab[0], lab[1], lab[3]), []).extend(xs)
    u_held, u_safe = property_cases_pathrun()
    u_held_fail, u_safe_fail = property_failures(u_held, u_safe)
    u_cells = {lab[0::2] for lab, _t, _v in u_held}
    u_held_bad = len({t for xs in u_held_fail.values() for t, _v in xs})
    u_safe_bad = sum(len(xs) for xs in u_safe_fail.values())
    u_vals = [v for _l, _t, v in u_held + u_safe]
    u_disagree = [v for v in u_vals if bool(PATH_VALUE.fullmatch(v)) != _p_path_shaped(v)]
    for name, ok, why in (
        (
            "prop-pathrun-held-and-cut",
            not u_held_fail and len(u_cells) == len(P_PRUN_HELD) * len(P_SYNTAX),
            (
                f"{len(u_held) - u_held_bad}/{len(u_held)} single-case tokens under /<root>/ held and cut whole, cells "
                f"{len(u_cells)}/{len(P_PRUN_HELD) * len(P_SYNTAX)} (hex, lowercase+digits, UPPER, uuid)"
            ),
        ),
        (
            "prop-pathrun-store-paths-pass",
            not u_safe_fail,
            (
                f"{len(u_safe) - u_safe_bad}/{len(u_safe)} store paths and boundaries passed (nix, gnu, docker, git, "
                f"/var/folders/, hex-15, 3 digits) {sorted({lab[0] for lab in u_safe_fail})[:4]}"
            ),
        ),
        (
            "pathrun-two-instruments-agree",
            not u_disagree,
            f"{len(u_vals) - len(u_disagree)}/{len(u_vals)} values: PATH_VALUE regex == _p_path_shaped {u_disagree[:2]}",
        ),
    ):
        chk("PROP", name, ok, why)
    for lab, xs in u_held_fail.items():
        by_class.setdefault((lab[0], lab[1], lab[3]), []).extend(xs)
    t_held, t_safe = property_cases_tail()
    t_held_fail, t_safe_fail = property_failures(t_held, t_safe)
    t_cells = {lab for lab, _t, _v in t_held}
    t_held_bad = len({t for xs in t_held_fail.values() for t, _v in xs})
    t_safe_bad = sum(len(xs) for xs in t_safe_fail.values())
    for name, ok, why in (
        (
            "prop-tail-held-and-cut",
            not t_held_fail and len(t_cells) == property_tail_cells(),
            (
                f"{len(t_held) - t_held_bad}/{len(t_held)} generated credentials held and cut whole, cells "
                f"{len(t_cells)}/{property_tail_cells()} (PascalCase, ARGS=--<name>=, glued *pass)"
            ),
        ),
        (
            "prop-tail-near-misses-pass",
            not t_safe_fail,
            f"{len(t_safe) - t_safe_bad}/{len(t_safe)} near-misses passed (PasswordHint, ARGS=--verbose, bypass)",
        ),
    ):
        chk("PROP", name, ok, why)
    for lab, xs in t_held_fail.items():
        by_class.setdefault((lab[0], lab[1], lab[3]), []).extend(xs)
    rows = [
        f"      held FAIL {len(xs):>4} {k}  e.g. " + ", ".join(f"<{len(v)} chars masked>" for _t, v in xs[:2])
        for k, xs in sorted(by_class.items(), key=lambda kv: -len(kv[1]))
    ]
    rows += [
        f"      safe FAIL {len(xs):>4} {lab}  e.g. " + ", ".join(repr(v) for _t, v in xs[:2])
        for lab, xs in sorted({**safe_fail, **x_safe_fail, **q_safe_fail, **t_safe_fail}.items(), key=lambda kv: -len(kv[1]))
    ]
    for line in rows[:12]:
        print(line)
    if len(rows) > 12:
        print(f"      ... {len(rows) - 12} more failing classes")
    good = sum(results)
    print(f"key_shapes_lib --selftest RESULT: {'PASS' if good == len(results) else 'FAIL'} -- {good}/{len(results)}")
    return 0 if good == len(results) else 1


if __name__ == "__main__":
    sys.exit(selftest() if "--selftest" in sys.argv else 0)
