""

import json
import os

HERE = os.path.dirname(os.path.realpath(__file__))
CATALOG = os.path.join(HERE, "claude-idioms.json")
KINDS = ("send", "insert", "key", "open")
KEYS = ("escape", "backtab")


def frontmatter(path):
    ""
    name, desc = os.path.basename(path)[: -len(".md")], ""
    with open(path, encoding="utf-8", errors="replace") as fh:
        lines = fh.read(8000).split("\n")
    if lines and lines[0].strip() == "---":
        for line in lines[1:]:
            if line.strip() == "---":
                break
            key, sep, val = line.partition(":")
            if sep and key.strip() == "name":
                name = val.strip() or name
            elif sep and key.strip() == "description":
                desc = val.strip()
    return name, desc


def agent_dirs(project, home):
    ""
    dirs = [os.path.join(project, ".claude", "agents")] if project else []
    dirs.append(os.path.join(home, ".claude", "agents"))
    out = []
    for d in dirs:
        r = os.path.realpath(d)
        if os.path.isdir(r) and r not in out:
            out.append(r)
    return out


def agents(project, home):
    ""
    seen, items = set(), []
    for d in agent_dirs(project, home):
        for f in sorted(os.listdir(d)):
            if not f.endswith(".md"):
                continue
            name, desc = frontmatter(os.path.join(d, f))
            if name in seen:
                continue
            seen.add(name)
            items.append({"name": name, "what": desc, "kind": "insert", "arg": f"Use the {name} agent to "})
    return items


def validate(doc):
    ""
    bad = []
    for g in doc.get("groups", []):
        for it in g.get("items", []):
            if len(it) != 4 or it[2] not in KINDS:
                bad.append(f"{g.get('group')}: {it!r}")
            elif it[2] == "key" and it[3] not in KEYS:
                bad.append(f"{g.get('group')}: unknown key {it[3]!r}")
    return bad


def resolve(project=None, home=None, catalog=CATALOG):
    home = home or os.path.expanduser("~")
    with open(catalog, encoding="utf-8") as fh:
        doc = json.load(fh)
    bad = validate(doc)
    if bad:
        raise ValueError("claude-idioms.json: " + "; ".join(bad))
    groups = []
    for g in doc["groups"]:
        items = agents(project, home) if g.get("agents") else []
        items += [dict(zip(("name", "what", "kind", "arg"), it)) for it in g["items"]]
        groups.append({"group": g["group"], "items": items})
    return {"project": project, "groups": groups}


def selftest():
    import tempfile

    cases = []

    def ck(n, got, want):
        cases.append((n, got == want, got, want))

    with tempfile.TemporaryDirectory() as t:
        proj, home = os.path.join(t, "p"), os.path.join(t, "h")
        for d in (os.path.join(proj, ".claude", "agents"), os.path.join(home, ".claude", "agents")):
            os.makedirs(d)
        with open(os.path.join(proj, ".claude", "agents", "rev.md"), "w") as fh:
            fh.write("---\nname: reviewer\ndescription: reviews: carefully\n---\nbody name: not-this\n")
        with open(os.path.join(home, ".claude", "agents", "a.md"), "w") as fh:
            fh.write("---\nname: reviewer\ndescription: user copy\n---\n")
        with open(os.path.join(home, ".claude", "agents", "b.md"), "w") as fh:
            fh.write("no frontmatter at all\n")
        with open(os.path.join(home, ".claude", "agents", "notes.txt"), "w") as fh:
            fh.write("ignored")
        r = resolve(proj, home)
        ag = next(g for g in r["groups"] if g["group"] == "Agents")["items"]
        ck("project agent first, description keeps its colon", ag[0], {"name": "reviewer", "what": "reviews: carefully",
           "kind": "insert", "arg": "Use the reviewer agent to "})
        ck("same-named user agent is shadowed; no-frontmatter file named by file", [a["name"] for a in ag[:-1]],
           ["reviewer", "b"])
        ck("catalog items follow the agents", ag[-1]["arg"], "/agents")
        ck("no project: user agents only", [a["name"] for a in resolve(None, home)["groups"][3]["items"][:-1]],
           ["reviewer", "b"])
        bad = os.path.join(t, "bad.json")
        with open(bad, "w") as fh:
            json.dump({"groups": [{"group": "G", "items": [["x", "y", "key", "f1"], ["z", "w", "launch", "q"]]}]}, fh)
        try:
            resolve(proj, home, bad)
            ck("a bad catalog refuses", "no error", "ValueError")
        except ValueError as e:
            ck("a bad catalog refuses, naming both problems", ("f1" in str(e), "launch" in str(e)), (True, True))
    real = resolve(None, os.path.join(os.sep, "nonexistent"))
    ck("the shipped catalog is sound and has the six groups", [g["group"] for g in real["groups"]],
       ["Conversation", "Model & permissions", "Project", "Agents", "Extend", "Help"])
    failed = [c for c in cases if not c[1]]
    for n, ok, got, want in cases:
        print(("ok   " if ok else "FAIL ") + n + ("" if ok else f"  got {got!r} want {want!r}"))
    print(f"claude_idioms --selftest RESULT: {'FAIL' if failed else 'PASS'} -- {len(cases) - len(failed)}/{len(cases)} cases")
    return 1 if failed else 0


if __name__ == "__main__":
    import sys

    sys.exit(selftest() if "--selftest" in sys.argv else (print(json.dumps(resolve(os.getcwd()), indent=1)) or 0))
