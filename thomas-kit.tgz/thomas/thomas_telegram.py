""

import json
import os
import secrets
import sys
import urllib.error
import urllib.request

CONF = os.path.expanduser("~/.thomas/telegram.json")
API = os.environ.get("THOMAS_TELEGRAM_API", "https://api.telegram.org")
LIMIT = 4000  # Telegram refuses a message over 4096 characters
MAX_WRONG = 5
PRIVATE = "This assistant is private. Its owner pairs it from their own computer."


def new_code():
    return f"{secrets.randbelow(10**6):06d}"


def decide(update, owner, code):
    ""
    m0 = update.get("message") if isinstance(update, dict) else None
    msg: dict = m0 if isinstance(m0, dict) else {}
    c0 = msg.get("chat")
    chat: dict = c0 if isinstance(c0, dict) else {}
    raw = msg.get("text")
    text = raw.strip() if isinstance(raw, str) else ""
    cid = chat.get("id")
    if cid is None or chat.get("type") != "private" or not text:
        return ("ignore", cid, "")
    if owner is None:
        parts = text.split()
        if parts and parts[0] == "/pair":
            if code and len(parts) == 2 and parts[1] == code:
                return ("pair", cid, "Paired. This chat now talks to your assistant; nobody else's can.")
            if not code:
                return ("wrong-code", cid, "Pairing is closed. Its owner can reopen it from their own computer.")
            return ("wrong-code", cid, "That code does not match. Check the code in your terminal.")
        return ("refuse", cid, PRIVATE)
    if cid != owner:
        return ("refuse", cid, PRIVATE)
    if text in ("/start", "/help"):
        return ("reply", cid, "Send a message and your assistant answers here. It remembers the conversation.")
    return ("turn", cid, text)


def chunks(text, n=LIMIT):
    ""
    text = text or "(no reply)"
    out = []
    while len(text) > n:
        cut = text.rfind("\n", n // 2, n)
        cut = n if cut < 0 else cut
        out.append(text[:cut])
        text = text[cut:].lstrip("\n")
    out.append(text)
    return out


def load_conf(path=CONF):
    try:
        with open(path) as fh:
            c = json.load(fh)
        return c if isinstance(c, dict) else {}
    except (OSError, ValueError):
        return {}


def save_conf(conf, path=CONF):
    ""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        json.dump(conf, fh)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def http(token, method, params, timeout=70):
    ""
    req = urllib.request.Request(
        f"{API}/bot{token}/{method}",
        data=json.dumps(params).encode(),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"telegram {method}: HTTP {e.code}") from None
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise RuntimeError(f"telegram {method}: {type(e).__name__}") from None


def poll_once(conf, state, call, turn, save, say=print, wait=50):
    ""
    got = call("getUpdates", {"offset": conf.get("offset", 0), "timeout": wait, "allowed_updates": ["message"]})
    ups = got.get("result") or [] if isinstance(got, dict) else []
    for u in ups:
        uid = u.get("update_id") if isinstance(u, dict) else None
        if isinstance(uid, int):
            conf["offset"] = uid + 1
        save(conf)  # BEFORE acting: a crash then drops this message rather than answering it twice
        action, cid, text = decide(u, conf.get("owner"), state.get("code"))
        if action == "ignore":
            continue
        if action == "pair":
            conf["owner"] = cid
            save(conf)
            state["code"] = None
            say("Paired with your Telegram chat. Messages from any other chat are refused.")
        elif action == "wrong-code":
            state["wrong"] = state.get("wrong", 0) + 1
            if state["wrong"] >= MAX_WRONG and state.get("code"):
                state["code"] = None
                say(f"Pairing closed after {MAX_WRONG} wrong codes. Run `thomas telegram run` again for a new code.")
        elif action == "turn":
            call("sendChatAction", {"chat_id": cid, "action": "typing"})
            text = turn(text)
        for piece in chunks(text):
            call("sendMessage", {"chat_id": cid, "text": piece})
    return len(ups)


LABEL = "ai.thomas.telegram"
SERVICE_ENV = "THOMAS_TELEGRAM_SERVICE"
LOG = os.path.expanduser("~/.thomas/telegram.log")


def service_files(thomas_path, home, system, path_env):
    ""
    log = os.path.join(home, ".thomas", "telegram.log")
    if system == "Darwin":
        from xml.sax.saxutils import escape

        args = "".join(f"<string>{escape(a)}</string>" for a in (thomas_path, "telegram", "run"))
        plist = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            '<plist version="1.0"><dict>'
            f"<key>Label</key><string>{LABEL}</string>"
            f"<key>ProgramArguments</key><array>{args}</array>"
            "<key>RunAtLoad</key><true/><key>KeepAlive</key><true/><key>ThrottleInterval</key><integer>30</integer>"
            f"<key>EnvironmentVariables</key><dict><key>PATH</key><string>{escape(path_env)}</string>"
            f"<key>{SERVICE_ENV}</key><string>1</string></dict>"
            f"<key>StandardOutPath</key><string>{escape(log)}</string>"
            f"<key>StandardErrorPath</key><string>{escape(log)}</string>"
            "</dict></plist>\n"
        )
        return [(os.path.join(home, "Library", "LaunchAgents", LABEL + ".plist"), plist)]
    def pct(s):  # systemd expands % specifiers in these values; a literal % must be %%
        return s.replace("%", "%%")

    unit = (
        "[Unit]\nDescription=Thomas Telegram channel\n\n"
        f'[Service]\nExecStart="{pct(thomas_path)}" telegram run\nRestart=always\nRestartSec=30\n'
        f'Environment="PATH={pct(path_env)}" "{SERVICE_ENV}=1"\nStandardOutput=append:{pct(log)}\nStandardError=append:{pct(log)}\n\n'
        "[Install]\nWantedBy=default.target\n"
    )
    return [(os.path.join(home, ".config", "systemd", "user", "thomas-telegram.service"), unit)]


def service_commands(system, uid, path, start):
    ""
    if system == "Darwin":
        stop = (["launchctl", "bootout", f"gui/{uid}/{LABEL}"], False)
        return [stop, (["launchctl", "bootstrap", f"gui/{uid}", path], True)] if start else [stop]
    if start:
        return [(["systemctl", "--user", "daemon-reload"], True),
                (["systemctl", "--user", "enable", "thomas-telegram"], True),
                (["systemctl", "--user", "restart", "thomas-telegram"], True)]
    return [(["systemctl", "--user", "disable", "--now", "thomas-telegram"], False)]


def service_probe(system, uid):
    ""
    if system == "Darwin":
        return ["launchctl", "print", f"gui/{uid}/{LABEL}"]
    return ["systemctl", "--user", "is-active", "--quiet", "thomas-telegram"]


def service_running(system, uid, _run=None):
    ""
    import subprocess

    try:
        return (_run or subprocess.run)(service_probe(system, uid), capture_output=True, check=False).returncode == 0
    except OSError:
        return False


def selftest():
    import tempfile

    cases = []

    def ck(n, got, want):
        cases.append((n, got == want, got))

    def up(i, cid, text, kind="private"):
        return {"update_id": i, "message": {"chat": {"id": cid, "type": kind}, "text": text}}

    ck("stranger-before-pairing-refused", decide(up(1, 7, "hi"), None, "123456")[0], "refuse")
    ck("right-code-pairs", decide(up(1, 7, "/pair 123456"), None, "123456")[:2], ("pair", 7))
    ck("wrong-code-is-wrong", decide(up(1, 7, "/pair 000000"), None, "123456")[0], "wrong-code")
    ck("no-code-cannot-pair", decide(up(1, 7, "/pair "), None, None)[0], "wrong-code")
    ck("pair-with-extra-words-refused", decide(up(1, 7, "/pair 123456 x"), None, "123456")[0], "wrong-code")
    ck("owner-message-is-a-turn", decide(up(1, 7, "what's up"), 7, None), ("turn", 7, "what's up"))
    ck("other-chat-after-pairing-refused", decide(up(1, 8, "what's up"), 7, None)[0], "refuse")
    ck("group-ignored-even-from-owner-id", decide(up(1, 7, "hi", "group"), 7, None)[0], "ignore")
    ck("no-text-ignored", decide({"update_id": 1, "message": {"chat": {"id": 7, "type": "private"}}}, 7, None)[0],
       "ignore")
    ck("chunks-fit", [len(c) <= LIMIT for c in chunks("x" * 9000)], [True, True, True])
    ck("chunks-keep-everything", "".join(chunks("y" * 9000)), "y" * 9000)
    ck("chunks-empty-says-so", chunks(""), ["(no reply)"])

    sent, turns = [], []
    script = [[up(10, 8, "hello")], [up(11, 7, "/pair 111111")], [up(12, 7, "remember tea")], [up(13, 8, "hi")]]

    def call(method, params):
        if method == "getUpdates":
            return {"ok": True, "result": script.pop(0) if script else []}
        sent.append((method, params.get("chat_id"), params.get("text")))
        return {"ok": True}

    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "t", "telegram.json")
        conf, state = {"token": "T"}, {"code": "111111"}

        def save(c):
            save_conf(c, path)

        def turn(t):
            turns.append(t)
            return "ok: " + t

        for _ in range(4):
            poll_once(conf, state, call, turn, save, say=lambda *_: None)
        texts = [(m, c, t) for m, c, t in sent if m == "sendMessage"]
        ck("loop-stranger-refused-paired-turned-stranger-refused",
           [(c, t.split(".")[0]) for _m, c, t in texts],
           [(8, PRIVATE.split(".")[0]), (7, "Paired"), (7, "ok: remember tea"), (8, PRIVATE.split(".")[0])])
        ck("loop-only-the-owner-reached-the-brain", turns, ["remember tea"])
        ck("loop-offset-past-last-update", load_conf(path).get("offset"), 14)
        ck("loop-owner-saved", load_conf(path).get("owner"), 7)
        ck("conf-file-owner-only", oct(os.stat(path).st_mode & 0o777), "0o600")

        st2 = {"code": "222222"}
        script[:] = [[up(20 + i, 9, "/pair 000000")] for i in range(MAX_WRONG)] + [[up(30, 7, "/pair 222222")]]
        c2 = {"token": "T"}
        for _ in range(MAX_WRONG + 1):
            poll_once(c2, st2, call, turn, lambda c: None, say=lambda *_: None)
        ck("five-wrong-codes-close-pairing-even-the-right-code-then-fails",
           (st2["code"], c2.get("owner")), (None, None))

    import plistlib

    (pp, pt), = service_files("/h/My Kit/thomas", "/h", "Darwin", "/usr/bin:/bin")
    pl = plistlib.loads(pt.encode())
    ck("launchagent-parses-and-runs-the-kit",
       (pp, pl["Label"], pl["ProgramArguments"], pl["KeepAlive"], pl["EnvironmentVariables"]),
       ("/h/Library/LaunchAgents/ai.thomas.telegram.plist", LABEL, ["/h/My Kit/thomas", "telegram", "run"], True,
        {"PATH": "/usr/bin:/bin", SERVICE_ENV: "1"}))
    (up_, ut), = service_files("/h/kit/thomas", "/h", "Linux", "/usr/bin")
    ck("systemd-unit-runs-the-kit", (up_.endswith("systemd/user/thomas-telegram.service"),
                                     'ExecStart="/h/kit/thomas" telegram run' in ut, "Restart=always" in ut), (True,) * 3)
    ck("mac-start-stops-any-loaded-copy-first",
       (service_commands("Darwin", 501, "/p", True), service_commands("Darwin", 501, "/p", False)),
       ([(["launchctl", "bootout", "gui/501/" + LABEL], False), (["launchctl", "bootstrap", "gui/501", "/p"], True)],
        [(["launchctl", "bootout", "gui/501/" + LABEL], False)]))
    (_pp, pu), = service_files("/h/100%/thomas", "/h", "Linux", "/a%b")
    ck("systemd-percent-escaped", ('"/h/100%%/thomas"' in pu, "PATH=/a%%b" in pu), (True, True))
    ck("systemd-marks-the-service", f'"{SERVICE_ENV}=1"' in pu, True)

    def _missing(*a, **k):
        raise FileNotFoundError("systemctl")

    ck("no-service-manager-means-not-running", service_running("Linux", 0, _run=_missing), False)
    ck("odd-shapes-ignored-not-crash", [decide(x, 7, None)[0] for x in (
        5, None, {"message": 3}, {"message": {"chat": {"id": 7, "type": "private"}, "text": 9}},
        {"message": {"chat": "x", "text": "hi"}})], ["ignore"] * 5)
    ck("closed-pairing-says-so", decide(up(1, 7, "/pair 123456"), None, None)[2].startswith("Pairing is closed"), True)
    ck("probes-name-the-service", (service_probe("Darwin", 501)[-1], service_probe("Linux", 0)[-1]),
       ("gui/501/" + LABEL, "thomas-telegram"))
    bad = sum(not ok for _n, ok, _g in cases)
    for n, ok, got in cases:
        print(f"  {n:<52} {'PASS' if ok else 'FAIL'}" + ("" if ok else f"  got {got!r}"))
    print("\nthomas_telegram --selftest RESULT: " + (f"FAIL -- {bad} case(s)" if bad else f"PASS -- {len(cases)} cases"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(selftest() if "--selftest" in sys.argv else 2)
