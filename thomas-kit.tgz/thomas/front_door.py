#!/usr/bin/env python3
""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
from front_door_usage import USAGE, help_only  # the sibling needs the path line above

ENTRY = os.path.join(os.path.dirname(os.path.realpath(__file__)), "thomas")  # the launcher a user runs

if __name__ == "__main__" and help_only(sys.argv):
    print(USAGE)
    sys.exit(0)

if sys.flags.no_site and "site" not in sys.modules:
    import site

    site.main()

import json
import shlex
import shutil
import subprocess

_KIT = os.path.dirname(os.path.realpath(__file__))
os.environ["PATH"] = os.pathsep.join(
    [
        os.path.join(_KIT, "adapter", "node_modules", ".bin"),
        os.path.join(_KIT, "node", "bin"),
        os.environ.get("PATH", ""),
    ]
)
import acp_lib
import sexpr_lib
import thomas_config

PERSONA_KEYS = (":name", ":pronouns", ":voice", ":personality", ":image")

ADAPTER_FIX = {
    "claude-agent-acp": "run install.sh in the Thomas folder again: it installs the adapter there (no admin rights)",
    "codex-acp": "npm install -g @agentclientprotocol/codex-acp   then run `codex login`",
    "gemini": "npm install -g @google/gemini-cli   then run `gemini` once to log in",
}


def doctor_checks(f):
    ""
    out = []
    py = f.get("py") or (0, 0)
    out.append((py >= (3, 10), f"python {py[0]}.{py[1]}", "install Python 3.10 or newer"))
    out.append(
        (
            bool(f.get("redis_mod")),
            "the redis package for Python",
            "run install.sh in the Thomas folder: it makes a private .venv beside thomas with redis in it",
        )
    )
    out.append(
        (
            bool(f.get("config")),
            "the shipped defaults (thomas.sexpr)",
            "keep thomas.sexpr next to the thomas script",
        )
    )
    chosen = f.get("chosen")
    out.append(
        (
            chosen in (f.get("agents") or ()),
            f"a chosen brain ({chosen or 'none'})",
            "set one in ~/.thomas/thomas.sexpr: (brain :kind claude)",
        )
    )
    if chosen == FREE:
        out.append(
            (
                bool(f.get("free_ready", True)),
                "a free OpenRouter key and model list",
                f.get("free_key_problem") or "run `thomas login --free` -- it explains how to get a free key from openrouter.ai/keys",
            )
        )
    adapter = f.get("adapter")
    if adapter:
        out.append(
            (
                bool(f.get("adapter_on_path")),
                f"the {adapter} adapter",
                ADAPTER_FIX.get(adapter, f"install {adapter}"),
            )
        )
        if adapter == "claude-agent-acp":
            node = f.get("node")
            out.append(
                (
                    node is not None and node >= 22,
                    f"Node {node if node is not None else 'not found'} (the claude adapter needs 22+)",
                    ("run install.sh in the Thomas folder again: it fetches Node 22 into that folder (no admin rights)."
                     " On a platform with no Node 22 build (e.g. 32-bit ARM, FreeBSD), install Node 22 or newer yourself"),
                )
            )
            out.append(
                (
                    bool(f.get("claude_login")),
                    "logged in to Claude",
                    (
                        "run `thomas login` -- it opens Claude's sign-in page (or prints a link). You need a paid Claude account (Pro,"
                        " Max, Team or Enterprise -- the free plan does not include it) or a Claude Console account;"
                        " or set ANTHROPIC_API_KEY. No paid account? `thomas login --free` starts free"
                    ),
                )
            )
    out.append(
        (
            bool(f.get("probe_ok")),
            "acp-probe can launch",
            "run install.sh in the Thomas folder again: it points acp-probe's first line at the folder's own python",
        )
    )
    return out


def _facts(cfg):
    ""
    import importlib.util

    here = os.path.dirname(os.path.realpath(__file__))
    chosen = cfg.get("brain", {}).get(":kind")
    spec = acp_lib.AGENTS.get(chosen) or {}
    adapter = (spec.get("cmd") or [None])[0]
    node = None
    if shutil.which("node"):
        try:
            v = subprocess.run(
                ["node", "--version"], capture_output=True, text=True, timeout=10, check=False
            ).stdout
            node = int(v.strip().lstrip("v").split(".")[0])
        except (OSError, ValueError, subprocess.SubprocessError) as e:
            print(
                f"thomas: node version unreadable ({type(e).__name__}); reported as unknown",
                file=sys.stderr,
            )
            node = None
    probe = os.path.join(here, "acp-probe")
    probe_ok = False
    try:
        with open(probe) as fh:
            first = fh.readline()
        interp = first[2:].split()[0] if first.startswith("#!") else ""
        probe_ok = bool(interp) and (
            os.path.isfile(interp)
            if interp != "/usr/bin/env"
            else bool(shutil.which(first.split()[1]))
        )
    except (OSError, IndexError) as e:
        print(
            f"thomas: acp-probe unreadable at {probe} ({type(e).__name__}); reported as not ok",
            file=sys.stderr,
        )
        probe_ok = False
    return {
        "py": sys.version_info[:2],
        "redis_mod": importlib.util.find_spec("redis") is not None,
        "config": thomas_config.DEFAULT if os.path.isfile(thomas_config.DEFAULT) else None,
        "chosen": chosen,
        "agents": tuple(acp_lib.AGENTS) + (FREE,),
        "free_ready": chosen != FREE or bool(_free_ready()),
        "free_key_problem": _free_key_problem() if chosen == FREE else "",
        "adapter": adapter,
        "adapter_on_path": bool(adapter and shutil.which(adapter)),
        "node": node,
        "probe_ok": probe_ok,
        "claude_login": bool(
            os.environ.get("ANTHROPIC_API_KEY")
            or os.environ.get("CLAUDE_CODE_OAUTH_TOKEN")
            or (adapter == "claude-agent-acp" and _login_known_ok())
        ),
    }


def sdk_claude_paths(adapter_real):
    ""
    pkg = os.path.dirname(os.path.dirname(adapter_real))  # .../claude-agent-acp
    hoisted = os.path.dirname(
        os.path.dirname(pkg)
    )  # .../node_modules (above the @agentclientprotocol scope)
    return [
        os.path.join(pkg, "node_modules", "@anthropic-ai"),
        os.path.join(hoisted, "@anthropic-ai"),
    ]


def claude_binary():
    ""
    acp = shutil.which("claude-agent-acp")
    if acp:
        for d in sdk_claude_paths(os.path.realpath(acp)):
            try:
                names = sorted(os.listdir(d))
            except (
                OSError
            ):  # a candidate SDK path that is not a directory on this install; the next is tried
                continue
            for n in names:
                b = os.path.join(d, n, "claude")
                if n.startswith("claude-agent-sdk-") and os.access(b, os.X_OK):
                    return b
    return shutil.which("claude")


def logged_in(binary, _run=subprocess.run, kids=None):
    ""
    if not binary:
        return None
    try:
        if kids is None:
            out = _run(
                [binary, "auth", "status", "--json"],
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            ).stdout
        else:
            p = subprocess.Popen(
                [binary, "auth", "status", "--json"], stdout=subprocess.PIPE, text=True
            )
            kids.append(p)
            try:
                out, _ = p.communicate(timeout=30)
            except subprocess.TimeoutExpired:
                print(
                    "thomas: `auth status` did not answer in 30 s; killed, login state UNREADABLE",
                    file=sys.stderr,
                )
                p.kill()
                p.communicate()
                return None
            finally:
                kids.remove(p)
        d = json.loads(out)
    except (OSError, ValueError, subprocess.SubprocessError) as e:
        print(
            f"thomas: `auth status` gave no readable JSON ({type(e).__name__}); login state UNREADABLE",
            file=sys.stderr,
        )
        return None
    v = d.get("loggedIn") if isinstance(d, dict) else None
    return v if isinstance(v, bool) else None


def _login_known_ok():
    ""
    b = claude_binary()
    return b is not None and logged_in(b) is not False


FREE = "free"  # the free brain: OpenRouter's free models, text only (thomas_free.py) -- no paid account needed
FREE_MODEL_FILE = os.path.expanduser(
    "~/.thomas/free-models"
)  # the ranked fallback list, one model id per line


def _free_models():
    ""
    import thomas_free

    try:
        with open(FREE_MODEL_FILE, encoding="utf-8") as fh:
            return thomas_free.model_ids(fh.read())
    except (
        FileNotFoundError
    ):  # no model file is the normal pre-login state; the login hint is the message
        return []
    except (OSError, ValueError) as e:  # ValueError: bytes that are not UTF-8 (UnicodeDecodeError has no strerror)
        print(
            f"thomas: free-model list unreadable at {FREE_MODEL_FILE} ({getattr(e, 'strerror', None) or type(e).__name__}); treated as empty",
            file=sys.stderr,
        )
        return []


def _free_ready():
    ""
    import thomas_free

    return bool(thomas_free.read_key()) and bool(_free_models())


def _free_key_problem():
    ""
    import thomas_free

    return thomas_free.key_file_problem(thomas_free.KEY_FILE)


def try_cmd(which=shutil.which, argv0=None):
    ""
    me = os.path.abspath(argv0 or sys.argv[0])
    found = which("thomas")
    if found and os.path.realpath(found) == os.path.realpath(me):
        return "thomas"
    return shlex.quote(me)


def free_login(
    cfg_path=thomas_config.USER, _getpass=None, _check=None, key_path=None, model_path=None
):
    ""
    import getpass

    import thomas_free

    print(
        "Start Thomas free, with OpenRouter's free models (no card, no paid plan):\n"
        "  1. On any device, open openrouter.ai and sign in (Google or GitHub works).\n"
        "  2. Open openrouter.ai/keys, press 'Create API Key', and copy the key.\n"
        "  3. Paste it here (it is not shown on screen).\n"
        "Privacy: free models are run by outside companies that may keep, train on, or publish what you send --\n"
        "including your notes and recent conversation, which Thomas sends with every question. Do not send anything\n"
        "private. OpenRouter may ask you to allow this in openrouter.ai/settings/privacy before free models work.\n"
        "For a paid brain use `thomas login`.\n",
        flush=True,
    )
    try:
        key = (_getpass or getpass.getpass)("OpenRouter key: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled. Run `thomas login --free` when you are ready.", file=sys.stderr)
        return 130
    if not key:
        print("thomas: no key pasted -- nothing saved.", file=sys.stderr)
        return 1
    models, err = (_check or thomas_free.check_key)(key)
    if not models:
        print("thomas: " + err, file=sys.stderr)
        return 1
    thomas_free.save_key(key, key_path or thomas_free.KEY_FILE)
    _private_write(model_path or FREE_MODEL_FILE, "\n".join(models))
    if os.environ.get("OPENROUTER_API_KEY"):
        print(
            "Note: OPENROUTER_API_KEY is set in your environment; Thomas uses it instead of the key you just saved."
        )
    set_brain_kind(FREE, cfg_path)
    print(
        f'Ready: Thomas now answers with free models ({models[0]} first). Try: {try_cmd()} ask "hello"'
    )
    return 0


def _user_forms(path):
    ""
    if not os.path.exists(path):
        return []
    try:
        with open(path, encoding="utf-8") as fh:
            return [f for f in sexpr_lib.read_all(fh.read()) if isinstance(f, list) and f]
    except (OSError, ValueError) as e:  # ValueError: bytes that are not UTF-8
        raise SystemExit(f"thomas: {path} cannot be read as text ({getattr(e, 'strerror', None) or type(e).__name__}); move it aside") from e


def set_brain_kind(kind, cfg_path=thomas_config.USER):
    ""
    forms = _user_forms(cfg_path)
    forms = set_form(forms, "brain", ":kind", kind)
    os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
    with open(cfg_path + ".tmp", "w", encoding="utf-8") as fh:
        fh.write(dump_forms(forms))
    os.replace(cfg_path + ".tmp", cfg_path)


def _private_write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd = os.open(path + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    os.fchmod(fd, 0o600)  # os.open's mode applies only at creation
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(text + "\n")
    os.replace(path + ".tmp", path)


def rotated(models, rotate):
    ""
    return models[1:] + models[:1] if rotate and len(models) > 1 else list(models)


def free_turn(prompt, _ask=None, rotate=False):
    ""
    import thomas_free

    key = thomas_free.read_key(thomas_free.KEY_FILE)  # the path passed, not defaulted: a default is bound when the module loads
    models = _free_models()
    if not key and thomas_free.key_file_problem(thomas_free.KEY_FILE):
        return 1, "", thomas_free.key_file_problem(thomas_free.KEY_FILE)
    if not key or not models:
        return 1, "", "the free brain needs a key first: run `thomas login --free`"
    models = rotated(models, rotate)
    rc, reply, err = (_ask or thomas_free.ask)(prompt, key, models)
    return rc, reply, (err + "\n") if err else ""


def login_cmd(cfg):
    ""
    kind = cfg.get("brain", {}).get(":kind") or "claude"
    if kind != "claude":
        how = {
            "codex": "codex login",
            "gemini": "gemini",
        }.get(kind)
        if not how:
            print(
                f"thomas: no brain called {kind!r}; pick claude, codex, gemini or free in ~/.thomas/thomas.sexpr",
                file=sys.stderr,
            )
            return 2
        print(
            f"Log in to {kind} with its own command: `{how}`"
            + (" (it asks you to sign in the first time)" if kind == "gemini" else "")
        )
        return 0
    import signal

    kids: list[subprocess.Popen] = []

    def _stop(_sig, _frame):
        for k in kids:
            k.terminate()
        sys.exit(143)

    signal.signal(signal.SIGTERM, _stop)
    try:
        return _login_claude(kids)
    except (
        KeyboardInterrupt
    ):  # Ctrl-C anywhere (the status checks too): children terminated, exit 130, no traceback
        for k in kids:
            k.terminate()
        print("\nCancelled. Run `thomas login` when you are ready.", file=sys.stderr)
        return 130


def keychain_home_mismatch(platform, home, account_home):
    ""
    if platform != "darwin" or not home or not account_home:
        return None
    if os.path.realpath(home) == os.path.realpath(account_home):
        return None
    return (
        f"HOME is {home}, but this account's home is {account_home}; the Claude sign-in keeps its token in your"
        " login keychain, which lives there. Run `thomas login` without changing HOME."
    )


def _account_home():
    import pwd

    try:
        return pwd.getpwuid(os.getuid()).pw_dir
    except (
        KeyError
    ):  # no passwd entry for this uid (a container); '' makes the caller fall back to $HOME
        return ""


def _login_claude(kids):
    ""
    why = keychain_home_mismatch(sys.platform, os.environ.get("HOME", ""), _account_home())
    if why:
        print("thomas: " + why, file=sys.stderr)
        return 2
    b = claude_binary()
    if not b:
        print(
            "thomas: the Claude adapter is not installed yet -- run install.sh in the Thomas folder again",
            file=sys.stderr,
        )
        return 1
    if logged_in(b, kids=kids):
        print(f'You are already logged in to Claude. Try: {try_cmd()} ask "hello"')
        return 0
    print(
        "Signing you in to Claude: a sign-in page opens in your browser, or -- on a computer without one -- a link to\n"
        "open on any device and a code to paste back here. You need a PAID account (Pro, Max, Team or Enterprise), or\n"
        "a Claude Console account billed by use -- the free claude.ai plan does not include this. Thomas never sees\n"
        "your password; the login is stored by Claude Code on this computer.\n",
        flush=True,
    )  # before the child writes
    child = subprocess.Popen([b, "auth", "login"])
    kids.append(child)
    rc = child.wait()
    if logged_in(b, kids=kids):
        print(f'\nLogged in. Try: {try_cmd()} ask "hello"')
        return 0
    print(
        "\nNot logged in yet. Run `thomas login` again, or set ANTHROPIC_API_KEY to a Claude Console key.",
        file=sys.stderr,
    )
    return rc or 1


def auth_hint(kind, text):
    ""
    if "Authentication required" not in text and "authentication_error" not in text:
        return None
    how = {
        "claude": "thomas login",
        "gemini": "gemini (run it once and sign in)",
        "codex": "codex login",
    }
    return f"your {kind} brain needs YOUR login first: run `{how.get(kind, kind + ' login')}`, then ask again."


def next_steps(f, cmd):
    ""
    chosen = f.get("chosen")
    signed = {
        FREE: f.get("free_ready"),
        "claude": f.get("claude_login"),
        None: f.get("claude_login"),
    }.get(chosen)
    gaps = [w for ok, w, _fix in doctor_checks(f) if not ok]
    name = f"{cmd} persona set :name YourName"
    hello = f'{cmd} ask "hello"'
    if signed and not gaps:
        return [
            "Next: you are already signed in, so give your assistant a name:  " + name,
            "      and say hello:                                              " + hello,
        ]
    if signed:
        return [
            "Next: fix what is marked MISSING above (each line says how), then give your assistant a name:  "
            + name,
            "      and say hello:  " + hello,
        ]
    if chosen in ("codex", "gemini"):
        return [
            f"Next: sign in to your {chosen} brain with your own account:  {cmd} login",
            "      then give your assistant a name:  " + name,
            "      and say hello:                    " + hello,
        ]
    return [
        "Next: sign in with your own paid Claude account (a sign-in page opens, or a link to open):",
        f"      {cmd} login",
        f"      no paid account? start free instead (an OpenRouter key, no card):  {cmd} login --free",
        "      then give your assistant a name:  " + name,
        "      and say hello:                    " + hello,
    ]


def print_doctor(checks, out=print):
    ""
    gaps = 0
    for ok, what, fix in checks:
        out(f"  {'ok  ' if ok else 'MISSING'}  {what}" + ("" if ok else f"\n           fix: {fix}"))
        gaps += not ok
    out("  ready." if not gaps else f"  {gaps} thing(s) to fix before `thomas ask` will work.")
    return gaps


SAFE_MODES = {"claude": "default", "codex": "read-only", "gemini": "default"}
CONFINED_BRAINS = ("claude",)


def confinement_refusal(brain, kind):
    ""
    if (
        kind == FREE
    ):  # text only -- one request, one reply; it can read and run nothing, so there is nothing to confine
        return None
    if kind not in acp_lib.AGENTS:
        return f"Thomas does not know a brain called {kind!r}: pick claude, codex, gemini or free"
    if brain.get(":autonomy") is True or kind in CONFINED_BRAINS:
        return None
    return (
        f"the {kind} brain reads files outside its folder even in its asking mode, so Thomas runs it only with"
        f" autonomy on: add (brain :autonomy t) to ~/.thomas/thomas.sexpr knowingly, or use --brain claude"
    )


ASKS = os.path.expanduser("~/.thomas/asks.jsonl")


def record_ask(ok, prompt_chars, reply_chars, brain, path=ASKS, now=None):
    ""
    import time

    row = {
        "t": round(now if now is not None else time.time()),
        "brain": brain,
        "ok": bool(ok),
        "prompt_chars": prompt_chars,
        "reply_chars": reply_chars,
    }
    return _append_jsonl(row, path, "ask")


def record_check(ok, counts, brain, path=ASKS, now=None):
    ""
    import time

    row = {"t": round(now if now is not None else time.time()), "kind": "check", "brain": brain, "ok": bool(ok)}
    if counts is not None:
        row.update(claims=sum(counts.values()), **{m: counts.get(m, 0) for m in CHECK_MARKS})
    return _append_jsonl(row, path, "check")


def has_checked(path=ASKS):
    ""
    import json

    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for ln in f:
                try:
                    row = json.loads(ln)
                except ValueError:  # a torn or foreign line is not a check row; skip it
                    continue
                if isinstance(row, dict) and row.get("kind") == "check":
                    return True
    except (OSError, ValueError):  # no readable asks.jsonl means no check yet; False is that fact
        return False
    return False


def check_hint(keep, checked, argv0, kind, default_kind):
    ""
    if checked or not keep:
        return None
    cmd = shlex.quote(argv0) if argv0 and "/" in argv0 else "thomas"  # quoted: the line is meant to be pasted
    cmd += " check" + (f" --brain {shlex.quote(kind)}" if kind != default_kind else "")
    return f"\n  Want a second opinion on that answer? Run:  {cmd}"


def _append_jsonl(row, path, what):
    ""
    import json

    try:
        _private_append(path, json.dumps(row) + "\n")
    except OSError as e:
        print(f"thomas: could not record this {what} in {path} ({e})", file=sys.stderr)
    return row


def brain_env(brain, kind):
    ""
    model = brain.get(":model")
    if not isinstance(model, str) or not model.strip():
        return {}, ""
    if kind == "claude":
        return {"ANTHROPIC_MODEL": model.strip()}, ""
    return {}, f"thomas: (brain :model {model}) is honoured for the claude brain only; {kind} uses its default"


def ask_flags(brain, kind, scratch=None):
    ""
    flags = []
    if brain.get(":autonomy") is not True:
        flags += ["--mode", SAFE_MODES.get(kind, "default")]
        if scratch:
            flags += ["--cwd", scratch]
    if brain.get(":borrow-credentials") is not True:
        flags.append("--no-borrow")
    if brain.get(":ledger") is not True:
        flags.append("--no-ledger")
    return flags


def persona_preamble(p):
    ""
    lines = [f"You are {p.get(':name') or 'Thomas'}, the user's assistant."]
    if p.get(":pronouns"):
        lines.append(f"Pronouns: {p[':pronouns']}.")
    if p.get(":personality"):
        lines.append(f"Personality: {p[':personality']}")
    if p.get(":voice"):
        lines.append(f"Voice: {p[':voice']}")
    return "\n".join(lines)


CONVO = os.path.expanduser("~/.thomas/conversation.jsonl")
NOTES = os.path.expanduser("~/.thomas/memory.md")
HISTORY_CHARS = 8000  # the most recalled conversation one turn carries; older turns drop first


def history_block(turns, max_turns=8, max_chars=HISTORY_CHARS):
    ""
    keep = (
        [t for t in turns if t.get("you") and t.get("thomas")][-max_turns:] if max_turns > 0 else []
    )
    while keep:
        text = "\n\n".join(f"User: {t['you']}\nYou: {t['thomas']}" for t in keep)
        if len(text) <= max_chars:
            return "Our conversation so far (oldest first):\n\n" + text
        keep = keep[1:]
    return ""


NOTES_CHARS = (
    16000  # notes beyond this are left out (oldest first): the prompt rides argv, which the OS caps
)


def clean_text(s):
    ""
    return str(s).replace("\x00", "").encode("utf-8", "replace").decode("utf-8")


def compose_prompt(preamble, notes, history, prompt):
    ""
    notes = clean_text(notes).strip()[-NOTES_CHARS:]
    parts = [clean_text(preamble)]
    if notes:
        parts.append("What the user wants you to remember:\n" + notes)
    if history:
        parts.append(clean_text(history))
    parts.append(("The user now says:\n" if history or notes else "") + clean_text(prompt))
    return "\n\n".join(parts)


def _private_append(path, line):
    ""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    with os.fdopen(fd, "a") as fh:
        fh.write(line)


def load_turns(path=CONVO):
    ""
    import json

    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            lines = fh.readlines()
    except (
        OSError,
        ValueError,
    ):  # no asks file yet is the normal first state: nothing was ever asked
        return []
    out = []
    for ln in lines:
        try:
            row = json.loads(ln)
        except (
            ValueError,
            RecursionError,
        ):  # a torn or hostile line in the asks file; a deeply nested one raises RecursionError, not ValueError
            continue
        if (
            isinstance(row, dict)
            and isinstance(row.get("you"), str)
            and isinstance(row.get("thomas"), str)
        ):
            out.append(row)
    return out


def _deep_ok():
    ""
    import tempfile

    with tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False) as fh:
        fh.write("[" * 100000 + "]" * 100000 + '\n{"you": "q", "thomas": "a"}\n')
    try:
        return load_turns(fh.name) == [{"you": "q", "thomas": "a"}]
    finally:
        os.remove(fh.name)


def read_notes(path=NOTES):
    ""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except (OSError, ValueError):  # no notes file yet means no notes; '' is that fact
        return ""


def brains(agents, have):
    ""
    return [(n, bool(have(spec["cmd"][0])), " ".join(spec["cmd"])) for n, spec in agents.items()]


def set_form(forms, section, key, value):
    ""
    out, done = [], False
    for f in forms:
        if isinstance(f, list) and f and f[0] == section and not done:
            body = list(f[1:])
            for i in range(0, len(body) - 1, 2):
                if body[i] == key:
                    body[i + 1] = value
                    break
            else:
                body += [key, value]
            out.append([section, *body])
            done = True
        else:
            out.append(f)
    if not done:
        out.append([section, key, value])
    return out


def _quote(v):
    ""
    if v in ("nil", "t"):
        return v
    return '"' + str(v).replace("\\", "\\\\").replace('"', '\\"') + '"'


def dump_forms(forms):
    ""
    rows = []
    for f in forms:
        head, body = f[0], f[1:]
        pairs = " ".join(f"{k} {_quote(v)}" for k, v in zip(body[0::2], body[1::2]))
        rows.append(f"({head} {pairs})")
    return (
        ";; machine-written by thomas (persona set, login); the documented defaults are thomas.sexpr beside the thomas program\n"
        + "\n".join(rows)
        + "\n"
    )


def persona_set(key, value, path=thomas_config.USER):
    if key not in PERSONA_KEYS:
        raise SystemExit(f"thomas persona set: unknown key {key} (one of {' '.join(PERSONA_KEYS)})")
    if (
        key == ":image"
        and value not in ("nil", "")
        and not os.path.isfile(os.path.expanduser(value))
    ):
        raise SystemExit(f"thomas persona set: no image at {value}")
    forms = _user_forms(path)
    forms = set_form(forms, "persona", key, value or "nil")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(dump_forms(forms))
    os.replace(tmp, path)


REPORT_REPO = "qizwiz/thomas-kit"


def cmd_report(rest, run=subprocess.run):
    ""
    import report_lib

    def opt(name):
        return rest[rest.index(name) + 1] if name in rest and rest.index(name) + 1 < len(rest) else ""

    unread = ""
    if "--form" in rest:
        try:
            fields = report_lib.parse(report_lib.FENCE + "\n" + opt("--form") + "\n```")
        except Exception as e:  # noqa: BLE001 -- whatever the reader raises on a form it cannot read is one plain line
            fields, why = None, f" ({type(e).__name__})"
        else:
            why = ""
        if not fields:
            print(f"thomas report: --form is not a (report :kind ... :what ...) form that reads{why}; nothing was filed", file=sys.stderr)
            return 2
    else:
        fields = {k: opt("--" + k) for k in ("kind", "what", "repro", "expected", "got")}
        if opt("--test"):
            tpath = os.path.expanduser(opt("--test"))
            try:
                with open(tpath, "rb") as fh:
                    raw = fh.read()
            except OSError as e:
                print(f"thomas report: cannot read --test file {tpath}: {e.strerror or type(e).__name__}; nothing was filed", file=sys.stderr)
                return 2
            try:
                fields["test"] = raw.decode("utf-8")
            except UnicodeDecodeError as e:  # recorded in `unread`; the preview note below says it and cmd_report's selftest asserts that
                unread = e.reason
                fields["test"] = raw.decode("utf-8", errors="replace")
    if not fields.get("thomas-version"):
        fields["thomas-version"] = _kit_version()
    bad = report_lib.problems(fields)
    if bad:
        print("thomas report: not filed --\n  " + "\n  ".join(bad), file=sys.stderr)
        return 2
    paths = mails = 0
    for k in list(fields):
        fields[k], p, m = report_lib.scrub_counted(fields[k])
        paths, mails = paths + p, mails + m
    note = (f"(shortened {paths} home path(s), replaced {mails} email address(es) before this was printed or filed)"
            if paths or mails else "")
    if unread:
        note += ("\n" if note else "") + f"(some bytes could not be read as text in the --test file ({unread}) and were replaced)"
    title = f"report: {fields['kind']}: {' '.join(fields['what'].split())[:70]}"
    body = (f"Filed with `thomas report`. The form below is what the intake reads.\n\n{report_lib.FENCE}\n"
            f"{report_lib.build(fields)}\n```\n")
    value_options = ("--kind", "--what", "--repro", "--expected", "--got", "--test", "--form")
    flag_file, takes_value = False, False
    for a in rest:
        if takes_value:
            takes_value = False  # this argument is the option's value, whatever it looks like
        elif a in value_options:
            takes_value = True
        elif a == "--file":
            flag_file = True
    if not flag_file:
        print(f"title: {title}\n\n{body}" + (note + "\n" if note else "")
              + f"\n(not filed -- add --file to open it on {REPORT_REPO})")
        return 0
    if note:
        print(note)
    try:
        p = run(["gh", "issue", "create", "--repo", REPORT_REPO, "--title", title, "--body", body],
                capture_output=True, text=True, check=False)
    except FileNotFoundError as e:
        print(f"thomas report: gh (the GitHub command-line tool) was not found ({e.strerror or 'no such file'}); install it from https://cli.github.com and run "
              f"`gh auth login`, or file this by hand at https://github.com/{REPORT_REPO}/issues (run again without --file to print "
              "the text). Nothing was filed.", file=sys.stderr)
        return 1
    except OSError as e:
        print(f"thomas report: gh could not be run ({e.strerror or type(e).__name__}); nothing was filed", file=sys.stderr)
        return 1
    if p.returncode != 0:
        first = next((ln.strip() for ln in (p.stderr or p.stdout or "").splitlines() if ln.strip()), f"exit status {p.returncode}")
        print(f"thomas report: gh failed: {first}", file=sys.stderr)
        return 1
    print((p.stdout or p.stderr).strip())
    return 0


def _kit_version():
    ""
    v = os.path.join(_KIT, "VERSION")
    if os.path.exists(v):
        with open(v) as fh:
            return fh.read().strip()[:64] or "unknown"
    return "unknown"


def main(argv):
    if "--selftest" in argv:
        return selftest()
    for a in argv:
        try:
            a.encode("utf-8")
        except UnicodeEncodeError:  # the refusal line below is the message; the argument is never echoed
            print("thomas: an argument is not valid UTF-8 text; nothing was done", file=sys.stderr)
            return 2
    cmd = argv[1] if len(argv) > 1 else "config"
    try:
        cfg = thomas_config.load()
    except thomas_config.ConfigError as e:  # a broken config is one plain line, never a traceback
        print(f"thomas: {e}", file=sys.stderr)
        return 2
    if cmd in ("--help", "-h", "help"):
        print(USAGE)
        return 0
    if cmd == "login":
        if "--free" in argv[2:]:
            return free_login()
        if cfg.get("brain", {}).get(":kind") == FREE:
            rc = login_cmd({**cfg, "brain": {**cfg.get("brain", {}), ":kind": "claude"}})
            if rc == 0:
                set_brain_kind("claude")
                print("Switched Thomas to the Claude brain.")
            return rc
        return login_cmd(cfg)
    if cmd == "report":
        return cmd_report(argv[2:])
    if cmd == "doctor":
        f = _facts(cfg)
        gaps = print_doctor(doctor_checks(f))
        if "--next" in argv[2:]:
            print()
            print("\n".join(next_steps(f, try_cmd())))
        return 1 if gaps else 0
    if cmd == "config":
        for sec, kv in cfg.items():
            print(f"({sec} " + " ".join(f"{k} {v!r}" for k, v in kv.items()) + ")")
        return 0
    if cmd == "brain":
        chosen = cfg.get("brain", {}).get(":kind")
        for n, ok, c in brains(acp_lib.AGENTS, shutil.which):
            print(
                f"  {'*' if n == chosen else ' '} {n:<8} {'installed' if ok else 'NOT on PATH':<12} {c}"
            )
        ready = _free_ready()
        print(
            f"  {'*' if chosen == FREE else ' '} {FREE:<8} {'ready' if ready else 'no key yet':<12}"
            f" {'free models through OpenRouter, text only' if ready else 'run `thomas login --free`'}"
        )
        if chosen not in acp_lib.AGENTS and chosen != FREE:
            print(
                f"  chosen brain {chosen!r} is not one Thomas knows -- pick claude, codex, gemini or free"
            )
        return 0
    if cmd == "idioms":
        rest = argv[2:]
        project = os.getcwd()
        if "--project" in rest:
            i = rest.index("--project")
            if i + 1 >= len(rest):
                print("thomas: --project needs a folder", file=sys.stderr)
                return 2
            project = os.path.abspath(rest[i + 1])
        import json

        import claude_idioms

        cat = claude_idioms.resolve(project)
        if "--json" in rest:
            print(json.dumps(cat))
        else:
            for g in cat["groups"]:
                print(g["group"])
                for it in g["items"]:
                    print(f"  {it['name']:<14} {it['what']}")
        return 0
    if cmd == "persona":
        if len(argv) >= 5 and argv[2] == "set":
            persona_set(argv[3], " ".join(argv[4:]))
        for k in PERSONA_KEYS:
            print(f"  {k:<13} {thomas_config.load().get('persona', {}).get(k)!r}")
        return 0
    if cmd == "remember":
        note = " ".join(argv[2:]).strip()
        if not note:
            print(
                f'usage: thomas remember "something every turn should know"   (kept in {NOTES})',
                file=sys.stderr,
            )
            return 2
        if not memory_settings(cfg)[0]:
            print(
                "Memory is off ((memory :keep nil) in ~/.thomas/thomas.sexpr), so nothing was saved.",
                file=sys.stderr,
            )
            return 1
        try:
            _private_append(NOTES, "- " + clean_text(note) + "\n")
        except OSError as e:
            print(f"thomas: could not write {NOTES} ({e.strerror or e})", file=sys.stderr)
            return 1
        print(f"Noted. Every turn now carries it; edit or delete it in {NOTES}.")
        return 0
    if cmd == "forget":
        try:
            os.remove(CONVO)
            print(
                f"Deleted the conversation ({CONVO}). Your notes in {NOTES} stay; delete that file to drop them."
            )
        except FileNotFoundError:
            print("There was no kept conversation.")
        except OSError as e:
            print(f"thomas: could not delete {CONVO} ({e.strerror or e})", file=sys.stderr)
            return 1
        return 0
    if cmd == "check":
        kind, rest = take_brain(argv[2:], cfg.get("brain", {}).get(":kind") or "claude")
        if kind is None or rest:
            print("thomas: usage: thomas check [--brain claude|codex|gemini|free]", file=sys.stderr)
            return 2
        refusal = confinement_refusal(cfg.get("brain", {}), kind)
        if refusal:
            print("thomas: " + refusal, file=sys.stderr)
            return 1
        return check_turn(cfg, kind)
    if cmd == "telegram":
        return telegram_cmd(cfg, argv[2:])
    if cmd in ("ask", "chat"):
        rest = argv[2:]
        kind, rest = take_brain(rest, cfg.get("brain", {}).get(":kind") or "claude")
        if kind is None:
            print("thomas: --brain needs a name (claude, codex, gemini or free)", file=sys.stderr)
            return 2
        fresh = "--new" in rest
        rest = [a for a in rest if a != "--new"]
        refusal = confinement_refusal(cfg.get("brain", {}), kind)
        if refusal:
            print("thomas: " + refusal, file=sys.stderr)
            return 1
        gaps = [
            c
            for c in doctor_checks(
                _facts({**cfg, "brain": {**cfg.get("brain", {}), ":kind": kind}})
            )
            if not c[0]
        ]
        if gaps:
            print_doctor(gaps)
            return 1
        if cmd == "ask":
            if kind == FREE and sys.stderr.isatty():
                print(
                    "(thinking -- free models can take a minute or more)",
                    file=sys.stderr,
                    flush=True,
                )
            rc = ask_turn(cfg, kind, " ".join(rest), fresh)
            if rc == 0 and sys.stderr.isatty():
                hint = check_hint(
                    memory_settings(cfg)[0],
                    has_checked(),
                    argv[0],
                    kind,
                    cfg.get("brain", {}).get(":kind") or "claude",
                )
                if hint:
                    print(hint, file=sys.stderr)
            return rc
        name = cfg.get("persona", {}).get(":name") or "Thomas"
        print(
            f"Talking with {name}. Type a message and press Return; an empty line or Ctrl-D ends the chat."
        )
        while True:
            try:
                line = input("\nyou> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                return 0
            if not line or line in ("exit", "quit"):
                return 0
            print(f"({name} is thinking...)", file=sys.stderr)
            print()
            ask_turn(cfg, kind, line, fresh)
            fresh = False
    print(USAGE)
    return 2


def take_brain(rest, default):
    ""
    if "--brain" not in rest:
        return default, list(rest)
    i = rest.index("--brain")
    if i + 1 >= len(rest):
        return None, list(rest)
    return rest[i + 1], rest[:i] + rest[i + 2 :]


def memory_settings(cfg):
    ""
    mem = cfg.get("memory", {})
    keep = not (":keep" in mem and mem[":keep"] in (None, False))
    try:
        max_turns = int(mem.get(":turns") or 8)
    except (TypeError, ValueError):
        print(f"thomas: :turns is {mem.get(':turns')!r}, not a number; using 8", file=sys.stderr)
        max_turns = 8
    return keep, max_turns


def telegram_cmd(cfg, rest):
    ""
    import getpass
    import time

    import thomas_telegram as tg

    sub = rest[0] if rest else "status"
    try:
        conf = {} if sub == "uninstall" else tg.load_conf()  # uninstall only removes the service: a torn conf must not stop that
    except tg.ConfCorrupt as e:  # a corrupt conf is reported, never treated as "not set up"
        print(f"thomas telegram: {e}", file=sys.stderr)
        return 1
    import platform

    running = tg.service_running(platform.system(), os.getuid())
    is_service = os.environ.get(tg.SERVICE_ENV) == "1"
    if (sub in ("setup", "unpair") or (sub == "run" and not is_service)) and running:
        print(
            "The background service is running; stop it first: thomas telegram uninstall",
            file=sys.stderr,
        )
        return 1
    if sub == "setup":
        print(
            "Create a bot: in Telegram, message @BotFather, send /newbot, and copy the token it gives you."
        )
        try:
            if sys.stdin.isatty():
                token = getpass.getpass("Paste the bot token (it is not shown): ").strip()
            else:  # piped in: getpass cannot hide anything there and warns, so read the line plainly
                token = sys.stdin.readline().strip()
        except (
            EOFError,
            KeyboardInterrupt,
        ):  # Ctrl-D / Ctrl-C at the prompt: no traceback
            print()
            token = ""
        if not token:
            print("No token given; nothing changed.", file=sys.stderr)
            return 2
        try:
            me = tg.http(token, "getMe", {}, timeout=20)
        except RuntimeError as e:
            print(f"Telegram did not accept that token ({e}); nothing saved.", file=sys.stderr)
            return 1
        name = (me.get("result") or {}).get("username", "?")
        tg.save_conf({"token": token, "offset": 0})  # a new token starts unpaired
        print(f"Saved for @{name} in {tg.CONF} (readable only by you). Next: thomas telegram run")
        return 0
    if sub == "unpair":
        conf.pop("owner", None)
        if conf:
            tg.save_conf(conf)
        print("Unpaired. The next `thomas telegram run` prints a new pairing code.")
        return 0
    if sub in ("install", "uninstall"):
        system = platform.system()
        me = ENTRY  # the launcher: the service runs the command a user runs, never this module
        ((svc_path, svc_text),) = tg.service_files(
            me, os.path.expanduser("~"), system, os.environ.get("PATH", "")
        )
        if sub == "install":
            if cfg.get("brain", {}).get(":autonomy") is True:
                print(
                    "thomas: Telegram runs only with autonomy off; remove (brain :autonomy t) first.",
                    file=sys.stderr,
                )
                return 1
            if not (conf.get("token") and conf.get("owner")):
                print(
                    "Pair first: thomas telegram setup, then thomas telegram run and send the /pair code. "
                    "The background service cannot show you a pairing code.",
                    file=sys.stderr,
                )
                return 1
            os.makedirs(os.path.dirname(svc_path), exist_ok=True)
            with open(svc_path, "w") as fh:
                fh.write(svc_text)
            os.close(os.open(tg.LOG, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600))
            os.chmod(tg.LOG, 0o600)
        for cmd, must in tg.service_commands(system, os.getuid(), svc_path, sub == "install"):
            try:
                p = subprocess.run(cmd, capture_output=True, text=True, check=False)
            except OSError:
                if not must:
                    continue
                print(
                    f"thomas: this system has no `{cmd[0]}`, so Thomas cannot install a background service here; "
                    "keep `thomas telegram run` open in a terminal instead.",
                    file=sys.stderr,
                )
                if sub == "install" and os.path.exists(svc_path):
                    os.remove(svc_path)  # no half-installed unit left behind
                return 1
            if p.returncode != 0 and must:
                print(
                    f"thomas: `{' '.join(cmd)}` failed: {(p.stderr or p.stdout).strip()[:200]}",
                    file=sys.stderr,
                )
                return 1
        if sub == "uninstall":
            try:
                os.remove(svc_path)
            except (
                FileNotFoundError
            ):  # the service file is already gone, which is the state `stop` wants
                pass
            if tg.service_running(system, os.getuid()):
                probe = " ".join(tg.service_probe(system, os.getuid()))
                print(
                    f"thomas: the service is STILL running after the stop; check `{probe}`",
                    file=sys.stderr,
                )
                return 1
            print(
                "Stopped and removed. Your assistant no longer answers Telegram until you run or install it again."
            )
        else:
            print(
                f"Running in the background, and again after every login. Log: {tg.LOG}. "
                "Stop it with: thomas telegram uninstall"
            )
        return 0
    if sub == "status":
        if not conf.get("token"):
            print("Not set up. Run: thomas telegram setup")
        else:
            print(
                "Set up; "
                + (
                    "paired with one chat."
                    if conf.get("owner")
                    else "not paired yet (thomas telegram run)."
                )
            )
        return 0
    if sub != "run":
        print(
            "usage: thomas telegram setup | run | install | uninstall | status | unpair",
            file=sys.stderr,
        )
        return 2
    if not conf.get("token"):
        print("Not set up. Run: thomas telegram setup", file=sys.stderr)
        return 1
    kind = cfg.get("brain", {}).get(":kind") or "claude"
    if cfg.get("brain", {}).get(":autonomy") is True:
        print(
            "thomas: Telegram runs only with autonomy off; remove (brain :autonomy t) to use it.",
            file=sys.stderr,
        )
        return 1
    refusal = confinement_refusal(cfg.get("brain", {}), kind)
    if refusal:
        print("thomas: " + refusal, file=sys.stderr)
        return 1
    gaps = [c for c in doctor_checks(_facts(cfg)) if not c[0]]
    if gaps:
        print_doctor(gaps)
        return 1
    reconf = getattr(
        sys.stdout, "reconfigure", None
    )  # absent on a replaced stdout; then printing is already its job
    if reconf:
        reconf(line_buffering=True)
    state = {"code": None if conf.get("owner") else tg.new_code(), "wrong": 0}
    if state["code"]:
        print(f"From your phone, send this to your bot:  /pair {state['code']}")
    print(
        "Listening for Telegram messages."
        + (
            " Leave this window open; Ctrl-C stops it (or: thomas telegram install)."
            if sys.stdout.isatty()
            else ""
        )
    )

    def turn(text):
        try:
            rc, reply, _out, _err = run_turn(cfg, kind, text)
        except Exception as e:  # noqa: BLE001
            print(f"thomas telegram: a turn failed ({type(e).__name__})", file=sys.stderr)
            rc, reply = 1, ""
        return (
            reply
            if rc == 0 and reply
            else "Your assistant could not answer that one; check the computer."
        )

    def call(method, params):
        return tg.http(conf["token"], method, params)

    try:
        while True:
            try:
                tg.poll_once(conf, state, call, turn, tg.save_conf)
            except RuntimeError as e:
                print(f"thomas telegram: {e}; retrying in 10 s", file=sys.stderr)
                time.sleep(10)
    except KeyboardInterrupt:
        print("\nStopped.")
        return 0


def ask_turn(cfg, kind, text, fresh=False, convo=CONVO, notes=NOTES):
    ""
    rc, _reply, out, err = run_turn(cfg, kind, text, fresh, convo, notes)
    print(out, end="" if out.endswith("\n") else "\n")
    sys.stderr.write(err)
    hint = auth_hint(kind, out + err) if rc != 0 else None
    if hint:
        print("\n  " + hint)
    return rc


def run_turn(cfg, kind, text, fresh=False, convo=CONVO, notes=NOTES):
    ""
    import json
    import time

    keep, max_turns = memory_settings(cfg)
    history = "" if (fresh or not keep) else history_block(load_turns(convo), max_turns)
    prompt = compose_prompt(
        persona_preamble(cfg.get("persona", {})), read_notes(notes) if keep else "", history, text
    )
    rc, reply, out, err = brain_call(cfg, kind, prompt)
    record_ask(rc == 0, len(prompt), len(reply) if rc == 0 else 0, kind)
    if rc == 0 and keep and reply:
        try:
            row = {"t": round(time.time()), "you": clean_text(text), "thomas": clean_text(reply)}
            _private_append(convo, json.dumps(row) + "\n")
        except OSError as e:
            print(f"thomas: could not keep this turn in {convo} ({e})", file=sys.stderr)
    return rc, reply, out, err


def brain_call(cfg, kind, prompt, rotate=False):
    ""
    import tempfile

    if kind == FREE:
        rc, reply, err = free_turn(prompt, rotate=rotate)
        return rc, reply, reply + ("\n" if reply else ""), err
    probe = os.path.join(os.path.dirname(os.path.realpath(__file__)), "acp-probe")
    scratch = (
        None
        if cfg.get("brain", {}).get(":autonomy") is True
        else tempfile.mkdtemp(prefix="thomas-ask-")
    )
    model_env, model_note = brain_env(cfg.get("brain", {}), kind)
    if model_note:
        print(model_note, file=sys.stderr)
    p = subprocess.run(
        [
            probe,
            "--agent",
            kind,
            "--timeout",
            "300",
            "--text",
            *ask_flags(cfg.get("brain", {}), kind, scratch),
            prompt,
        ],
        capture_output=True,
        text=True,
        check=False,
        env={**os.environ, **model_env} if model_env else None,
    )
    if scratch:
        shutil.rmtree(scratch, ignore_errors=True)
    return p.returncode, p.stdout.rstrip("\n"), p.stdout, p.stderr


CHECK_MARKS = ("OK", "DOUBT", "UNSURE")


def check_prompt(question, answer):
    ""
    return (
        "Another assistant wrote the ANSWER below to the QUESTION. You did not write it, and your job is to find what "
        "is wrong with it, not to defend it.\n"
        "List each checkable claim in the ANSWER (facts, numbers, names, dates, steps, code). For each, write ONE line:\n"
        "OK | <claim> | <why it holds>\n"
        "DOUBT | <claim> | <what is wrong or likely wrong>\n"
        "UNSURE | <claim> | <what you would need to check it>\n"
        "Do not rewrite the answer. If it has no checkable claims, write only: NONE\n\n"
        f"QUESTION:\n{question}\n\nANSWER:\n{answer}\n"
    )


def parse_check(text):
    ""
    rows = []
    for ln in (text or "").splitlines():
        parts = [p.strip() for p in ln.strip().lstrip("-*• ").split("|")]
        mark = parts[0].strip("*_` ").rstrip(":").strip("*_` ").upper() if parts else ""
        if mark in CHECK_MARKS and len(parts) >= 2 and parts[1]:
            rows.append((mark, parts[1], " | ".join(parts[2:]).strip()))
    return rows


def check_turn(cfg, kind, convo=CONVO, _call=None, out=print, asks=ASKS):
    ""
    if not memory_settings(cfg)[0]:
        out(
            "Nothing to check: (memory :keep nil) keeps no conversation, so there is no last answer to read."
        )
        return 1
    turns = load_turns(convo)
    if not turns:
        out("Nothing to check yet: ask something first (thomas ask or thomas chat).")
        return 1
    last = turns[-1]
    rc, reply, _o, err = (_call or brain_call)(
        cfg, kind, check_prompt(last["you"], last["thomas"]), rotate=True
    )
    if rc != 0:
        record_check(False, None, kind, path=asks)
        out(
            "The check could not run: "
            + (err.strip().rstrip(".") or "the brain did not answer")
            + "."
        )
        return 1
    rows = parse_check(reply)
    n = {m: sum(1 for r in rows if r[0] == m) for m in CHECK_MARKS}
    record_check(True, n, kind, path=asks)
    out(
        "Checked by a fresh session of the brain that did not write the answer -- a second opinion, not proof: it"
    )
    out("can share the first answer's blind spots, and it can be wrong itself.\n")
    if not rows:
        out(
            "  "
            + (
                "No checkable claims found."
                if reply.strip().strip("*_`. ").upper() == "NONE"
                else reply.strip()[:600]
            )
        )
        return 0
    for mark, claim, why in rows:
        out(f"  {mark:<6} {claim}" + (f"\n         {why}" if why else ""))
    out(f"\n{len(rows)} claim(s): {n['OK']} OK, {n['DOUBT']} doubted, {n['UNSURE']} unsure.")
    return 0


def run(argv, _main=None):
    ""
    fn = _main or main
    if "--selftest" in argv:
        return fn(argv)
    try:
        return fn(argv)
    except Exception as e:  # noqa: BLE001 -- this IS the handler: it names the type, and THOMAS_DEBUG gives the traceback
        print(f"thomas: internal error ({type(e).__name__}) -- please run thomas report", file=sys.stderr)
        if os.environ.get("THOMAS_DEBUG"):
            import traceback

            traceback.print_exc()
        return 1


def selftest():
    import tempfile

    cases = []

    def ck(n, got, want):
        cases.append((n, got == want, got))

    ck("preamble-default", persona_preamble({}), "You are Thomas, the user's assistant.")
    _gh: list = []

    class _P:
        returncode, stdout, stderr = 0, "https://github.com/qizwiz/thomas-kit/issues/1", ""

    def _fake_gh(argv, **_k):
        _gh.append(argv)
        return _P()
    _ok = cmd_report(["--form", '(report :kind idea :what "a sidebar")', "--file"], run=_fake_gh)
    ck("report-files-on-the-kit-repo-with-the-form",
       (_ok, _gh[0][:5] if _gh else None, "(report :kind idea" in (_gh[0][-1] if _gh else "")),
       (0, ["gh", "issue", "create", "--repo", REPORT_REPO], True))
    _gh.clear()
    import contextlib
    import io
    import tempfile as _tf

    import report_lib as _rl
    _mac_home = _rl._HOMES[0]
    with _tf.TemporaryDirectory() as _td:
        _tp = os.path.join(_td, "t.txt")
        with open(_tp, "w", encoding="utf-8") as _fh:
            _fh.write("run " + _mac_home + "sam/proj/t.py\nfrom sam@example.org\n")
        _dry_out = io.StringIO()
        with contextlib.redirect_stdout(_dry_out):
            _dry = cmd_report(["--kind", "idea", "--what", "see /home/lee/x", "--test", _tp], run=_fake_gh)
        _filed = io.StringIO()
        with contextlib.redirect_stdout(_filed):
            cmd_report(["--kind", "idea", "--what", "x", "--test", _tp, "--file"], run=_fake_gh)
    _txt = _dry_out.getvalue()
    ck("report-dry-run-shows-no-home-path-or-address",
       (_dry, _mac_home in _txt, "/home/" in _txt, "sam@" in _txt, "~/proj/t.py" in _txt, "<email>" in _txt,
        "shortened 2 home path(s)" in _txt and "replaced 1 email address(es)" in _txt),
       (0, False, False, False, True, True, True))
    ck("report-filed-body-carries-no-home-path-or-address",
       (_mac_home in _gh[-1][-1] or "sam@" in _gh[-1][-1], "~/proj/t.py" in _gh[-1][-1]) if _gh else None, (False, True))
    _gh.clear()
    _no = cmd_report(["--kind", "bug", "--what", "x", "--file"], run=_fake_gh)
    ck("report-missing-fields-refused-and-nothing-sent", (_no, _gh), (2, []))

    def _rep(args, run=_fake_gh):
        ""
        _gh.clear()
        o, e = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(o), contextlib.redirect_stderr(e):
            rc = cmd_report(args, run=run)
        return rc, o.getvalue(), e.getvalue(), len(_gh)

    _vf = [_rep(a) for a in (
        ["--kind", "idea", "--what", "--file"],
        ["--kind", "bug", "--what", "x", "--repro", "--file", "--expected", "y", "--got", "z"],
        ["--kind", "idea", "--what", "--file", "--file"],
        ["--form", '(report :kind idea :what "a sidebar")', "--file"],
        ["--kind", "idea", "--what", "x", "--test", "--file"],
    )]
    ck("report-file-as-an-option-value-is-text-not-the-flag",
       [(r[0], "not filed -- add --file" in r[1], r[3]) for r in _vf[:2]] + [(r[0], r[3]) for r in _vf[2:4]] + [(_vf[4][0], _vf[4][3])],
       [(0, True, 0), (0, True, 0), (0, 1), (0, 1), (2, 0)])
    with open(os.path.realpath(__file__), encoding="utf-8") as _src_fh:
        _src = _src_fh.read()
    ck("comments: no code comment points at a numbered list of ours (a config error is said by what the code does)",
       "(" + "item " in _src, False)

    _words = ("password=hunter2", "the password is Tr0ub4dor&3", "PASSWORD: correcthorsebattery")
    _dry_w = [_rep(["--kind", "idea", "--what", w]) for w in _words]
    ck("report-word-like-password-is-not-refused-and-prints-as-fileable",
       [(r[0], w in r[1], "not filed -- add --file" in r[1], r[2], r[3]) for r, w in zip(_dry_w, _words)],
       [(0, True, True, "", 0)] * 3)
    _key = "sk-ant-" + "api03-" + "Zq9Xw8Vu7Ts6Rq5Po4Nm3Lk2Ji1Hg0Fe9Dc8Ba7"
    _rnd = "password=" + _key[-30:]
    _rnd2 = "password: " + _key[-30:]
    _dry_k = [_rep(["--kind", "idea", "--what", "it broke with " + v, "--file"]) for v in (_key, _rnd, _rnd2)]
    ck("report-key-shaped-and-long-random-password-are-refused-and-nothing-sent",
       [(r[0], "credential" in r[2], r[2].count("\n") > 0, v[-12:] in r[1] + r[2], r[3]) for r, v in zip(_dry_k, (_key, _rnd, _rnd2))],
       [(2, True, True, False, 0)] * 3)
    _sent = _rep(["--kind", "idea", "--what", "the password is " + _key[-30:]])
    ck("report-long-random-password-inside-a-sentence-is-not-refused",
       (_sent[0], _key[-30:] in _sent[1], _sent[3]), (0, True, 0))
    _known = ("A" + "Q." + "A1b2C3d4" * 5 + "A1b2", "gh" + "p_" + "A1b2C3d4e5" * 4, _key)
    _unknown = "zq" + "xk-" + "Ab3dE6gH9jK2mN5pQ8sT1vW4yZ7bC0eF3hJ6kL9n"
    _dry_known = [_rep(["--kind", "idea", "--what", "it broke with " + v]) for v in _known]
    _dry_unk = _rep(["--kind", "idea", "--what", "it broke with " + _unknown])
    ck("report-known-key-formats-are-refused-and-an-unknown-one-passes-a-dry-run",
       ([(r[0], "credential" in r[2], v[-12:] in r[1] + r[2]) for r, v in zip(_dry_known, _known)],
        (_dry_unk[0], _unknown in _dry_unk[1], "not filed -- add --file" in _dry_unk[1], _dry_unk[3])),
       ([(2, True, False)] * 3, (0, True, True, 0)))
    _fam = {
        "GitHub": "gh" + "p_" + "A1b2C3d4e5" * 4, "GitLab": "gl" + "pat-" + "A1b2C3d4e5" * 2,
        "AWS": "AK" + "IA" + "Q3EGR7WZ5LXHJ2PN", "Slack": "xo" + "xb-" + "A1b2C3d4e5" * 2,
        "OpenAI": "sk-" + "proj-" + "A1b2C3d4" * 5, "OpenRouter": "sk-" + "or-v1-" + "0123456789abcdef" * 4,
        "Anthropic": _key, "Google": "AI" + "za" + "A1b2C3d4" * 4 + "A1b", "Stripe": "sk" + "_live_" + "A1b2C3d4" * 3,
        "Shopify": "sh" + "pat_" + "A1b2C3d4" * 4, "Groq": "gs" + "k_" + "A1b2C3d4" * 5,
        "Hugging Face": "h" + "f_" + "A1b2C3d4" * 4, "npm": "np" + "m_" + "A1b2C3d4e5f6" * 3,
    }
    ck("report-every-key-family-the-texts-name-is-refused",
       [n for n, v in _fam.items() if _rep(["--kind", "idea", "--what", "it broke with " + v])[0] != 2], [])
    def _no_gh(argv, **_k):
        _gh.append(argv)
        raise FileNotFoundError(2, "No such file or directory", "gh")

    class _Bad:
        returncode, stdout, stderr = 1, "", "gh: To get started with GitHub CLI, please run:  gh auth login\nsecond line"

    def _bad_gh(argv, **_k):
        _gh.append(argv)
        return _Bad()
    _good = ["--kind", "idea", "--what", "a sidebar"]
    _r1 = _rep(_good + ["--file"], run=_no_gh)
    ck("report-no-gh-program-is-one-line-rc1-and-says-nothing-was-filed",
       (_r1[0], _r1[2].count("\n"), "gh" in _r1[2] and "install" in _r1[2], "nothing was filed" in _r1[2].lower(), "Traceback" in _r1[2], _r1[3]),
       (1, 1, True, True, False, 1))
    _r2 = _rep(_good + ["--file"], run=_bad_gh)
    ck("report-gh-failing-is-rc1-and-its-first-stderr-line-only",
       (_r2[0], _r2[2].count("\n"), "gh auth login" in _r2[2], "second line" in _r2[2] + _r2[1], _r2[3]), (1, 1, True, False, 1))
    with _tf.TemporaryDirectory() as _td2:
        _gone, _bin, _unr, _ok8 = (os.path.join(_td2, n) for n in ("nope.txt", "bin.dat", "unreadable.txt", "ok.txt"))
        with open(_bin, "wb") as _fb:
            _fb.write(b"before \xff\xfe after")
        with open(_unr, "w", encoding="utf-8") as _fh:
            _fh.write("x")
        os.chmod(_unr, 0)
        with open(_ok8, "w", encoding="utf-8") as _fh:
            _fh.write("fine text")
        _tr = {n: _rep(_good + ["--test", p, "--file"]) for n, p in
               (("gone", _gone), ("dir", _td2), ("unreadable", _unr), ("bin", _bin), ("ok", _ok8))}
        _tr["bindry"] = _rep(_good + ["--test", _bin])
        os.chmod(_unr, 0o600)
    for _n in ("gone", "dir") + (("unreadable",) if os.getuid() != 0 else ()):
        _p = {"gone": _gone, "dir": _td2, "unreadable": _unr}[_n]
        ck(f"report-test-file-{_n}-is-rc2-names-the-path-in-one-line-and-files-nothing",
           (_tr[_n][0], _tr[_n][2].count("\n"), _p in _tr[_n][2], "Traceback" in _tr[_n][2], _tr[_n][3]), (2, 1, True, False, 0))
    ck("report-test-file-not-utf8-is-read-with-replacement-and-the-preview-says-bytes-could-not-be-read",
       (_tr["bin"][0], "some bytes could not be read as text" in _tr["bin"][1], _tr["bin"][3],
        _tr["bindry"][0], "some bytes could not be read as text" in _tr["bindry"][1], "before " in _tr["bindry"][1], _tr["bindry"][3]),
       (0, True, 1, 0, True, True, 0))
    ck("report-test-file-that-is-text-says-no-such-thing-negative-control",
       (_tr["ok"][0], "could not be read as text" in _tr["ok"][1], _tr["ok"][3]), (0, False, 1))
    for _n, _f in (("not-a-report-form", '(issue :what "x")'), ("does-not-parse", '(report :kind idea :what "x'),
                   ("empty", ""), ("no-fields", "(report)")):
        _rf = _rep(["--form", _f, "--file"])
        ck(f"report-form-{_n}-is-rc2-in-one-line-and-files-nothing",
           (_rf[0], _rf[2].count("\n"), "form" in _rf[2], "Traceback" in _rf[2], _rf[3]), (2, 1, True, False, 0))
    _cp = check_prompt("When did WW2 end?", "1946, in May.")
    ck(
        "check-prompt-carries-question-and-answer-and-nothing-of-yours",
        (
            "When did WW2 end?" in _cp,
            "1946, in May." in _cp,
            "You are Thomas" in _cp,
            "did not write it" in _cp,
        ),
        (True, True, False, True),
    )
    ck(
        "parse-check-reads-marked-lines-only",
        parse_check(
            "Here you go:\nDOUBT | it ended in 1946 | it ended in 1945\nOK | in May | V-E Day was 8 May\nthanks"
        ),
        [("DOUBT", "it ended in 1946", "it ended in 1945"), ("OK", "in May", "V-E Day was 8 May")],
    )
    ck(
        "parse-check-ignores-unmarked-and-empty-claims",
        parse_check("NONE\nMAYBE | x | y\nOK |  | z"),
        [],
    )
    with tempfile.TemporaryDirectory() as _d:
        _seen: list = []
        _lines: list = []
        ck(
            "check-with-no-turns-says-so",
            check_turn({}, "free", os.path.join(_d, "none.jsonl"), out=_lines.append),
            1,
        )
        _c = os.path.join(_d, "c.jsonl")
        with open(_c, "w") as _fh:
            _fh.write('{"you": "When did WW2 end?", "thomas": "1946, in May."}\n')

        def _fake(cfg, kind, prompt, rotate=False):
            _seen.append((kind, rotate, "1946" in prompt))
            return 0, "DOUBT | it ended in 1946 | 1945", "", ""

        _lines.clear()
        ck(
            "check-asks-a-rotated-fresh-call-and-reports-the-doubt",
            (check_turn({}, "free", _c, _call=_fake, out=_lines.append, asks=os.path.join(_d, "a.jsonl")), _seen, _lines[-1].strip()),
            (0, [("free", True, True)], "1 claim(s): 0 OK, 1 doubted, 0 unsure."),
        )
        _lines.clear()
        check_turn(
            {},
            "free",
            _c,
            _call=lambda *a, **k: (0, "Nonetheless, this is wrong.", "", ""),
            out=_lines.append,
            asks=os.path.join(_d, "a.jsonl"),
        )
        ck(
            "check-shows-an-unparsed-objection-instead-of-no-claims",
            _lines[-1].strip(),
            "Nonetheless, this is wrong.",
        )
    with tempfile.TemporaryDirectory() as _d:
        import json as _json

        _ca = os.path.join(_d, "c.jsonl")
        with open(_ca, "w") as _fh:
            _fh.write('{"you": "When did WW2 end?", "thomas": "1946, in May."}\n')
        _ap = os.path.join(_d, "sub", "asks.jsonl")

        def _read_rows():
            try:
                with open(_ap) as _fh:
                    return [_json.loads(x) for x in _fh]
            except OSError:
                return []

        check_turn(
            {},
            "free",
            _ca,
            _call=lambda *a, **k: (0, "DOUBT | 1946 | 1945\nOK | May | yes\nUNSURE | WW2 | which theatre", "", ""),
            out=lambda *_a: None,
            asks=_ap,
        )
        check_turn({}, "free", _ca, _call=lambda *a, **k: (1, "", "", "busy"), out=lambda *_a: None, asks=_ap)
        check_turn({}, "free", _ca, _call=lambda *a, **k: (0, "NONE", "", ""), out=lambda *_a: None, asks=_ap)
        ck(
            "check-records-one-row-per-check-with-counts-only-when-it-ran",
            [{k: v for k, v in r.items() if k != "t"} for r in _read_rows()],
            [
                {"kind": "check", "brain": "free", "ok": True, "claims": 3, "OK": 1, "DOUBT": 1, "UNSURE": 1},
                {"kind": "check", "brain": "free", "ok": False},
                {"kind": "check", "brain": "free", "ok": True, "claims": 0, "OK": 0, "DOUBT": 0, "UNSURE": 0},
            ],
        )
        _before = len(_read_rows())
        check_turn({}, "free", os.path.join(_d, "none.jsonl"), out=lambda *_a: None, asks=_ap)
        check_turn({"memory": {":keep": None}}, "free", _ca, out=lambda *_a: None, asks=_ap)
        ck("check-that-never-called-the-brain-records-nothing", len(_read_rows()) - _before, 0)
    ck(
        "parse-check-reads-a-mark-dressed-in-markdown",
        parse_check("**DOUBT** | it ended in 1946 | 1945\n- `OK`: | Berlin fell | May 1945"),
        [("DOUBT", "it ended in 1946", "1945"), ("OK", "Berlin fell", "May 1945")],
    )
    ck(
        "take-brain-reads-the-flag-and-leaves-the-rest",
        (
            take_brain(["x", "--brain", "free", "y"], "claude"),
            take_brain(["x"], "claude"),
            take_brain(["--brain"], "c"),
        ),
        (("free", ["x", "y"]), ("claude", ["x"]), (None, ["--brain"])),
    )
    ck(
        "check-hint-after-an-answer-names-the-command",
        (
            check_hint(True, False, "thomas", "claude", "claude"),
            check_hint(True, False, "/home/u/.local/share/thomas/thomas", "claude", "claude"),
            check_hint(True, False, "thomas", "free", "claude"),
        ),
        (
            "\n  Want a second opinion on that answer? Run:  thomas check",
            "\n  Want a second opinion on that answer? Run:  /home/u/.local/share/thomas/thomas check",
            "\n  Want a second opinion on that answer? Run:  thomas check --brain free",
        ),
    )
    ck(
        "check-hint-quotes-a-path-with-a-space-so-it-pastes",
        (check_hint(True, False, "/opt/my tools/thomas", "claude", "claude"),  # not a home path: thomas ships in the kit
         check_hint(True, False, "/home/u/thomas", "claude", "claude")),  # NEAR-MISS: a plain path stays unquoted
        ("\n  Want a second opinion on that answer? Run:  '/opt/my tools/thomas' check",
         "\n  Want a second opinion on that answer? Run:  /home/u/thomas check"),
    )
    ck(
        "check-hint-silent-once-checked-or-with-keep-off-or-no-argv0",
        (
            check_hint(True, True, "thomas", "claude", "claude"),
            check_hint(False, False, "thomas", "claude", "claude"),
            check_hint(True, False, "", "claude", "claude"),
        ),
        (None, None, "\n  Want a second opinion on that answer? Run:  thomas check"),
    )
    with tempfile.TemporaryDirectory() as _d:
        _hk = os.path.join(_d, "asks.jsonl")
        _before = has_checked(_hk)  # missing file
        record_ask(True, 3, 4, "claude", path=_hk)
        with open(_hk, "a") as _fh:
            _fh.write("not json\n")
        _asked_only = has_checked(_hk)
        record_check(True, {"OK": 1}, "claude", path=_hk)  # the real writer's row is what silences the hint
        ck("has-checked-reads-the-check-row-record-check-writes", (_before, _asked_only, has_checked(_hk)), (False, False, True))
    with tempfile.TemporaryDirectory() as _d:
        _lines.clear()
        _n = check_turn(
            {"memory": {":keep": None}}, "free", os.path.join(_d, "none.jsonl"), out=_lines.append
        )
        ck("check-with-keep-off-says-why", (_n, "keep nil" in _lines[-1]), (1, True))
        _old = os.path.join(_d, "old.jsonl")
        with open(_old, "w") as _fh:
            _fh.write('{"you": "Q1", "thomas": "old"}\n')
        _lines.clear()
        _asked: list = []

        def _counting_call(*a, **k):
            _asked.append(1)
            return 0, "NONE", "", ""

        _n = check_turn(
            {"memory": {":keep": None}}, "free", _old, _call=_counting_call, out=_lines.append, asks=os.path.join(_d, "a.jsonl")
        )
        ck("check-with-keep-off-ignores-old-rows", (_n, _asked, "keep nil" in _lines[-1]), (1, [], True))
        _c2 = os.path.join(_d, "c.jsonl")
        with open(_c2, "w") as _fh:
            _fh.write('{"you": "q", "thomas": "a"}\n')
        _lines.clear()
        check_turn(
            {},
            "free",
            _c2,
            _call=lambda *a, **k: (1, "", "", "busy, try again."),
            out=_lines.append,
            asks=os.path.join(_d, "a.jsonl"),
        )
        ck(
            "check-error-ends-with-one-period",
            _lines[-1],
            "The check could not run: busy, try again.",
        )
    ck(
        "free-rotate-starts-from-a-different-model",
        (rotated(["a", "b", "c"], True), rotated(["a", "b", "c"], False), rotated(["a"], True)),
        (["b", "c", "a"], ["a", "b", "c"], ["a"]),
    )
    with tempfile.TemporaryDirectory() as _d:
        import json as _json

        _p = os.path.join(_d, "sub", "asks.jsonl")
        record_ask(True, 12, 345, "claude", path=_p, now=1000)
        record_ask(False, 3, 0, "codex", path=_p, now=1001)
        with open(_p) as _fh:
            _rows = [_json.loads(x) for x in _fh]
        ck(
            "ask-history-one-line-per-ask-lengths-only-never-text",
            _rows,
            [
                {"t": 1000, "brain": "claude", "ok": True, "prompt_chars": 12, "reply_chars": 345},
                {"t": 1001, "brain": "codex", "ok": False, "prompt_chars": 3, "reply_chars": 0},
            ],
        )
        ck("ask-history-file-is-owner-only", oct(os.stat(_p).st_mode & 0o777), "0o600")
        ck(
            "ask-history-unwritable-never-raises",
            record_ask(True, 1, 1, "claude", path="/dev/null/x/asks.jsonl")["ok"],
            True,
        )
    ck(
        "ask-flags-everything-off-unless-opted-in",
        (
            ask_flags({}, "gemini"),
            ask_flags({":autonomy": True, ":borrow-credentials": True, ":ledger": True}, "claude"),
        ),
        (["--mode", "default", "--no-borrow", "--no-ledger"], []),
    )
    ck(
        "ask-flags-asking-mode-runs-in-the-scratch-folder-autonomy-does-not",
        (ask_flags({}, "claude", "/tmp/s")[:4], ask_flags({":autonomy": True}, "claude", "/tmp/s")),
        (["--mode", "default", "--cwd", "/tmp/s"], ["--no-borrow", "--no-ledger"]),
    )
    ck(
        "help-names-the-scratch-folder-and-what-is-verified",
        (
            "scratch folder" in USAGE,
            "anywhere your user account can" in USAGE and "whoami" in USAGE,
        ),
        (True, True),
    )
    ck(
        "brain-model-reaches-claude-and-only-claude",
        (brain_env({":model": "claude-sonnet-5-5"}, "claude"), brain_env({":model": None}, "claude"),
         brain_env({":model": "  "}, "claude"), brain_env({}, "claude"),
         brain_env({":model": "x"}, "gemini")[0], bool(brain_env({":model": "x"}, "gemini")[1])),
        (({"ANTHROPIC_MODEL": "claude-sonnet-5-5"}, ""), ({}, ""), ({}, ""), ({}, ""), {}, True),
    )
    ck(
        "ask-flags-safe-mode-is-per-agent-and-nil-is-off",
        (ask_flags({":autonomy": None}, "codex")[:2], ask_flags({":ledger": True}, "claude")),
        (["--mode", "read-only"], ["--mode", "default", "--no-borrow"]),
    )
    ck(
        "confinement-refuses-unproven-brains-unless-autonomy",
        (
            confinement_refusal({}, "claude"),
            confinement_refusal({}, "codex") is not None,
            confinement_refusal({":autonomy": None}, "gemini") is not None,
            confinement_refusal({":autonomy": True}, "codex"),
        ),
        (None, True, True, None),
    )
    ready = {
        "py": (3, 12),
        "redis_mod": True,
        "config": "/kit/thomas.sexpr",
        "chosen": "claude",
        "agents": ("claude", "codex"),
        "adapter": "claude-agent-acp",
        "adapter_on_path": True,
        "node": 22,
        "probe_ok": True,
        "claude_login": True,
    }
    ck("doctor-ready-machine-has-no-gaps", [w for ok, w, _ in doctor_checks(ready) if not ok], [])
    ck(
        "doctor-claude-brain-without-a-login-is-a-gap",
        [
            w.split(" (")[0]
            for ok, w, _ in doctor_checks({**ready, "claude_login": False})
            if not ok
        ],
        ["logged in to Claude"],
    )
    signin = "Next: sign in"
    ck("next-signed-in-skips-login", any(signin in s for s in next_steps(ready, "T")), False)
    ck(
        "next-logged-out-asks-login",
        next_steps({**ready, "claude_login": False}, "T")[0].startswith(signin),
        True,
    )
    ck(
        "next-free-with-key-skips-login",
        any(
            signin in s
            for s in next_steps(
                {**ready, "chosen": FREE, "free_ready": True, "claude_login": False}, "T"
            )
        ),
        False,
    )
    ck(
        "next-free-without-key-asks-login",
        next_steps({**ready, "chosen": FREE, "free_ready": False}, "T")[0].startswith(signin),
        True,
    )
    ck(
        "next-shows-the-given-command",
        next_steps(ready, "/k/thomas")[-1].endswith('/k/thomas ask "hello"'),
        True,
    )
    ck(
        "next-signed-in-with-a-gap-says-fix-first",
        next_steps({**ready, "node": 18}, "T")[0].startswith("Next: fix"),
        True,
    )
    ck(
        "next-codex-names-its-own-login",
        "codex brain" in next_steps({**ready, "chosen": "codex"}, "T")[0],
        True,
    )
    newbie = {
        **ready,
        "redis_mod": False,
        "config": None,
        "chosen": None,
        "adapter": None,
        "node": 18,
        "probe_ok": False,
    }
    ck(
        "doctor-names-every-audit-gap",
        [w.split(" (")[0] for ok, w, _ in doctor_checks(newbie) if not ok],
        [
            "the redis package for Python",
            "the shipped defaults",
            "a chosen brain",
            "acp-probe can launch",
        ],
    )
    ck(
        "doctor-node-18-is-a-gap-for-the-claude-adapter-node-22-is-not",
        (
            [ok for ok, w, _ in doctor_checks({**ready, "node": 18}) if w.startswith("Node")],
            [
                ok
                for ok, w, _ in doctor_checks({**ready, "adapter_on_path": False})
                if w.startswith("the ") and w.endswith("adapter")
            ],
        ),
        ([False], [False]),
    )
    ck(
        "auth-hint-names-the-login-only-for-an-auth-failure",
        (
            auth_hint("claude", "RequestError: Authentication required"),
            auth_hint("claude", "sample text"),
        ),
        (
            "your claude brain needs YOUR login first: run `thomas login`, then ask again.",
            None,
        ),
    )
    ck(
        "sdk-claude-paths-cover-nested-and-hoisted",
        sdk_claude_paths(
            "/k/adapter/node_modules/@agentclientprotocol/claude-agent-acp/dist/index.js"
        ),
        [
            "/k/adapter/node_modules/@agentclientprotocol/claude-agent-acp/node_modules/@anthropic-ai",
            "/k/adapter/node_modules/@anthropic-ai",
        ],
    )
    ck(
        "logged-in-reads-the-field-and-fails-closed",
        (
            logged_in(
                "b",
                _run=lambda *a, **k: subprocess.CompletedProcess(a, 0, '{"loggedIn": true}', ""),
            ),
            logged_in(
                "b",
                _run=lambda *a, **k: subprocess.CompletedProcess(a, 1, '{"loggedIn": false}', ""),
            ),
            logged_in("b", _run=lambda *a, **k: subprocess.CompletedProcess(a, 1, "not json", "")),
            logged_in(None),
        ),
        (True, False, None, None),
    )
    ck(
        "logged-in-renamed-or-non-bool-field-is-unreadable-not-logged-out",
        tuple(
            logged_in("b", _run=lambda *a, o=o, **k: subprocess.CompletedProcess(a, 0, o, ""))
            for o in ('{"logged_in": true}', '{"loggedIn": "yes"}', "[true]")
        ),
        (None, None, None),
    )
    g = globals()
    real_li, real_cb = g["logged_in"], g["claude_binary"]
    saved = {k: os.environ.pop(k, None) for k in ("ANTHROPIC_API_KEY", "CLAUDE_CODE_OAUTH_TOKEN")}
    try:
        claude_cfg = {"brain": {":kind": "claude"}}
        verdicts = []
        for binary, state in (("b", False), ("b", None), ("b", True), (None, None)):
            g["claude_binary"] = lambda b=binary: b
            g["logged_in"] = lambda _b, s=state: s
            verdicts.append(_facts(claude_cfg)["claude_login"])
    finally:
        g["logged_in"], g["claude_binary"] = real_li, real_cb
        os.environ.update({k: v for k, v in saved.items() if v is not None})
    ck(
        "facts-login-gap-on-logged-out-or-no-binary-not-on-unreadable",
        verdicts,
        [False, True, True, False],
    )
    import tempfile as _tf

    fd = _tf.mkdtemp()
    fcfg, fkey, fmod = (os.path.join(fd, n) for n in ("thomas.sexpr", "g.key", "g.model"))
    rc_ok = free_login(
        fcfg,
        _getpass=lambda _p: "KEY",
        _check=lambda k: (["a/b:free", "c/d:free"], ""),
        key_path=fkey,
        model_path=fmod,
    )
    with open(fcfg, encoding="utf-8") as fh:
        cfg_text = fh.read()
    rc_bad = free_login(
        os.path.join(fd, "b.sexpr"),
        _getpass=lambda _p: "BAD",
        _check=lambda k: ([], "nope"),
        key_path=os.path.join(fd, "b.key"),
        model_path=os.path.join(fd, "b.model"),
    )
    ck(
        "free-login-saves-0600-and-chooses-free-brain-bad-key-saves-nothing",
        (
            rc_ok,
            thomas_config.parse(cfg_text).get("brain", {}).get(":kind") == FREE,
            oct(os.stat(fkey).st_mode & 0o777),
            oct(os.stat(fmod).st_mode & 0o777),
            rc_bad,
            os.path.exists(os.path.join(fd, "b.key")),
        ),
        (0, True, "0o600", "0o600", 1, False),
    )
    ck("free-brain-needs-no-confinement", confinement_refusal({}, FREE), None)
    ck(
        "try-hint-uses-the-full-path-until-a-new-terminal-finds-THIS-thomas",
        (try_cmd(lambda _n: "/k/thomas", "/k/thomas"), try_cmd(lambda _n: None, "/k/thomas"),
         try_cmd(lambda _n: "/usr/local/bin/thomas", "/k/thomas"), try_cmd(lambda _n: None, "/my apps/thomas")),
        ("thomas", "/k/thomas", "/k/thomas", "'/my apps/thomas'"),
    )
    ck(
        "claude-sign-in-refused-on-a-mac-when-HOME-is-not-the-account-home",
        (
            keychain_home_mismatch("darwin", "/tmp/x", "/acct/a")
            is not None,  # placeholder paths: only equality
            keychain_home_mismatch("darwin", "/acct/a", "/acct/a"),  # matters to this check
            keychain_home_mismatch("linux", "/tmp/x", "/home/a"),
        ),
        (True, None, None),
    )
    ck(
        "doctor-free-brain-without-key-names-login-free",
        [
            fix
            for ok, w, fix in doctor_checks(
                {
                    **ready,
                    "chosen": FREE,
                    "agents": (*acp_lib.AGENTS, FREE),
                    "adapter": None,
                    "free_ready": False,
                }
            )
            if not ok
        ],
        ["run `thomas login --free` -- it explains how to get a free key from openrouter.ai/keys"],
    )
    ck(
        "help-is-user-facing",
        ("src/" in USAGE, "thomas doctor" in USAGE),
        (False, True),
    )
    ck(
        "help-only-argv",
        [help_only(a) for a in (["thomas", "--help"], ["thomas", "-h"], ["thomas", "help"], ["thomas"],
                                ["thomas", "ask", "--help"], ["thomas", "help", "me"], ["thomas", "--helpx"])],
        [True, True, True, False, False, False, False],
    )
    hp = subprocess.run([sys.executable, "-X", "importtime", ENTRY, "--help"],
                        capture_output=True, text=True, timeout=60, check=False)
    imported = {ln.rsplit("|", 1)[-1].strip() for ln in hp.stderr.splitlines() if ln.startswith("import time:")}
    ck(
        "help-before-heavy-imports",
        (hp.returncode, hp.stdout.rstrip("\n") == USAGE, bool(imported),
         sorted(m for m in ("acp_lib", "thomas_config", "subprocess", "shutil", "front_door") if m in imported)),
        (0, True, True, []),
    )
    with open(ENTRY, "rb") as _lfh:
        _entry_src = _lfh.read()
    ck(
        "launcher-small-body-imported",
        (len(_entry_src) < 6000, b'__import__("front_door")' in _entry_src),
        (True, True),
    )

    def _shebang_imports(*args):
        p = subprocess.run([ENTRY, *args], capture_output=True, text=True, timeout=60,
                           check=False, env={**os.environ, "PYTHONPROFILEIMPORTTIME": "1"})
        names = [ln.rsplit("|", 1)[-1].strip() for ln in p.stderr.splitlines() if ln.startswith("import time:")]
        return p.returncode, names

    _hrc, _hnames = _shebang_imports("--help")
    _crc, _cnames = _shebang_imports("config")
    with open(ENTRY) as _sfh:
        _has_S = " -S" in _sfh.readline()
    _site_back = (_crc, all(m in _cnames for m in ("site", "sitecustomize", "acp_lib")),
                  "sitecustomize" in _cnames and "acp_lib" in _cnames
                  and _cnames.index("sitecustomize") < _cnames.index("acp_lib"))
    ck(
        "help-skips-site-commands-restore-it" if _has_S else "commands-restore-site-before-acp_lib (shebang has no -S: the help half is skipped)",
        (*((_hrc, bool(_hnames), [m for m in ("site", "sitecustomize") if m in _hnames]) if _has_S else (0, True, [])),
         *_site_back),
        (0, True, [], 0, True, True),
    )
    with tempfile.TemporaryDirectory() as _d:
        _link = os.path.join(_d, "thomas")
        os.symlink(ENTRY, _link)
        _out = subprocess.run(
            [sys.executable, _link, "doctor"],
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        ).stdout  # doctor exits 1 when a gap exists; the case reads the acp-probe line, not the code
    _beside = os.path.isfile(os.path.join(os.path.dirname(os.path.realpath(__file__)), "acp-probe"))
    ck(
        "doctor-through-a-symlink-looks-beside-the-real-file",
        [ln.split()[0] for ln in _out.splitlines() if "acp-probe can launch" in ln],
        ["ok" if _beside else "MISSING"],
    )
    ck(
        "preamble-designed",
        persona_preamble({":name": "Sam", ":pronouns": "she/her", ":voice": "dry"}),
        "You are Sam, the user's assistant.\nPronouns: she/her.\nVoice: dry",
    )
    ck("preamble-skips-unset", "None" in persona_preamble({":name": "T", ":voice": None}), False)
    ck(
        "brains-installed-flag",
        brains({"a": {"cmd": ["x"]}, "b": {"cmd": ["y", "--acp"]}}, lambda c: c == "x"),
        [("a", True, "x"), ("b", False, "y --acp")],
    )
    ck("set-form-creates", set_form([], "persona", ":name", "Sam"), [["persona", ":name", "Sam"]])
    ck(
        "set-form-replaces-one-key",
        set_form(
            [["persona", ":name", "A", ":voice", "v"], ["brain", ":kind", "codex"]],
            "persona",
            ":name",
            "B",
        ),
        [["persona", ":name", "B", ":voice", "v"], ["brain", ":kind", "codex"]],
    )
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, "thomas.sexpr")
        shipped = os.path.join(td, "shipped.sexpr")
        with open(shipped, "w", encoding="utf-8") as fh:
            fh.write('(brain :kind claude :model nil)\n(persona :name "Thomas")\n')
        persona_set(":name", "Sam", p)
        persona_set(":personality", 'says "no" plainly', p)
        merged = thomas_config.load(env={}, default=shipped, user=p)
        ck(
            "persona-set-round-trips",
            (merged["persona"][":name"], merged["persona"][":personality"]),
            ("Sam", 'says "no" plainly'),
        )
        ck("persona-set-keeps-shipped-keys", merged["brain"].get(":kind"), "claude")
        try:
            persona_set(":image", "/nonexistent/x.png", p)
            img = "accepted"
        except SystemExit:  # the refusal IS the expected outcome under test; ck("image-must-exist") asserts it
            img = "refused"
        ck("image-must-exist", img, "refused")
    _t = [{"you": f"q{i}", "thomas": f"a{i}"} for i in range(5)]
    ck("history-empty-is-empty-string", history_block([]), "")
    ck(
        "history-keeps-the-newest-max-turns",
        [x for x in ("q0", "q1", "q2", "q3", "q4") if f"User: {x}\n" in history_block(_t, 2)],
        ["q3", "q4"],
    )
    ck(
        "history-drops-oldest-whole-turn-to-fit",
        [
            x
            for x in ("q0", "q1", "q2", "q3", "q4")
            if f"User: {x}\n" in history_block(_t, 8, max_chars=20)
        ],
        ["q4"],
    )
    ck("history-skips-a-turn-with-no-reply", history_block([{"you": "q", "thomas": ""}]), "")
    ck("history-zero-turns-is-off", history_block(_t, 0), "")
    ck("prompt-without-memory-is-the-old-prompt", compose_prompt("P", "", "", "hi"), "P\n\nhi")
    _cp = compose_prompt("P", "- likes tea\n", "H", "hi")
    ck(
        "prompt-order-persona-notes-history-message",
        [_cp.index(x) for x in ("P", "likes tea", "H", "The user now says:\nhi")]
        == sorted(_cp.index(x) for x in ("P", "likes tea", "H", "The user now says:\nhi")),
        True,
    )
    ck("memory-on-by-default", memory_settings({}), (True, 8))
    ck(
        "memory-nil-turns-it-off",
        memory_settings({"memory": {":keep": None, ":turns": "3"}}),
        (False, 3),
    )
    ck("memory-bad-turns-is-8", memory_settings({"memory": {":turns": "lots"}}), (True, 8))
    with tempfile.TemporaryDirectory() as _d:
        _c = os.path.join(_d, "x", "conversation.jsonl")
        _private_append(_c, '{"you": "a", "thomas": "b"}\n')
        _private_append(_c, "torn{\n")
        ck("conversation-file-is-owner-only", oct(os.stat(_c).st_mode & 0o777), "0o600")
        ck("conversation-torn-line-skipped", load_turns(_c), [{"you": "a", "thomas": "b"}])
        ck("conversation-missing-is-empty", load_turns(os.path.join(_d, "none")), [])
        ck("notes-missing-is-empty", read_notes(os.path.join(_d, "none")), "")
        _bad = os.path.join(_d, "bad.jsonl")
        with open(_bad, "wb") as _bw:
            _bw.write(
                b'[1,2]\n5\nnull\n{"you": 3, "thomas": "x"}\n\xff\xfe junk\n{"you": "q", "thomas": "a"}\n'
            )
        ck(
            "conversation-non-objects-and-bad-bytes-skipped",
            load_turns(_bad),
            [{"you": "q", "thomas": "a"}],
        )
        _bn = os.path.join(_d, "bad.md")
        with open(_bn, "wb") as _bw:
            _bw.write(b"- likes \xe9t\xe9\n")
        ck("notes-in-another-encoding-read-not-crash", read_notes(_bn).startswith("- likes "), True)
    _p = compose_prompt("P\x00", "- note\x00\x00", "H\ud800", "hi\x00")
    ck(
        "prompt-has-no-nul-and-encodes",
        ("\x00" not in _p, len(_p.encode("utf-8")) > 0),
        (True, True),
    )
    ck(
        "long-notes-keep-the-newest",
        compose_prompt("P", "a" * 30000 + "END", "", "q").count("a") <= NOTES_CHARS,
        True,
    )
    ck("deep-nesting-skipped", _deep_ok(), True)

    import contextlib
    import io
    import types
    import typing

    with tempfile.TemporaryDirectory() as td:
        fake: typing.Any = types.ModuleType("thomas_telegram")
        fake.SERVICE_ENV, fake.LOG = "THOMAS_SELFTEST_SVC", os.path.join(td, "log")
        fake.load_conf = lambda: {"token": "t", "owner": 1}
        fake.service_running = lambda *a: False
        fake.service_files = lambda *a: [(os.path.join(td, "svc.plist"), "x")]
        fake.service_commands = lambda *a: [(["launchctl", "bootout"], True)]
        fake.service_probe = lambda *a: ["launchctl", "list"]
        real_tg, real_run = sys.modules.get("thomas_telegram"), subprocess.run
        sys.modules["thomas_telegram"] = fake
        subprocess.run = lambda *a, **k: subprocess.CompletedProcess(  # type: ignore[assignment]
            [], 2, stdout="", stderr="x"
        )
        try:
            with contextlib.redirect_stderr(io.StringIO()), contextlib.redirect_stdout(io.StringIO()):
                urc = telegram_cmd({}, ["uninstall"])
                fake.ConfCorrupt = type("ConfCorrupt", (Exception,), {})

                def _torn():
                    raise fake.ConfCorrupt("torn")

                fake.load_conf = _torn
                subprocess.run = lambda *a, **k: subprocess.CompletedProcess([], 0, stdout="", stderr="")  # type: ignore[assignment]
                torn_rc = (telegram_cmd({}, ["uninstall"]), telegram_cmd({}, ["status"]))
        finally:
            subprocess.run = real_run  # type: ignore[assignment]
            if real_tg is None:
                sys.modules.pop("thomas_telegram", None)
            else:
                sys.modules["thomas_telegram"] = real_tg
        ck("telegram-uninstall-required-command-rc2-fails", urc, 1)
        ck("telegram-uninstall-proceeds-with-a-corrupt-conf-status-refuses", torn_rc, (0, 1))
    import contextlib
    import io

    def _try(fn):
        try:
            return fn()
        except Exception as e:  # noqa: BLE001 -- a raise is a FAIL line with its name, not a dead suite
            return "raised " + type(e).__name__

    def _thomas(files, *args, env_extra=None):
        with tempfile.TemporaryDirectory() as hd:
            os.makedirs(os.path.join(hd, ".thomas"))
            for rel, blob in files.items():
                with open(os.path.join(hd, ".thomas", rel), "wb") as bf:
                    bf.write(blob)
            env = {"HOME": hd, "PATH": os.path.dirname(sys.executable) + ":/usr/bin:/bin",
                   "THOMAS_FREE_API": "http://127.0.0.1:9", "LANG": "en_US.UTF-8", **(env_extra or {})}
            cp = subprocess.run([sys.executable, ENTRY, *args], capture_output=True, text=True, errors="replace",
                                timeout=60, check=False, env=env, stdin=subprocess.DEVNULL)
            left = sorted(os.listdir(os.path.join(hd, ".thomas")))
            kept: dict = {}
            for rel in files:
                try:
                    with open(os.path.join(hd, ".thomas", rel), "rb") as bf:
                        kept[rel] = bf.read()
                except OSError:  # a state file that is gone is reported as missing in kept
                    kept[rel] = None
            return cp.returncode, cp.stdout, cp.stderr, left, kept

    _free = {"thomas.sexpr": b"(brain :kind free)\n"}
    _rc, _out, _err, _l, _k = _thomas({**_free, "openrouter.key": b"\xff\xfe\x80", "free-models": b"a/b:free\n"}, "doctor")
    ck("doctor-on-the-free-brain-reads-a-key-file-that-is-not-utf-8-as-no-key",
       ("Traceback" in _err, "a free OpenRouter key and model list" in _out, _rc), (False, True, 1))
    def _free_turn_on(blob):  # in-process: `ask` stops at doctor's preflight where the interpreter has no redis
        with tempfile.TemporaryDirectory() as hd:
            mf = os.path.join(hd, "free-models")
            with open(mf, "wb") as bf:
                bf.write(blob)
            real_mf, real_key, seen, buf = globals()["FREE_MODEL_FILE"], os.environ.get("OPENROUTER_API_KEY"), [], io.StringIO()

            def _fake_ask(pr, key, models):
                seen.append(models)
                return 0, "ok", ""

            globals()["FREE_MODEL_FILE"], os.environ["OPENROUTER_API_KEY"] = mf, "k"
            try:
                with contextlib.redirect_stderr(buf):
                    res = free_turn("hi", _ask=_fake_ask)
            finally:
                globals()["FREE_MODEL_FILE"] = real_mf
                if real_key is None:
                    os.environ.pop("OPENROUTER_API_KEY", None)
                else:
                    os.environ["OPENROUTER_API_KEY"] = real_key
            return res, seen, buf.getvalue().replace(mf, "<list>")

    _res = _try(lambda: _free_turn_on(b"\xff\xfe\x80"))
    ck("free-turn-with-a-model-list-that-is-not-utf-8-gives-the-one-line-message-and-asks-nobody",
       _res if isinstance(_res, str) else (_res[0][0], _res[1], _res[2]),
       (1, [], "thomas: free-model list unreadable at <list> (UnicodeDecodeError); treated as empty\n"))
    _res = _try(lambda: _free_turn_on(b"%%not [1, ab\n"))
    ck("free-turn-with-a-model-list-of-only-junk-behaves-as-no-list",
       _res if isinstance(_res, str) else (_res[0][0], _res[1], _res[2]), (1, [], ""))
    _res = _try(lambda: _free_turn_on(b"%%not a/b:free [1,\n"))
    ck("free-turn-keeps-the-plausible-ids-control",
       _res if isinstance(_res, str) else (_res[0][0], _res[1]), (0, [["a/b:free"]]))
    def _free_turn_key(blob):  # audit 11: a key file that is not a single-line key says so, names the path, asks nobody
        import thomas_free

        with tempfile.TemporaryDirectory() as hd:
            kf, mf = os.path.join(hd, "openrouter.key"), os.path.join(hd, "free-models")
            for pth, data in ((kf, blob), (mf, b"a/b:free\n")):
                with open(pth, "wb") as bf:
                    bf.write(data)
            real = (thomas_free.KEY_FILE, globals()["FREE_MODEL_FILE"], os.environ.pop("OPENROUTER_API_KEY", None))
            thomas_free.KEY_FILE, globals()["FREE_MODEL_FILE"] = kf, mf
            seen = []

            def _fake_ask(pr, key, models):
                seen.append(models)
                return 0, "ok", ""

            try:
                res = free_turn("hi", _ask=_fake_ask)
            finally:
                thomas_free.KEY_FILE, globals()["FREE_MODEL_FILE"] = real[0], real[1]
                if real[2] is not None:
                    os.environ["OPENROUTER_API_KEY"] = real[2]
            return res[0], len(seen), "not a single-line key" in res[2], kf in res[2], "exam" in res[2].replace(kf, "")

    _kx = "sk-or-v1-" + "exam" + "ple-0123456789abcdef"
    ck("free-turn-with-a-two-line-key-file-says-so-names-the-path-and-asks-nobody",
       _try(lambda: _free_turn_key((_kx + "\n# my notes\n").encode())), (1, 0, True, True, False))
    for _lbl, _blob in (("two-line", (_kx + "\n# my notes\n").encode()), ("non-latin-1", (_kx + "\u0100\n").encode("utf-8"))):
        _rc, _out, _err, _l, _k = _thomas({**_free, "openrouter.key": _blob, "free-models": b"a/b:free\n"}, "doctor")
        ck("doctor-with-a-" + _lbl + "-key-file-says-it-is-not-a-single-line-key-and-never-prints-the-key",
           ("not a single-line key" in _out, "openrouter.key" in _out, "exam" in _out.replace("openrouter.key", ""), "Traceback" in _err, _rc),
           (True, True, False, False, 1))
    ck("free-turn-control-a-one-line-key-file-with-a-trailing-newline-asks",
       _try(lambda: _free_turn_key((_kx + "\n").encode())), (0, 1, False, False, False))
    _rc, _out, _err, _l, _k = _thomas({**_free, "openrouter.key": b"k\n", "free-models": b"%%not [1, ab\n"}, "doctor")
    ck("doctor-calls-a-model-list-of-only-junk-missing", "MISSING  a free OpenRouter key and model list" in _out, True)
    _bad = "caf\udce9"  # a byte that is not UTF-8, as the shell passes it
    _cfg = {"thomas.sexpr": b"(persona :name \"Sam\")\n"}
    _rc, _out, _err, _l, _k = _thomas(_cfg, "report", "--kind", "idea", "--what", _bad)
    ck("report-with-an-argument-that-is-not-utf-8-is-refused-in-one-line",
       ("Traceback" in _err, len(_err.strip().splitlines()), _rc, _bad in _err), (False, 1, 2, False))
    _rc, _out, _err, _l, _k = _thomas(_cfg, "persona", "set", ":name", _bad)
    ck("persona-set-with-an-argument-that-is-not-utf-8-writes-nothing-and-leaves-no-tmp",
       ("Traceback" in _err, len(_err.strip().splitlines()), _rc, _l, _k["thomas.sexpr"] == _cfg["thomas.sexpr"]),
       (False, 1, 2, ["thomas.sexpr"], True))
    _rc, _out, _err, _l, _k = _thomas(_cfg, "persona", "set", ":name", "Lee")
    ck("persona-set-with-a-plain-argument-still-works-control", (_rc, b"Lee" in (_k["thomas.sexpr"] or b"")), (0, True))
    with tempfile.TemporaryDirectory() as _ud:
        _ucfg = os.path.join(_ud, "thomas.sexpr")
        with open(_ucfg, "wb") as _ub:
            _ub.write(b"(persona :name \xff)\n")

        def _exit_text(fn):
            try:
                fn()
            except SystemExit as e:  # the plain line is the SystemExit's text
                return str(e).replace(_ud, "<dir>")
            except Exception as e:  # noqa: BLE001 -- a raw raise is the defect: the case shows its type
                return "raised " + type(e).__name__
            return "no exit"

        _want = "thomas: <dir>/thomas.sexpr cannot be read as text (UnicodeDecodeError); move it aside"
        ck("persona-set-on-a-config-that-is-not-utf-8-gives-one-plain-line", _exit_text(lambda: persona_set(":name", "Lee", path=_ucfg)), _want)
        ck("set-brain-kind-on-a-config-that-is-not-utf-8-gives-one-plain-line", _exit_text(lambda: set_brain_kind("free", cfg_path=_ucfg)), _want)
        ck("a-config-that-is-not-utf-8-is-left-as-it-was-with-no-tmp", sorted(os.listdir(_ud)), ["thomas.sexpr"])
    def _boom(_argv):
        raise ZeroDivisionError("x")

    def _entry(fn, argv, debug=None):
        real = os.environ.get("THOMAS_DEBUG")
        os.environ.pop("THOMAS_DEBUG", None)
        if debug:
            os.environ["THOMAS_DEBUG"] = debug
        buf = io.StringIO()
        try:
            with contextlib.redirect_stderr(buf):
                rc = run(argv, fn)
        except BaseException as e:  # noqa: BLE001 -- SystemExit and KeyboardInterrupt are what the control looks for
            rc = "passed " + type(e).__name__
        finally:
            os.environ.pop("THOMAS_DEBUG", None)
            if real is not None:
                os.environ["THOMAS_DEBUG"] = real
        return rc, buf.getvalue()

    ck("entry-guard-turns-an-escaped-exception-into-one-plain-line",
       _try(lambda: _entry(_boom, ["thomas", "x"])),
       (1, "thomas: internal error (ZeroDivisionError) -- please run thomas report\n"))
    _dbg = _try(lambda: _entry(_boom, ["thomas", "x"], "1"))
    ck("entry-guard-control-THOMAS_DEBUG-shows-the-traceback",
       (_dbg[0], "Traceback" in _dbg[1], "ZeroDivisionError" in _dbg[1]) if isinstance(_dbg, tuple) else _dbg, (1, True, True))
    ck("entry-guard-lets-SystemExit-and-KeyboardInterrupt-through",
       _try(lambda: (_entry(lambda a: sys.exit(3), ["thomas"])[0], _entry(lambda a: (_ for _ in ()).throw(KeyboardInterrupt()), ["thomas"])[0])),
       ("passed SystemExit", "passed KeyboardInterrupt"))
    ck("entry-guard-does-not-wrap-the-selftest-path", _try(lambda: _entry(_boom, ["thomas", "--selftest"])[0]), "passed ZeroDivisionError")
    ck("entry-guard-passes-a-normal-return-value-through", _try(lambda: _entry(lambda a: 7, ["thomas"])), (7, ""))
    with open(ENTRY, encoding="utf-8") as _lf:
        ck("the-launcher-runs-the-guarded-entry", "front_door.run(sys.argv)" in _lf.read(), True)
    bad = sum(not ok for _n, ok, _g in cases)
    for n, ok, got in cases:
        print(f"  {n:<32} {'PASS' if ok else 'FAIL'}" + ("" if ok else f"  got {got!r}"))
    print(
        "\nthomas --selftest RESULT: "
        + (f"FAIL -- {bad} case(s)" if bad else f"PASS -- {len(cases)} cases")
    )
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(run(sys.argv))
