""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
import sexpr_lib


def default_path(script_dir=None):
    ""
    return os.path.join(script_dir or os.path.dirname(os.path.realpath(__file__)), "thomas.sexpr")


DEFAULT = default_path()
USER = os.path.expanduser("~/.thomas/thomas.sexpr")

SWITCHES = {
    ("brain", ":kind"): "THOMAS_BRAIN",
}


def _atom(v):
    ""
    if v == "nil":
        return None
    if v == "t":
        return True
    return v


def parse(text):
    ""
    out: dict[str, dict] = {}
    for form in sexpr_lib.read_all(text):
        if isinstance(form, list) and form and isinstance(form[0], str):
            body = form[1:]
            pairs = dict(zip(body[0::2], body[1::2]))
            out.setdefault(form[0], {}).update(
                {k: _atom(v) for k, v in pairs.items() if str(k).startswith(":")}
            )
    return out


def merge(*layers):
    ""
    out: dict[str, dict] = {}
    for layer in layers:
        for sec, kv in (layer or {}).items():
            out.setdefault(sec, {}).update(kv)
    return out


def env_layer(env):
    ""
    out: dict[str, dict] = {}
    for (sec, key), var in SWITCHES.items():
        v = env.get(var)
        if v is not None and v != "":
            out.setdefault(sec, {})[key] = {"1": True, "0": None}.get(v, v)
    return out


def _read(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return parse(fh.read())
    except FileNotFoundError:
        return {}


def load(env=None, default=DEFAULT, user=USER):
    ""
    return merge(_read(default), _read(user), env_layer(os.environ if env is None else env))


def section(name, env=None):
    return dict(load(env).get(name, {}))


def get(name, key, default=None, env=None):
    return load(env).get(name, {}).get(key, default)


def selftest():
    cases = []

    def ck(n, got, want):
        cases.append((n, got == want, got))

    shipped = parse('(brain :kind claude :model nil :ledger nil) (persona :name "Thomas")')
    ck(
        "parse-nil-and-strings",
        shipped["brain"],
        {":kind": "claude", ":model": None, ":ledger": None},
    )
    ck("default-is-beside-the-script", default_path("/kit"), "/kit/thomas.sexpr")
    ck("parse-quoted-string", shipped["persona"][":name"], "Thomas")
    user = parse("(brain :kind gemini)")
    m = merge(shipped, user)
    ck(
        "user-overrides-one-key-only",
        m["brain"],
        {":kind": "gemini", ":model": None, ":ledger": None},
    )
    ck(
        "env-overrides-file",
        merge(m, env_layer({"THOMAS_BRAIN": "codex"}))["brain"][":kind"],
        "codex",
    )
    ck("env-0-reads-as-nil", env_layer({"THOMAS_BRAIN": "0"}), {"brain": {":kind": None}})
    ck("env-unset-leaves-file", merge(m, env_layer({}))["brain"][":kind"], "gemini")
    ck(
        "typo-form-ignored",
        parse("(junk) 42 (brain :kind codex)"),
        {"junk": {}, "brain": {":kind": "codex"}},
    )
    live = load(env={}, user=os.devnull)
    ck(
        "shipped-file-defaults-are-all-OFF",
        [live.get("brain", {}).get(k) for k in (":autonomy", ":borrow-credentials", ":ledger")],
        [None, None, None],
    )
    bad = sum(not ok for _n, ok, _g in cases)
    for n, ok, got in cases:
        print(f"  {n:<36} {'PASS' if ok else 'FAIL'}" + ("" if ok else f"  got {got!r}"))
    print(
        "\nthomas_config --selftest RESULT: "
        + (f"FAIL -- {bad} case(s)" if bad else f"PASS -- {len(cases)} cases")
    )
    return 1 if bad else 0


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    for sec, kv in load().items():
        print(f"({sec} " + " ".join(f"{k} {v!r}" for k, v in kv.items()) + ")")
