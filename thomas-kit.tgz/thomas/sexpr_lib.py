#!/usr/bin/env python3
""

import ast as _ast
import re as _re


def head_docs(path):
    ""
    try:
        src = open(path, errors="replace").read().splitlines()
    except OSError:
        return {}
    out = {}
    for i, line in enumerate(src):
        m = _re.match(r"\s*(?:el)?if head (?:==|in)\s*\(?[\"']([a-z][a-z0-9-]*)[\"']", line)
        if not m:
            continue
        heads = [m.group(1)]
        if _re.match(r"\s*(?:el)?if head in", line):
            blob, k = line, i
            while ")" not in blob.split(" in ", 1)[-1] and k + 1 < len(src) and k - i < 24:
                k += 1
                blob += src[k]
            heads = _re.findall(r"[\"']([a-z][a-z0-9-]*)[\"']", blob) or heads
        inline = line.split("#", 1)[1].strip() if "#" in line.split(":", 1)[-1] else ""
        if len(inline) >= 14:
            for h in heads:
                out[h] = inline
            continue
        for j in range(i + 1, min(i + 4, len(src))):
            s = src[j].strip()
            if _re.match(r"\s*(?:el)?if head\b", src[j]) or _re.match(
                r"\s*(?:el)?if \(\s*$", src[j]
            ):
                break
            if not s.startswith("#"):
                continue
            t = s.lstrip("# ").strip()
            t = _re.sub(r"^\(?%s[^)]*\)?\s*(?:--|—)\s*" % _re.escape(m.group(1)), "", t)
            if len(t) >= 14:
                for h in heads:
                    out[h] = t
            break
    try:
        tree = _ast.parse("\n".join(src))
    except Exception:
        return out  # unparseable: keep what the line scan found, never claim more
    for node in _ast.walk(tree):
        if not isinstance(node, _ast.If) or not node.body:
            continue
        heads2 = []
        for cmp_ in _ast.walk(node.test):
            if not (isinstance(cmp_, _ast.Compare) and isinstance(cmp_.left, _ast.Name)):
                continue
            if cmp_.left.id != "head":
                continue
            for c in cmp_.comparators:
                if isinstance(c, _ast.Constant) and isinstance(c.value, str):
                    heads2.append(c.value)
                elif isinstance(c, (_ast.Tuple, _ast.List, _ast.Set)):
                    heads2 += [
                        e.value
                        for e in c.elts
                        if isinstance(e, _ast.Constant) and isinstance(e.value, str)
                    ]
        if not heads2:
            continue
        for j in range(node.lineno - 1, max(node.lineno, node.body[0].lineno - 1)):
            s = src[j] if j < len(src) else ""
            k = s.find("#")
            if k < 0:
                continue
            t2 = s[k + 1 :].strip()
            if len(t2) >= 14:
                for h in heads2:
                    out.setdefault(h, t2)
                break
    return out


def known_keys(path):
    ""
    try:
        tree = _ast.parse(open(path, errors="replace").read())
    except Exception:
        return None
    out = set()
    for n in _ast.walk(tree):
        k = None
        if isinstance(n, _ast.Subscript):  # kv[":x"]
            if getattr(n.value, "id", "") == "kv" and isinstance(n.slice, _ast.Constant):
                k = n.slice.value
        elif isinstance(n, _ast.Call):  # kv.get(":x", ...)
            f = n.func
            if (
                isinstance(f, _ast.Attribute)
                and f.attr == "get"
                and getattr(f.value, "id", "") == "kv"
                and n.args
                and isinstance(n.args[0], _ast.Constant)
            ):
                k = n.args[0].value
        if isinstance(k, str) and k.startswith(":"):
            out.add(k)
    return out


def known_heads(path):
    ""
    try:
        tree = _ast.parse(open(path, errors="replace").read())
    except Exception:
        return None
    out = set()
    for n in _ast.walk(tree):
        if not (isinstance(n, _ast.Compare) and isinstance(n.left, _ast.Name)):
            continue
        if n.left.id != "head":
            continue
        for c in n.comparators:
            if isinstance(c, _ast.Constant) and isinstance(c.value, str):
                out.add(c.value)
            elif isinstance(c, (_ast.Tuple, _ast.List, _ast.Set)):
                for e in c.elts:
                    if isinstance(e, _ast.Constant) and isinstance(e.value, str):
                        out.add(e.value)
    return sorted(out)


def tokenize(s):
    out, i = [], 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            i += 1
        elif c in "()":
            out.append(c)
            i += 1
        elif c == ";":
            while i < len(s) and s[i] != "\n":
                i += 1
        elif c == '"':
            j, buf = i + 1, []
            while j < len(s) and s[j] != '"':
                if s[j] == "\\" and j + 1 < len(s):
                    buf.append(s[j + 1])
                    j += 2
                else:
                    buf.append(s[j])
                    j += 1
            out.append(("str", "".join(buf)))
            i = j + 1
        else:
            j = i
            while j < len(s) and not s[j].isspace() and s[j] not in '()"':
                j += 1
            out.append(("atom", s[i:j]))
            i = j
    return out


def parse(toks, pos=0):
    if toks[pos] == "(":
        lst, pos = [], pos + 1
        while toks[pos] != ")":
            node, pos = parse(toks, pos)
            lst.append(node)
        return lst, pos + 1
    t, v = toks[pos]
    return v, pos + 1


def read_all(s):
    ""
    toks, out, pos = tokenize(s), [], 0
    while pos < len(toks):
        form, pos = parse(toks, pos)
        out.append(form)
    return out


def read(s):
    toks = tokenize(s)
    node, pos = parse(toks, 0)
    if pos != len(toks):
        raise ValueError("trailing tokens after form")
    return node


class Str(str):
    ""

    __slots__ = ()


def _parse_typed(toks, pos=0):
    if toks[pos] == "(":
        lst, pos = [], pos + 1
        while toks[pos] != ")":
            node, pos = _parse_typed(toks, pos)
            lst.append(node)
        return lst, pos + 1
    tag, v = toks[pos]
    return (Str(v) if tag == "str" else v), pos + 1


def read_typed(s):
    ""
    toks = tokenize(s)
    node, pos = _parse_typed(toks, 0)
    if pos != len(toks):
        raise ValueError("trailing tokens after form")
    return node


def dump(form):
    ""
    if isinstance(form, (list, tuple)):
        return "(" + " ".join(dump(x) for x in form) + ")"
    s = form if isinstance(form, str) else str(form)
    if isinstance(form, Str) or s == "" or any(c in s for c in ' \t\n\r()"'):
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return s


def lisp_args(nodes):
    ""
    out, i = [], 0
    while i < len(nodes):
        n = nodes[i]
        bare = isinstance(n, str) and not isinstance(n, Str)
        if bare and n == "'" and i + 1 < len(nodes):
            out.append("(quote " + dump(nodes[i + 1]) + ")")
            i += 2
            continue
        if bare and len(n) > 1 and n.startswith("'"):
            out.append("(quote " + n[1:] + ")")
            i += 1
            continue
        out.append(dump(n))
        i += 1
    return out


def plist(items):
    d = {}
    for k, v in zip(items[0::2], items[1::2]):
        d[k] = v
    return d


def selftest():
    ""
    import os
    import tempfile

    lines = [
        "def d(head, app):",
        '    if head == "plain":  # a plain trailing description here',
        "        return 1",
        "    if (",
        '        head == "wrapped"',
        "    ):  # a description on the closing paren line",
        "        return 2",
        '    if head == "guarded":',
        "        if not app:",
        "            raise ValueError(1)",
        "        # the description sits after the guard and is still its own",
        "        return 3",
        '    if head == "bare":',
        "        return 4",
        '    if head == "neighbour":  # belongs to neighbour, never to bare',
        "        return 5",
    ]
    bad = ran = 0

    def ck(name, ok, why):
        nonlocal bad, ran
        ran += 1
        bad += not ok
        print("  %-20s %-4s %s" % (name, "PASS" if ok else "FAIL", why), flush=True)

    def _raises(fn):
        try:
            fn()
            return False
        except Exception:
            return True

    with tempfile.TemporaryDirectory() as t:
        p = os.path.join(t, "probe.py")
        with open(p, "w") as fh:
            fh.write("\n".join(lines) + "\n")
        d = head_docs(p)

    print("sexpr_lib HEAD-DOCS CONTRACT", flush=True)
    ck(
        "plain",
        "plain" in d,
        "a trailing comment on the branch line is the common case",
    )
    ck(
        "wrapped",
        "wrapped" in d,
        "NON-REGRESSION: a formatter-wrapped branch must stay readable, or writing a long"
        " description is what destroys it",
    )
    ck(
        "guarded",
        "guarded" in d,
        "a description after a raise-guard belongs to that head -- cutting at the first"
        " statement silently dropped two forms",
    )
    ck(
        "bare-stays-bare",
        "bare" not in d,
        "NON-VACUITY: a head with NO comment stays UNDESCRIBED rather than adopting its"
        " neighbour -- an index that fabricates is worse than one admitting the gap",
    )
    ck(
        "neighbour-kept",
        d.get("neighbour", "").startswith("belongs to neighbour"),
        "and the neighbour keeps its OWN description, so the fix removed an attribution"
        " rather than an answer",
    )
    print("\nsexpr_lib READER + SCANNERS", flush=True)
    ck(
        "lisp-args-folds-quote-shorthand",
        lisp_args(read_typed("(f '(1 2) 'a \"'\" 3)")[1:])
        == ["(quote (1 2))", "(quote a)", '"\'"', "3"],
        "the reader leaves ' as an atom; an argument renderer must fold it into (quote X), or a"
        " head minted from (f '(1 2)) gets TWO slots and (f (quote (1 2))) leaves {a2} unbound",
    )
    ck(
        "tok-parens-atoms",
        tokenize("(a b)") == ["(", ("atom", "a"), ("atom", "b"), ")"],
        "parens are their own tokens; bare words are atoms -- the basic shape",
    )
    ck(
        "tok-string-escape",
        tokenize(r'("a\"b")') == ["(", ("str", 'a"b'), ")"],
        "a backslash-escaped quote stays INSIDE the string; drop the escape branch and the"
        " string terminates early and the tail reparses as atoms",
    )
    ck(
        "tok-atom-boundary",
        tokenize('a(b)"c"') == [("atom", "a"), "(", ("atom", "b"), ")", ("str", "c")],
        "an atom ends at ( ) \" or whitespace -- flip that boundary and 'a' swallows the paren",
    )
    ck(
        "tok-comment-stripped",
        read("(a ; note\n b)") == ["a", "b"],
        "a ; comment runs to end-of-line and vanishes; without it ';' becomes an atom (the"
        " exact effects.sexpr break this branch was added to fix)",
    )
    ck(
        "read-nested",
        read("(a (b c) d)") == ["a", ["b", "c"], "d"],
        "parse recurses into sublists",
    )
    ck(
        "read-empty-list",
        read("()") == [],
        "the empty list is a valid form, not an error",
    )
    ck(
        "read-rejects-trailing",
        _raises(lambda: read("(a) (b)")),
        "read() is ONE form -- trailing tokens RAISE, so a truncated or garbage tail is caught"
        " rather than silently dropped",
    )
    ck(
        "read-all-multi",
        read_all("(a) (b c)") == [["a"], ["b", "c"]],
        "read_all consumes EVERY top-level form -- registry/policy files are sequences of forms",
    )
    ck(
        "typed-str-vs-atom",
        [type(x).__name__ for x in read_typed('(f "5" 5)')] == ["str", "Str", "str"],
        "a quoted 5 returns as Str, a bare 5 as plain str -- the distinction that lets a"
        ' content-hash tell (f "5") from (f 5)',
    )
    ck(
        "typed-rejects-trailing",
        _raises(lambda: read_typed("(a) x")),
        "read_typed is also one-form -- the trailing-token guard is not reader-specific",
    )
    ck(
        "dump-quotes-spaces",
        dump(["a", "x y"]) == '(a "x y")',
        "a value with a space MUST round-trip quoted or the ledger form re-reads as two atoms",
    )
    ck(
        "dump-bare-atoms",
        dump(["a", "b"]) == "(a b)",
        "space-free atoms stay bare -- quotes there would be noise",
    )
    ck(
        "dump-quotes-empty",
        dump(["a", ""]) == '(a "")',
        "the empty string must be quoted or it vanishes on re-read",
    )
    ck(
        "roundtrip",
        read(dump(["send", "+1 555", "hi (there)"])) == ["send", "+1 555", "hi (there)"],
        "THE LEDGER PROPERTY: read(dump(f)) == f even with spaces and parens inside values",
    )
    ck(
        "dump-str-quoted",
        dump([Str("5")]) == '("5")' and dump(["5"]) == "(5)",
        "a Str literal serializes quoted, a bare atom bare -- the writer preserves the typed"
        " distinction the reader made",
    )
    ck(
        "plist-pairs",
        plist(["a", 1, "b", 2]) == {"a": 1, "b": 2},
        "an even-length kv list becomes a dict",
    )
    with tempfile.TemporaryDirectory() as _t2:
        _pk = os.path.join(_t2, "k.py")
        with open(_pk, "w") as _fh:
            _fh.write(
                'def h(kv):\n    a = kv[":handle"]\n    b = kv.get(":limit", 10)\n'
                '    c = other[":nope"]\n    return a, b, c\n'
            )
        ck(
            "known-keys-kv-only",
            known_keys(_pk) == {":handle", ":limit"},
            "only kv[...] and kv.get(...) count; other[':nope'] is excluded, so a key the tool"
            " never reads is never advertised as accepted",
        )
        _ph = os.path.join(_t2, "h.py")
        with open(_ph, "w") as _fh:
            _fh.write(
                'def d(head):\n    if head == "flick":\n        pass\n'
                '    if head in ("win-move", "windows"):\n        pass\n'
                '    if other == "nope":\n        pass\n'
            )
        ck(
            "known-heads-derived",
            known_heads(_ph) == ["flick", "win-move", "windows"],
            "heads come from head== / head in comparisons; a non-head compare is excluded, so"
            " the advertised set is exactly what the dispatcher accepts",
        )

    print("\nRESULT: %s" % ("FAIL -- %d case(s)" % bad if bad else "PASS -- %d cases" % ran))
    return 1 if bad else 0


if __name__ == "__main__":
    import sys as _s

    _s.exit(selftest() if "--selftest" in _s.argv else 0)
