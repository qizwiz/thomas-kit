""

import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from typing import Any

_SWALLOWED: dict = {}


def _swallowed(where, line, e):
    ""
    k = f"{where}:{line}"
    _SWALLOWED[k] = _SWALLOWED.get(k, 0) + 1
    if _SWALLOWED[k] != 1:
        return
    print(f"swallowed@{where}:{line}: {e!r}"[:200], file=sys.stderr)


PROTOCOL_VERSION = 1
CLIENT_CAPS = {"fs": {"readTextFile": False, "writeTextFile": False}, "terminal": False}


def route(msg):
    ""
    if not isinstance(msg, dict):
        return "junk"
    has_id, has_method = "id" in msg, "method" in msg
    if has_method and has_id:
        return "request"
    if has_method:
        return "notification"
    if has_id and ("result" in msg or "error" in msg):
        return "response"
    return "junk"


def update_kind(msg):
    ""
    upd = ((msg or {}).get("params") or {}).get("update") or {}
    return upd.get("sessionUpdate")


def chunk_text(msg):
    ""
    if update_kind(msg) != "agent_message_chunk":
        return ""
    content = ((msg.get("params") or {}).get("update") or {}).get("content") or {}
    return content.get("text", "") if content.get("type") == "text" else ""


def choose_option(options, decision):
    ""
    want = "allow_once" if decision == "allow" else "reject_once"
    for opt in options or []:
        if opt.get("kind") == want:
            return {"outcome": {"outcome": "selected", "optionId": opt.get("optionId")}}
    if decision == "allow":
        return choose_option(options, "reject")
    return {"outcome": {"outcome": "cancelled"}}


def reject_policy(params):
    ""
    return choose_option((params or {}).get("options"), "reject")


AGENTS: dict[str, dict[str, Any]] = {
    "claude": {"cmd": ["claude-agent-acp"], "mode": "bypassPermissions"},
    "codex": {"cmd": ["codex-acp"], "mode": "agent"},
    "gemini": {
        "cmd": ["gemini", "--acp"],
        "mode": "yolo",
        "auth": "gemini-api-key",
        "env": {"GEMINI_API_KEY": ("google", "key"), "GEMINI_CLI_TRUST_WORKSPACE": "true"},
    },
}
CRED_STORE = os.path.expanduser("~/.local/share/opencode/auth.json")


def agent_spec(agent):
    ""
    s = AGENTS.get(agent)
    if s:
        return list(s["cmd"]), s.get("mode"), s.get("auth"), dict(s.get("env") or {})
    return agent.split(), None, None, {}


def _read_cred_store():
    with open(CRED_STORE) as fh:
        return json.load(fh)


def resolve_env(refs, read=None):
    ""
    if not refs:
        return {}
    store = None
    out = {}
    for var, ref in refs.items():
        if isinstance(ref, str):
            out[var] = ref
            continue
        if store is None:
            store = (read or _read_cred_store)()
        v = (store.get(ref[0]) or {}).get(ref[1])
        if isinstance(v, str) and v:
            out[var] = v
    return out


def literal_refs(refs):
    ""
    return {k: v for k, v in (refs or {}).items() if isinstance(v, str)}


def mode_decision(want, offered):
    ""
    if want:
        return ("set", want)
    ids = [m.get("id") for m in (offered or {}).get("availableModes") or []]
    if ids:
        return ("refuse", f"agent offers modes {ids} and none was declared; pass --mode")
    return ("none", "")


def session_params(cwd, settings, session_id=None):
    ""
    p = {
        "cwd": cwd,
        "mcpServers": [],
        "_meta": {"claudeCode": {"options": {"settingSources": list(settings)}}},
    }
    if session_id:
        p["sessionId"] = session_id
    return p


def turn_usage(result):
    ""
    res = result or {}
    if res.get("usage"):
        return res["usage"]
    tc = ((res.get("_meta") or {}).get("quota") or {}).get("token_count") or {}
    if not tc:
        return {}
    return {
        "inputTokens": tc.get("input_tokens", 0),
        "outputTokens": tc.get("output_tokens", 0),
        "cachedReadTokens": tc.get("cached_tokens", 0),
    }


def usage_fields(update):
    ""
    out: dict[str, int | float | str] = {}
    used, size = update.get("used"), update.get("size")
    if isinstance(used, (int, float)):
        out["ctx_used"] = int(used)
    if isinstance(size, (int, float)) and size:
        out["ctx_size"] = int(size)
        if isinstance(used, (int, float)):
            out["ctx_pct"] = round(100.0 * used / size, 1)
    cost = update.get("cost") or {}
    if isinstance(cost, dict) and isinstance(cost.get("amount"), (int, float)):
        out["cost"] = f"{round(cost['amount'], 4):g} {cost.get('currency', '')}".strip()
    return out


STATUS_EVENTS = {
    "ready": "idle",  # session created or loaded
    "prompt": "working",  # session/prompt sent
    "permission": "blocked",  # agent asked permission; a turn waits on the answer
    "answered": "working",  # permission answered; the turn resumes
    "stop": "idle",  # session/prompt returned a stopReason
    "error": "idle",  # session/prompt returned an error; the seat can take the next prompt
    "exit": "dead",  # the adapter process ended
}


def next_status(status, event):
    ""
    if status == "dead" and event != "ready":
        return "dead"
    return STATUS_EVENTS.get(event, status)


class Client:
    ""

    def __init__(self, cmd, cwd, on_message=None, policy=reject_policy, on_exit=None, env=None):
        self.p = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=cwd,
            env={**os.environ, **env} if env else None,
            text=True,
            bufsize=1,
        )
        if self.p.stdin is None or self.p.stdout is None or self.p.stderr is None:
            raise RuntimeError(f"ACP agent {cmd!r} spawned without its three pipes")
        self._in, self._out, self._err = self.p.stdin, self.p.stdout, self.p.stderr
        self.on_message = on_message or (lambda kind, msg: None)
        self.on_exit = on_exit or (lambda: None)
        self.policy = policy
        self.next_id = 0
        self.pending = {}
        self.stderr_tail = []
        self.lock = threading.Lock()
        self.wlock = threading.Lock()
        self.t0 = time.time()
        self._reader = threading.Thread(target=self._read_out, daemon=True, name="acp-out")
        self._reader.start()
        threading.Thread(target=self._read_err, daemon=True, name="acp-err").start()

    def alive(self):
        return self.p.poll() is None

    def _send(self, obj):
        with self.wlock:
            self._in.write(json.dumps(obj) + "\n")
            self._in.flush()

    def call(self, method, params, timeout):
        ""
        with self.lock:
            self.next_id += 1
            rid = self.next_id
            ev = threading.Event()
            self.pending[rid] = [ev, None]
        try:
            self._send({"jsonrpc": "2.0", "id": rid, "method": method, "params": params})
        except (BrokenPipeError, ValueError, OSError) as e:
            self.pending.pop(rid, None)
            return {"error": {"code": "dead", "message": f"{method}: agent pipe closed ({e})"}}
        deadline = time.time() + timeout
        while not ev.wait(0.5):
            if not self.alive():
                self.pending.pop(rid, None)
                return {
                    "error": {
                        "code": "dead",
                        "message": f"{method}: agent exited rc={self.p.poll()}",
                    }
                }
            if time.time() > deadline:
                self.pending.pop(rid, None)
                return {
                    "error": {"code": "timeout", "message": f"{method}: no response in {timeout}s"}
                }
        return self.pending.pop(rid)[1]

    def notify(self, method, params):
        try:
            self._send({"jsonrpc": "2.0", "method": method, "params": params})
        except (BrokenPipeError, ValueError, OSError) as e311:
            _swallowed(
                "notify", 311, e311
            )  # a notification to a dead agent has no one to reach; alive() reports the death

    def _read_out(self):
        for line in self._out:
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except ValueError as e321:
                _swallowed("_read_out", 321, e321)
                self.stderr_tail.append("stdout-junk: " + line[:200])
                continue
            kind = route(msg)
            if kind == "response":
                slot = self.pending.get(msg.get("id"))
                if slot:
                    slot[1] = msg
                    slot[0].set()
            elif kind == "request":
                if msg.get("method") == "session/request_permission":
                    self.on_message("permission", msg)
                    result = self.policy(msg.get("params"))
                    self._send({"jsonrpc": "2.0", "id": msg["id"], "result": result})
                    self.on_message("answered", {"request": msg, "result": result})
                    continue
                self._send(
                    {
                        "jsonrpc": "2.0",
                        "id": msg["id"],
                        "error": {
                            "code": -32601,
                            "message": f"thomas ACP client does not serve {msg.get('method')}",
                        },
                    }
                )
            self.on_message(kind, msg)
        self.on_exit()

    def _read_err(self):
        for line in self._err:
            self.stderr_tail.append(line.rstrip()[:300])
            del self.stderr_tail[:-40]

    def enforce_mode(self, sid, want, offered):
        ""
        act, arg = mode_decision(want, offered)
        if act == "refuse":
            return "", arg
        if act == "none":
            return "", ""
        res = self.call("session/set_mode", {"sessionId": sid, "modeId": arg}, 60)
        if res.get("error"):
            return "", f"set_mode {arg} refused: {json.dumps(res['error'])[:200]}"
        return arg, ""

    def authenticate(self, method, timeout=60):
        return self.call("authenticate", {"methodId": method}, timeout)

    def initialize(self, name="thomas", timeout=60):
        return self.call(
            "initialize",
            {
                "protocolVersion": PROTOCOL_VERSION,
                "clientCapabilities": CLIENT_CAPS,
                "clientInfo": {"name": name, "version": "0.1"},
            },
            timeout,
        )

    def close(self):
        try:
            self._in.close()
            self.p.wait(timeout=5)
        except Exception as e386:  # noqa: BLE001
            _swallowed("close", 386, e386)
            self.p.kill()
        if threading.current_thread() is not self._reader:
            self._reader.join(timeout=5)



_FAKE_AGENT = '''\
"""A fake ACP agent -- the smallest peer that makes a Client take every branch it has."""
import json
import sys


def send(obj):
    sys.stdout.write(json.dumps(obj) + "\\n")
    sys.stdout.flush()


sys.stdout.write("this line is not json\\n")  # must land in stderr_tail, not be parsed
sys.stdout.flush()
sys.stderr.write("fake agent up\\n")
sys.stderr.flush()

seen = []  # every response THE CLIENT sent back to us
report_id = None  # a probe/report the client waits on, held until both answers are in

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    msg = json.loads(line)
    method = msg.get("method")
    if method is None:
        seen.append(msg)
    elif method == "initialize":
        send({"jsonrpc": "2.0", "id": msg["id"],
              "result": {"protocolVersion": msg["params"]["protocolVersion"],
                         "caps": msg["params"]["clientCapabilities"],
                         "name": msg["params"]["clientInfo"]["name"]}})
    elif method == "session/set_mode":
        if msg["params"]["modeId"] == "yolo":
            send({"jsonrpc": "2.0", "id": msg["id"], "result": {}})
        else:
            send({"jsonrpc": "2.0", "id": msg["id"],
                  "error": {"code": -32602, "message": "no such mode"}})
    elif method == "probe/drive":
        send({"jsonrpc": "2.0", "id": msg["id"], "result": {"ok": True}})
        send({"jsonrpc": "2.0", "method": "session/update",
              "params": {"sessionId": "s1",
                         "update": {"sessionUpdate": "agent_message_chunk",
                                    "content": {"type": "text", "text": "hi from fake"}}}})
        send({"jsonrpc": "2.0", "id": 900, "method": "session/request_permission",
              "params": {"options": [{"optionId": "A1", "kind": "allow_once"},
                                     {"optionId": "R1", "kind": "reject_once"}]}})
        send({"jsonrpc": "2.0", "id": 901, "method": "fs/read_text_file",
              "params": {"path": "/etc/passwd"}})
    elif method == "probe/report":
        report_id = msg["id"]
    elif method == "probe/flood":
        send({"jsonrpc": "2.0", "id": msg["id"], "result": {"flooded": 200}})
        for i in range(200):
            send({"jsonrpc": "2.0", "method": "session/update",
                  "params": {"sessionId": "s1",
                             "update": {"sessionUpdate": "tool_call", "toolCallId": str(i)}}})
    if report_id is not None and len(seen) >= 2:
        send({"jsonrpc": "2.0", "id": report_id, "result": {"seen": seen}})
        report_id = None
'''

_OPTS = [
    {"optionId": "AA", "kind": "allow_always"},
    {"optionId": "A1", "kind": "allow_once"},
    {"optionId": "RA", "kind": "reject_always"},
    {"optionId": "R1", "kind": "reject_once"},
]


def _run(fn, *args):
    ""
    try:
        fn(*args)
    except Exception as e:  # noqa: BLE001 -- a case may fail any way it likes; the text reports
        why = str(e)
        if not why:
            frame = traceback.extract_tb(e.__traceback__)[-1]
            why = f"line {frame.lineno}: {frame.line}"
        return f"{type(e).__name__}: {why}"
    return ""


def _upd(kind, content):
    ""
    return {
        "jsonrpc": "2.0",
        "method": "session/update",
        "params": {"sessionId": "s1", "update": {"sessionUpdate": kind, "content": content}},
    }


def _c_route():
    assert route({"jsonrpc": "2.0", "id": 1, "method": "session/request_permission"}) == "request"
    assert route({"jsonrpc": "2.0", "method": "session/update", "params": {}}) == "notification"
    assert route({"jsonrpc": "2.0", "id": 1, "result": {}}) == "response"
    assert route({"jsonrpc": "2.0", "id": 2, "error": {"code": -32601}}) == "response"
    assert route({"id": 0, "result": None}) == "response"
    assert route({"id": None, "error": {"code": -32700}}) == "response"


def _c_route_near_miss():
    assert route({"jsonrpc": "2.0", "id": 7}) == "junk"
    assert route({}) == "junk"
    assert route(None) == "junk"
    assert route([{"method": "x", "id": 1}]) == "junk"
    assert route(["id", "result"]) == "junk"
    assert route('{"method": "x", "id": 1}') == "junk"
    assert route({"id": 1, "method": "m", "result": {}}) == "request"


def _c_update_kind():
    assert update_kind(_upd("tool_call", None)) == "tool_call"
    assert update_kind({}) is None
    assert update_kind(None) is None
    assert update_kind({"params": None}) is None
    assert update_kind({"params": {"update": None}}) is None
    assert update_kind({"params": {"update": {}}}) is None
    assert update_kind({"params": {"sessionUpdate": "agent_message_chunk"}}) is None


def _c_chunk_text():
    assert chunk_text(_upd("agent_message_chunk", {"type": "text", "text": "a b\n"})) == "a b\n"
    assert chunk_text(_upd("agent_message_chunk", {"type": "text", "text": ""})) == ""
    assert chunk_text({}) == ""
    assert chunk_text(None) == ""


def _c_chunk_text_near_miss():
    assert chunk_text(_upd("agent_thought_chunk", {"type": "text", "text": "thinking"})) == ""
    assert chunk_text(_upd("tool_call", {"type": "text", "text": "ran ls"})) == ""
    assert chunk_text(_upd("agent_message_chunk", {"type": "image", "data": "iVBOR"})) == ""
    assert (
        chunk_text(
            _upd("agent_message_chunk", {"type": "resource_link", "uri": "file:///x", "text": "/x"})
        )
        == ""
    )
    assert chunk_text(_upd("agent_message_chunk", {"type": "text"})) == ""
    assert chunk_text(_upd("agent_message_chunk", None)) == ""


def _c_choose_option_allow():
    assert choose_option(_OPTS, "allow") == {"outcome": {"outcome": "selected", "optionId": "A1"}}
    assert choose_option(_OPTS, "reject") == {"outcome": {"outcome": "selected", "optionId": "R1"}}
    assert choose_option(_OPTS, "allow")["outcome"]["optionId"] != "AA"
    assert choose_option(_OPTS, "reject")["outcome"]["optionId"] != "RA"


def _c_choose_option_fallback():
    no_once = [
        {"optionId": "AA", "kind": "allow_always"},
        {"optionId": "R1", "kind": "reject_once"},
    ]
    assert choose_option(no_once, "allow") == {"outcome": {"outcome": "selected", "optionId": "R1"}}
    assert choose_option(_OPTS, "Allow") == {"outcome": {"outcome": "selected", "optionId": "R1"}}
    assert choose_option(_OPTS, None) == {"outcome": {"outcome": "selected", "optionId": "R1"}}


def _c_choose_option_cancel():
    assert choose_option([], "reject") == {"outcome": {"outcome": "cancelled"}}
    assert choose_option(None, "allow") == {"outcome": {"outcome": "cancelled"}}
    always = [
        {"optionId": "AA", "kind": "allow_always"},
        {"optionId": "RA", "kind": "reject_always"},
    ]
    assert choose_option(always, "allow") == {"outcome": {"outcome": "cancelled"}}
    assert choose_option(always, "reject") == {"outcome": {"outcome": "cancelled"}}
    assert choose_option([{"optionId": "x"}], "reject") == {"outcome": {"outcome": "cancelled"}}


def _c_reject_policy():
    assert reject_policy({"options": _OPTS}) == {
        "outcome": {"outcome": "selected", "optionId": "R1"}
    }
    assert reject_policy({"options": [{"optionId": "A1", "kind": "allow_once"}]}) == {
        "outcome": {"outcome": "cancelled"}
    }
    assert reject_policy({}) == {"outcome": {"outcome": "cancelled"}}
    assert reject_policy(None) == {"outcome": {"outcome": "cancelled"}}


def _c_usage_fields():
    live = {
        "used": 12345,
        "size": 200000,
        "cost": {"amount": 0.28225249999999996, "currency": "USD"},
    }
    assert usage_fields(live) == {
        "ctx_used": 12345,
        "ctx_size": 200000,
        "ctx_pct": 6.2,
        "cost": "0.2823 USD",
    }
    assert usage_fields({"used": 1, "size": 3})["ctx_pct"] == 33.3
    assert usage_fields({"used": 2, "size": 3})["ctx_pct"] == 66.7
    assert usage_fields({"used": 200000, "size": 200000})["ctx_pct"] == 100.0
    assert usage_fields({"used": 100.7}) == {"ctx_used": 100}


def _c_usage_fields_edges():
    assert usage_fields({"used": 7}) == {"ctx_used": 7}
    assert usage_fields({"used": 500, "size": 0}) == {"ctx_used": 500}
    assert usage_fields({"size": 1000}) == {"ctx_size": 1000}
    assert usage_fields({}) == {}
    assert usage_fields({"used": 0, "size": 1000}) == {
        "ctx_used": 0,
        "ctx_size": 1000,
        "ctx_pct": 0.0,
    }
    assert usage_fields({"cost": {"amount": 1.0}}) == {"cost": "1"}
    assert usage_fields({"used": "many", "size": "big"}) == {}
    assert usage_fields({"cost": {"amount": "1.00", "currency": "USD"}}) == {}
    assert usage_fields({"cost": None}) == {}


def _c_next_status():
    assert next_status("idle", "prompt") == "working"
    assert next_status("working", "permission") == "blocked"
    assert next_status("blocked", "answered") == "working"
    assert next_status("working", "stop") == "idle"
    assert next_status("working", "error") == "idle"
    assert next_status("working", "exit") == "dead"
    assert next_status("blocked", "ready") == "idle"
    assert next_status("blocked", "tick") == "blocked"
    assert next_status("working", "") == "working"
    assert set(STATUS_EVENTS) == {
        "ready",
        "prompt",
        "permission",
        "answered",
        "stop",
        "error",
        "exit",
    }


def _c_next_status_dead():
    for ev in ["prompt", "permission", "answered", "stop", "error", "exit", "tick", ""]:
        assert next_status("dead", ev) == "dead", ev
    assert next_status("dead", "ready") == "idle"


def _c_mode_decision():
    offered = {"availableModes": [{"id": "default"}, {"id": "yolo"}]}
    assert mode_decision("yolo", offered) == ("set", "yolo")
    assert mode_decision("bypassPermissions", None) == ("set", "bypassPermissions")
    assert mode_decision(None, offered) == (
        "refuse",
        "agent offers modes ['default', 'yolo'] and none was declared; pass --mode",
    )
    assert mode_decision("", offered)[0] == "refuse"
    assert mode_decision(None, None) == ("none", "")
    assert mode_decision(None, {}) == ("none", "")
    assert mode_decision(None, {"availableModes": []}) == ("none", "")


def _c_agent_spec():
    assert agent_spec("claude") == (["claude-agent-acp"], "bypassPermissions", None, {})
    assert agent_spec("codex") == (["codex-acp"], "agent", None, {})
    assert agent_spec("gemini") == (
        ["gemini", "--acp"],
        "yolo",
        "gemini-api-key",
        {"GEMINI_API_KEY": ("google", "key"), "GEMINI_CLI_TRUST_WORKSPACE": "true"},
    )
    spec = agent_spec("node /tmp/agent.js --acp")
    assert spec == (["node", "/tmp/agent.js", "--acp"], None, None, {})
    assert mode_decision(spec[1], {"availableModes": [{"id": "d"}]})[0] == "refuse"
    assert [n for n, s in AGENTS.items() if not s.get("mode")] == []


def _c_agent_spec_isolation():
    cmd, _, _, env = agent_spec("gemini")
    cmd.append("--yolo")
    env["GEMINI_API_KEY"] = "sk-leaked"
    assert AGENTS["gemini"]["cmd"] == ["gemini", "--acp"]
    assert AGENTS["gemini"]["env"]["GEMINI_API_KEY"] == ("google", "key")
    assert agent_spec("gemini")[0] == ["gemini", "--acp"]


def _c_resolve_env():
    calls = []

    def fake_read():
        calls.append(1)
        return {"google": {"key": "sk-live-1"}, "openai": {"key": "sk-live-2"}}

    assert resolve_env({"K": ("google", "key")}, fake_read) == {"K": "sk-live-1"}
    assert len(calls) == 1
    del calls[:]
    assert resolve_env({"GEMINI_CLI_TRUST_WORKSPACE": "true"}, fake_read) == {
        "GEMINI_CLI_TRUST_WORKSPACE": "true"
    }
    assert calls == []
    out = resolve_env({"A": ("google", "key"), "B": ("openai", "key"), "C": "lit"}, fake_read)
    assert out == {"A": "sk-live-1", "B": "sk-live-2", "C": "lit"}
    assert len(calls) == 1
    assert resolve_env(None, fake_read) == {}
    assert resolve_env({}, fake_read) == {}
    assert len(calls) == 1


def _c_resolve_env_misses():
    def fake_read():
        return {"google": {"key": ""}, "codex": {"other": "x"}, "numeric": {"key": 42}}

    assert resolve_env({"K": ("google", "key")}, fake_read) == {}  # empty string
    assert resolve_env({"K": ("codex", "key")}, fake_read) == {}  # field absent
    assert resolve_env({"K": ("nobody", "key")}, fake_read) == {}  # provider absent
    assert resolve_env({"K": ("numeric", "key")}, fake_read) == {}  # not a string
    assert resolve_env({"K": ("google", "key"), "T": "true"}, fake_read) == {"T": "true"}


def _c_literal_refs():
    refs = AGENTS["gemini"]["env"]
    assert literal_refs(refs) == {"GEMINI_CLI_TRUST_WORKSPACE": "true"}
    assert literal_refs({}) == {} and literal_refs(None) == {}
    assert resolve_env(literal_refs(refs), read=lambda: {"google": {"key": "sk-live-9"}}) == {
        "GEMINI_CLI_TRUST_WORKSPACE": "true"
    }


def _c_session_params():
    assert session_params("/tmp/w", []) == {
        "cwd": "/tmp/w",
        "mcpServers": [],
        "_meta": {"claudeCode": {"options": {"settingSources": []}}},
    }
    assert "sessionId" not in session_params("/tmp/w", [])
    assert session_params("/tmp/w", ["user", "project"], "sess-7") == {
        "cwd": "/tmp/w",
        "mcpServers": [],
        "sessionId": "sess-7",
        "_meta": {"claudeCode": {"options": {"settingSources": ["user", "project"]}}},
    }
    settings = ["user"]
    p = session_params("/tmp/w", settings)
    settings.append("project")
    assert p["_meta"]["claudeCode"]["options"]["settingSources"] == ["user"]
    assert "sessionId" not in session_params("/tmp/w", [], "")
    assert "sessionId" not in session_params("/tmp/w", [], None)


def _answers(rec):
    ""
    seen = (rec["report"].get("result") or {}).get("seen") or []
    return {m.get("id"): m for m in seen}


def _c_client_initialize(rec):
    res = rec["init"].get("result")
    assert res, rec["init"]
    assert res["protocolVersion"] == 1, res
    assert res["caps"] == {
        "fs": {"readTextFile": False, "writeTextFile": False},
        "terminal": False,
    }, res["caps"]
    assert res["name"] == "thomas-selftest", res
    assert rec["alive"] is True


def _c_client_permission_rejects(rec):
    assert _answers(rec).get(900) == {
        "jsonrpc": "2.0",
        "id": 900,
        "result": {"outcome": {"outcome": "selected", "optionId": "R1"}},
    }, _answers(rec).get(900)


def _c_client_refuses_request(rec):
    assert _answers(rec).get(901) == {
        "jsonrpc": "2.0",
        "id": 901,
        "error": {
            "code": -32601,
            "message": "thomas ACP client does not serve fs/read_text_file",
        },
    }, _answers(rec).get(901)


def _c_client_message_log(rec):
    kinds = [k for k, _ in rec["log"]]
    assert kinds.count("permission") == 1, kinds
    assert kinds.count("answered") == 1, kinds
    assert kinds.count("request") == 1, kinds
    assert [m["method"] for k, m in rec["log"] if k == "request"] == ["fs/read_text_file"]
    notes = [update_kind(m) for k, m in rec["log"] if k == "notification"]
    assert notes[0] == "agent_message_chunk", notes[:3]
    assert set(notes[1:]) == {"tool_call"}, set(notes[1:])
    speech = [t for t in (chunk_text(m) for k, m in rec["log"] if k == "notification") if t]
    assert speech == ["hi from fake"], speech
    ans = next(m for k, m in rec["log"] if k == "answered")
    assert ans["result"] == {"outcome": {"outcome": "selected", "optionId": "R1"}}, ans
    assert ans["request"]["id"] == 900, ans


def _c_client_stderr_tail(rec):
    assert "stdout-junk: this line is not json" in rec["stderr_tail"], rec["stderr_tail"]
    assert "fake agent up" in rec["stderr_tail"], rec["stderr_tail"]


def _c_client_enforce_mode(rec):
    assert rec["mode_set"] == ("yolo", "")
    assert rec["mode_refuse"] == (
        "",
        "agent offers modes ['x'] and none was declared; pass --mode",
    ), rec["mode_refuse"]
    assert rec["mode_none"] == ("", "")
    assert rec["mode_bad"] == (
        "",
        'set_mode nope refused: {"code": -32602, "message": "no such mode"}',
    ), rec["mode_bad"]


def _c_client_timeout(rec):
    assert rec["timeout"] == {
        "error": {"code": "timeout", "message": "probe/never: no response in 0.2s"}
    }, rec["timeout"]


def _c_client_close_drains(rec):
    assert rec["flood"].get("result") == {"flooded": 200}, rec["flood"]
    assert rec["exited_at_close"] == ["exit"], rec["exited_at_close"]
    assert rec["log_at_close"] == len(rec["log"]), (rec["log_at_close"], len(rec["log"]))
    assert len([1 for k, m in rec["log"] if update_kind(m) == "tool_call"]) == 200


def _c_client_dead(rec):
    assert rec["after_close"]["error"]["code"] == "dead", rec["after_close"]
    assert rec["alive_after"] is False
    assert rec["returncode"] == 0, rec["returncode"]
    assert rec["exited"] == ["exit"], rec["exited"]


def _client_cases(tmp):
    ""
    path = os.path.join(tmp, "fake_acp_agent.py")
    with open(path, "w") as fh:
        fh.write(_FAKE_AGENT)
    log: list[Any] = []
    exited: list[str] = []
    slow = [False]
    rec: dict[str, Any] = {"log": log, "exited": exited}

    def on_message(kind, msg):
        log.append((kind, msg))
        if slow[0]:
            time.sleep(0.002)  # the flood's backlog, ~0.4s of reader work close() must wait out

    c = Client(
        [sys.executable, path],
        cwd=tmp,
        on_message=on_message,
        on_exit=lambda: exited.append("exit"),
    )
    try:
        rec["init"] = c.initialize(name="thomas-selftest", timeout=20)
        rec["alive"] = c.alive()
        rec["drive"] = c.call("probe/drive", {}, 20)
        rec["report"] = c.call("probe/report", {}, 20)
        rec["mode_set"] = c.enforce_mode("s1", "yolo", {"availableModes": [{"id": "yolo"}]})
        rec["mode_refuse"] = c.enforce_mode("s1", None, {"availableModes": [{"id": "x"}]})
        rec["mode_none"] = c.enforce_mode("s1", None, None)
        rec["mode_bad"] = c.enforce_mode("s1", "nope", None)
        rec["timeout"] = c.call("probe/never", {}, 0.2)
        slow[0] = True
        rec["flood"] = c.call("probe/flood", {}, 20)
    finally:
        c.close()
        rec["exited_at_close"] = list(exited)
        rec["log_at_close"] = len(log)
    deadline = time.time() + 5
    while time.time() < deadline and len(c.stderr_tail) < 2:
        time.sleep(0.02)
    rec["stderr_tail"] = list(c.stderr_tail)
    rec["after_close"] = c.call("initialize", {}, 5)
    rec["alive_after"] = c.alive()
    rec["returncode"] = c.p.poll()
    return [
        (name, _run(fn, rec))
        for name, fn in [
            ("client-initialize", _c_client_initialize),
            ("client-permission-rejects", _c_client_permission_rejects),
            ("client-refuses-request", _c_client_refuses_request),
            ("client-message-log", _c_client_message_log),
            ("client-stderr-tail", _c_client_stderr_tail),
            ("client-enforce-mode", _c_client_enforce_mode),
            ("client-timeout", _c_client_timeout),
            ("client-close-drains-reader", _c_client_close_drains),
            ("client-dead-after-close", _c_client_dead),
        ]
    ]


def selftest():
    ""
    pure = [
        ("route-shapes", _c_route),
        ("route-near-miss", _c_route_near_miss),
        ("update-kind", _c_update_kind),
        ("chunk-text", _c_chunk_text),
        ("chunk-text-near-miss", _c_chunk_text_near_miss),
        ("choose-option-once-kinds", _c_choose_option_allow),
        ("choose-option-allow-fallback", _c_choose_option_fallback),
        ("choose-option-cancel", _c_choose_option_cancel),
        ("reject-policy-never-allows", _c_reject_policy),
        ("usage-fields", _c_usage_fields),
        ("usage-fields-absent-vs-zero", _c_usage_fields_edges),
        ("next-status", _c_next_status),
        ("next-status-dead-absorbs", _c_next_status_dead),
        ("mode-decision", _c_mode_decision),
        ("agent-spec", _c_agent_spec),
        ("agent-spec-isolation", _c_agent_spec_isolation),
        ("resolve-env-injected-read", _c_resolve_env),
        ("resolve-env-missing-omitted", _c_resolve_env_misses),
        ("literal-refs-never-reads-the-store", _c_literal_refs),
        ("session-params", _c_session_params),
    ]
    results = [(name, _run(fn)) for name, fn in pure]
    with tempfile.TemporaryDirectory(prefix="acp-selftest-") as tmp:
        results.extend(_client_cases(tmp))
    for name, err in results:
        print(f"  {'FAIL' if err else 'PASS'} {name}")
        if err:
            print("      " + err.replace("\n", " ")[:400])
    failed = [name for name, err in results if err]
    n = len(results)
    if failed:
        names = ",".join(failed)
        print(
            f"acp_lib.py --selftest RESULT: FAIL -- {n - len(failed)}/{n} cases"
            f" (failed: {names})"
        )
        return 1
    print(f"acp_lib.py --selftest RESULT: PASS -- {n}/{n} cases")
    return 0


if __name__ == "__main__":
    raise SystemExit(selftest() if "--selftest" in sys.argv else 0)
