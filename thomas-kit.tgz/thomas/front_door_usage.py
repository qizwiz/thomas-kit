""

import sys

USAGE = """thomas -- your assistant: one brain, one persona, configured in ~/.thomas/thomas.sexpr

  thomas login                        sign in to Claude with your own paid account (once)
  thomas login --free                 or start free: a free OpenRouter key, no card (text answers only)
  thomas doctor                       check that everything Thomas needs is installed, with the fix for each gap
  thomas config                       the merged configuration (shipped defaults < ~/.thomas/thomas.sexpr < env)
  thomas brain                        the brains Thomas can use (claude, codex, gemini, free) and which is chosen
  thomas persona                      who your assistant is
  thomas persona set :KEY VALUE       design it (:name :pronouns :voice :personality :image)
  thomas chat [--brain K]             talk back and forth: type a message, read the answer, type again
  thomas ask [--brain K] [--new] "PROMPT"  one message; --new ignores the conversation so far
  thomas check                        put the last answer to a fresh session that did not write it, and see what it doubts
  thomas remember "NOTE"              something every answer should know about you (kept in ~/.thomas/memory.md)
  thomas forget                       delete the kept conversation (~/.thomas/conversation.jsonl)
  thomas telegram setup | run         talk to it from your phone, through a Telegram bot you create
  thomas telegram install             keep it answering in the background (after pairing); uninstall stops it
  thomas idioms [--json] [--project D] Claude Code's commands, keys and agents, for an editor sidebar
  thomas report --kind bug|idea --what TEXT ...  write a bug report or an idea and print it; with --file it opens a
                                      PUBLIC issue on the kit's GitHub repository through your own gh login.
                                      Shortened first: home paths become ~: the two segments /home/NAME or /Users then /NAME,
                                      wherever they stand in a path, with the path before them kept
                                      (/srv/home/sam/x becomes /srv/~/x), and after file:// too; /root only where it
                                      starts a path. NAME runs to the
                                      next slash or space, and closing punctuation at its very end stays in the text;
                                      shortened only where NAME has no space (the part after a space stays). An email address,
                                      everything around an @ up to a space, bracket, quote, comma, semicolon or
                                      colon when something stands before the @ and a dot after it, is replaced.
                                      Refused: text in a key format the kit knows, or a long random password written
                                      as password=VALUE. A key in a format the kit does
                                      not know, a short or word-like password, or one written inside a sentence is NOT
                                      refused, so read the report before you add --file

Thomas runs on your machine; your prompts go to the brain's provider under your own login.
So that it remembers you, Thomas keeps your recent turns and your notes in two files only you can read,
and each message sends them to the brain too. (memory :keep nil) in ~/.thomas/thomas.sexpr stops keeping and
sending them; files already written stay until you delete them.
With the default settings Thomas runs only the Claude brain, in an empty scratch folder, and refuses
every request it is asked to approve -- reading, writing or running anything. Claude may still run a few
read-only commands such as `whoami` and `pwd` without asking, so the brain sees your prompt, your persona
settings, your account name and a temporary folder path, along with what Claude itself sends its provider
(such as your platform and the date). Codex and Gemini read files outside that folder
even in their asking modes, so Thomas runs them only after you set `:autonomy t`, which lets the brain read,
write and run commands anywhere your user account can. Logins stay yours: Thomas never ships a credential,
and reading another app's stored key is off unless you turn it on."""
HELP_ARGS = ("--help", "-h", "help")


def help_only(argv) -> bool:
    ""
    return len(argv) == 2 and argv[1] in HELP_ARGS


def selftest():
    got = [help_only(a) for a in (["thomas", "--help"], ["thomas", "-h"], ["thomas", "help"], ["thomas"],
                                  ["thomas", "ask", "--help"], ["thomas", "help", "me"], ["thomas", "--helpx"])]
    cases = [
        ("help-only-argv", got == [True, True, True, False, False, False, False], got),
        ("usage-is-user-facing", ("src/" in USAGE, "thomas doctor" in USAGE) == (False, True), USAGE[:60]),
        ("usage-report-says-what-is-refused-and-what-is-not",
         all(s in " ".join(USAGE.split()) for s in ("key format the kit knows", "long random password written as password=VALUE", "word-like", "read the report before")),
         True),
        ("usage-report-says-a-key-format-it-does-not-know-is-not-refused",
         "does not know" in " ".join(USAGE.split()) and "API key" not in USAGE, True),
        ("usage-report-says-exactly-which-paths-are-shortened",
         "where NAME has no space" in " ".join(USAGE.split()) and "the path before them kept" in " ".join(USAGE.split()) and "home-directory" not in USAGE, True),
        ("usage-report-says-how-far-a-name-and-an-address-reach",
         "runs to the next slash or space" in " ".join(USAGE.split()) and "closing punctuation at its very end stays in the text" in " ".join(USAGE.split())
         and "up to a space, bracket, quote, comma, semicolon or colon" in " ".join(USAGE.split()), True),
    ]
    for n, ok, g in cases:
        print(f"  {n:<24} {'PASS' if ok else 'FAIL'}" + ("" if ok else f"  got {g!r}"))
    bad = sum(not ok for _n, ok, _g in cases)
    print("\nfront_door_usage --selftest RESULT: " + (f"FAIL -- {bad} case(s)" if bad else f"PASS -- {len(cases)} cases"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(selftest() if "--selftest" in sys.argv else (print(USAGE) or 0))
