""

import json
import os
import urllib.error
import urllib.request

DEFAULT_API = "https://openrouter.ai/api/v1"


def api_base(env=None):
    ""
    v = (os.environ if env is None else env).get("THOMAS_FREE_API", "")
    if v.startswith(("https://", "http://127.0.0.1:", "http://localhost:")):
        return v.rstrip("/")
    return DEFAULT_API


API = api_base()
KEY_FILE = os.path.expanduser("~/.thomas/openrouter.key")
FALLBACKS = 3  # OpenRouter's `models` list: the first plus this many - 1 fallbacks
PROBE_TIMEOUT = 25  # seconds per model at login; a slow free model is skipped, not waited on
NOT_CHAT = ("content-safety", "guard", "embed", "-code", "coder", "omni", "vision")


def read_key(path=KEY_FILE, env=None):
    ""
    env = os.environ if env is None else env
    if env.get("OPENROUTER_API_KEY"):
        return env["OPENROUTER_API_KEY"].strip()
    try:
        with open(path, encoding="utf-8") as fh:
            return fh.read().strip()
    except OSError:
        return ""


def save_key(key, path=KEY_FILE):
    ""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    os.fchmod(fd, 0o600)  # the mode on os.open applies only at creation; a stale looser .tmp must be tightened too
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(key.strip() + "\n")
    os.replace(tmp, path)


NOT_JSON = -1  # a 200 that is not JSON: something answered, but not OpenRouter


def _http(method, url, key, body=None, timeout=60):
    ""
    data = json.dumps(body).encode() if body is not None else None
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json",
               "X-Title": "Thomas"}
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read() or b"{}"
            try:
                return r.status, json.loads(raw)
            except ValueError:
                return NOT_JSON, {"error": "the reply was not JSON"}
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except ValueError:
            return e.code, {}
    except (urllib.error.URLError, OSError, ValueError) as e:
        reason = getattr(e, "reason", e)
        return 0, {"error": f"{type(reason).__name__}: {reason}"}


def _d(x):
    ""
    return x if isinstance(x, dict) else {}


def pick_models(models, n=FALLBACKS):
    ""
    free = []
    for m in models if isinstance(models, list) else []:
        m = _d(m)
        mid = str(m.get("id", ""))
        if not mid.endswith(":free") or any(t in mid for t in NOT_CHAT):
            continue
        out = _d(m.get("architecture")).get("output_modalities") or ["text"]
        if not isinstance(out, list) or "text" not in out:
            continue
        try:
            ctx = int(m.get("context_length") or 0)
        except (TypeError, ValueError):
            ctx = 0
        free.append((-ctx, mid))
    return [mid for _c, mid in sorted(free)[:n]]


def explain(status, payload, key=""):
    ""
    err = _d(payload).get("error") or {}
    msg = hide(str(err.get("message") or "") if isinstance(err, dict) else str(err), key)
    if status == NOT_JSON:
        return (f"Something other than OpenRouter answered ({msg[:120]}). A Wi-Fi sign-in page or a proxy may be in"
                " the way: open any web page to check, then try again.")
    if status == 401:
        return "OpenRouter did not accept that key. Make a new one at openrouter.ai/keys and run `thomas login --free` again."
    if status == 402:
        return ("OpenRouter refused for lack of credit: an account with a negative balance cannot use free models"
                " either. Check openrouter.ai/credits.")
    if status == 404 and "data policy" in msg:  # the account's privacy settings block THIS model (two switches)
        return ("OpenRouter's privacy settings block the free models tried. Free models need you to allow providers"
                " that may train on or publish what you send: openrouter.ai/settings/privacy. Then run"
                " `thomas login --free` again.")
    if status == 404:
        return (f"OpenRouter answered 404: {msg[:160] or 'not found'}. Free models come and go -- run"
                " `thomas login --free` again to pick ones that answer today.")
    if status == 429:
        return ("The free models are busy, or you have used today's free requests. Try again in a minute; the daily"
                " limit resets at midnight UTC.")
    if status == 0:
        return f"Could not reach OpenRouter ({msg[:160]}) -- check your internet connection."
    return f"OpenRouter answered {status}: {msg[:200] or 'no detail'}"


PROBES = 8  # how many listed free models login may try before giving up


def check_key(key, http=_http, say=None, clock=None):
    ""
    status, payload = http("GET", f"{API}/key", key)
    if status != 200:
        return [], explain(status, payload, key)
    status, payload = http("GET", f"{API}/models", key)
    if status != 200:
        return [], explain(status, payload, key)
    say = say or _say
    clock = clock or __import__("time").monotonic
    working, last_err = [], ""
    for mid in pick_models(_d(payload).get("data") or [], n=PROBES):
        say(f"  trying {mid} ...")
        t0 = clock()
        rc, _text, err, _used, status = _call(
            "Reply with the single word: ready", key, [mid], http, timeout=PROBE_TIMEOUT
        )
        if rc == 0:
            working.append((clock() - t0, mid))
            if len(working) == FALLBACKS:
                break
        else:
            last_err = err
            if status in ACCOUNT_WIDE:  # a bad key or no credit: every next model would fail alike; say why now
                break
    if working:
        return [mid for _secs, mid in sorted(working, key=lambda w: w[0])], ""  # stable: ties keep the ranking
    return [], hide(last_err, key) or "No free model answered just now; try `thomas login --free` again in a minute."


ACCOUNT_WIDE = (401, 402)


def hide(text, key):
    ""
    return text.replace(key, "<key>") if key else text


def _say(line):
    print(line, flush=True)


def _call(prompt, key, models, http, timeout=120):
    ""
    body = {"models": models, "messages": [{"role": "user", "content": prompt}]}
    status, payload = http("POST", f"{API}/chat/completions", key, body, timeout=timeout)
    if status != 200:
        return 1, "", explain(status, payload, key), "", status
    payload = _d(payload)
    choices = payload.get("choices")
    choice = _d(choices[0]) if isinstance(choices, list) and choices else {}
    text = _d(choice.get("message")).get("content") or ""
    text = text.strip() if isinstance(text, str) else ""
    used = str(payload.get("model", ""))
    if not text:
        return 1, "", "The free model returned no text; try again.", used, status
    return 0, text, "", used, status


def ask(prompt, key, models, http=_http):
    ""
    models = [m for m in models if m]
    if not models:
        return 1, "", "no free model chosen yet: run `thomas login --free`"
    err = ""
    while models:
        rc, text, err, used, _status = _call(prompt, key, models, http)
        if rc == 0:
            return 0, text, ""
        if used not in models:  # a real error (no model named): retrying the same list would not help
            return 1, "", err
        models = [m for m in models if m != used]
    return 1, "", err


def selftest():
    cases = []

    def ck(n, got, want):
        cases.append((n, got == want, got))

    models = [
        {"id": "nvidia/nemotron-3-super-120b-a12b:free", "context_length": 262144},
        {"id": "big/model:free", "context_length": 1000000},
        {"id": "nvidia/nemotron-3.5-content-safety:free", "context_length": 2000000},
        {"id": "cohere/north-mini-code:free", "context_length": 3000000},
        {"id": "paid/model", "context_length": 9000000},
        {"id": "img/out:free", "context_length": 5000000, "architecture": {"output_modalities": ["image"]}},
        {"id": "small/one:free", "context_length": 65536},
    ]
    ck("pick-free-chat-by-context", pick_models(models),
       ["big/model:free", "nvidia/nemotron-3-super-120b-a12b:free", "small/one:free"])
    ck("pick-none", pick_models(models[2:6]), [])
    ck("explain-bad-key-is-plain", "openrouter.ai/keys" in explain(401, {"error": {"message": "No auth"}}), True)
    ck("explain-busy", "busy" in explain(429, {}), True)
    seen = []

    def fake(method, url, key, body=None, timeout=60):
        seen.append((method, url, key, body))
        if url.endswith("/key"):
            return 200, {"data": {"label": "x"}}
        if url.endswith("/models"):
            return 200, {"data": models}
        return 200, {"choices": [{"message": {"content": "hi there"}}]}

    ck("check-key-lists-models", check_key("K", say=lambda _l: None, http=fake, clock=lambda: 0)[0][0], "big/model:free")
    ck("ask-returns-text", ask("hello", "K", ["a:free", "b:free"], http=fake), (0, "hi there", ""))
    ck("ask-sends-fallback-list", seen[-1][3]["models"], ["a:free", "b:free"])
    ck("key-never-in-url", all("K" not in u for _m, u, _k, _b in seen), True)
    ck("bad-key-stops-before-models", check_key("K", say=lambda _l: None, http=lambda *a, **k: (401, {}))[0], [])

    def gated(method, url, key, body=None, timeout=60):  # the first model answers 200 with no text
        if url.endswith("/key"):
            return 200, {}
        if url.endswith("/models"):
            return 200, {"data": models}
        first = body["models"][0]
        if first == "big/model:free":
            return 200, {"model": first, "choices": [{"message": {"content": ""}}]}
        return 200, {"model": first, "choices": [{"message": {"content": "ok from " + first}}]}

    ck("login-keeps-only-models-that-answer", check_key("K", say=lambda _l: None, http=gated, clock=lambda: 0)[0],
       ["nvidia/nemotron-3-super-120b-a12b:free", "small/one:free"])
    ticks = iter([0, 9, 10, 11, 20, 22])  # big takes 9 s, nemotron 1 s, small 2 s

    ck("login-orders-kept-models-fastest-first",
       check_key("K", say=lambda _l: None, http=fake, clock=lambda: next(ticks))[0],
       ["nvidia/nemotron-3-super-120b-a12b:free", "small/one:free", "big/model:free"])
    ck("empty-reply-drops-that-model-and-retries",
       ask("q", "K", ["big/model:free", "small/one:free"], http=gated), (0, "ok from small/one:free", ""))
    ck("ask-error-plain", ask("x", "K", ["m"], http=lambda *a, **k: (429, {}))[0:2], (1, ""))
    policy = {"error": {"message": "No endpoints available matching your guardrail restrictions and data policy."}}
    ck("login-shows-the-real-probe-error-data-policy",
       "settings/privacy" in check_key("K", say=lambda _l: None, http=lambda m, u, *a, **k: (200, {"data": models}) if m == "GET"
                                          else (404, policy))[1], True)
    ck("402-points-at-credits-not-relogin", "openrouter.ai/credits" in explain(402, {}), True)
    ck("api-override-only-https-or-localhost",
       (api_base({"THOMAS_FREE_API": "http://evil.example/v1"}), api_base({"THOMAS_FREE_API": "http://127.0.0.1:9/v1"}),
        api_base({"THOMAS_FREE_API": "https://x.example/v1/"})),
       (DEFAULT_API, "http://127.0.0.1:9/v1", "https://x.example/v1"))
    ck("odd-json-shapes-give-messages-not-tracebacks",
       (explain(500, ["x"])[:19], pick_models({"data": "abc"}), pick_models(["x", {"id": 3}]),
        ask("q", "K", ["m"], http=lambda *a, **k: (200, {"choices": "abc"}))[0]),
       ("OpenRouter answered", [], [], 1))
    straddle = {"error": {"message": "x" * 145 + " Bearer SECRETKEY-0123456789abcdef"}}
    ck("key-straddling-the-cut-leaves-no-prefix", "SECRET" in explain(404, straddle, "SECRETKEY-0123456789abcdef"), False)
    ck("non-json-says-something-else-answered", explain(NOT_JSON, {"error": "x"}).startswith("Something other than"), True)
    ck("server-echoed-key-is-hidden",
       "SECRETKEY" in ask("q", "SECRETKEY", ["m"], http=lambda *a, **k: (400, {"error": {"message": "bad Bearer SECRETKEY"}}))[2],
       False)
    probes = []

    def broke(method, url, key, body=None, timeout=60):
        if method == "GET":
            return 200, {"data": models}
        probes.append(1)
        return 402, {}

    gone = []

    def one_gone(method, url, key, body=None, timeout=60):  # the first model 404s (removed); the rest answer
        if method == "GET":
            return 200, {"data": models}
        gone.append(body["models"][0])
        if body["models"][0] == "big/model:free":
            return 404, {"error": {"message": "No endpoints found for big/model:free"}}
        return 200, {"model": body["models"][0], "choices": [{"message": {"content": "ok"}}]}

    ck("a-404-for-one-model-keeps-probing",
       check_key("K", say=lambda _l: None, http=one_gone, clock=lambda: 0)[0],
       ["nvidia/nemotron-3-super-120b-a12b:free", "small/one:free"])
    def one_switch(method, url, key, body=None, timeout=60):  # "may publish" off: the first model refuses, the rest answer
        if method == "GET":
            return 200, {"data": models}
        if body["models"][0] == "big/model:free":
            return 404, {"error": {"message": "No endpoints found matching your data policy (Free model publication)"}}
        return 200, {"model": body["models"][0], "choices": [{"message": {"content": "ok"}}]}

    ck("a-data-policy-404-on-one-model-keeps-probing",
       check_key("K", say=lambda _l: None, http=one_switch, clock=lambda: 0)[0],
       ["nvidia/nemotron-3-super-120b-a12b:free", "small/one:free"])
    ck("odd-messages-and-model-fields-never-raise",
       ([explain(400, {"error": {"message": v}})[:19] for v in (None, 5, {"a": 1})],
        pick_models([{"id": "a:free", "architecture": "text"}, {"id": "b:free", "context_length": "4096"},
                     {"id": "c:free", "architecture": {"output_modalities": 3}}])),
       (["OpenRouter answered"] * 3, ["b:free", "a:free"]))
    ck("account-wide-error-stops-probing-at-once",
       ("credits" in check_key("K", say=lambda _l: None, http=broke, clock=lambda: 0)[1], len(probes)), (True, 1))
    import tempfile

    d = tempfile.mkdtemp()
    p = os.path.join(d, "k")
    save_key("abc", p)
    ck("save-key-0600-and-read", (oct(os.stat(p).st_mode & 0o777), read_key(p, env={})), ("0o600", "abc"))
    ck("env-key-wins", read_key(p, env={"OPENROUTER_API_KEY": "env"}), "env")
    bad = sum(not ok for _n, ok, _g in cases)
    for n, ok, got in cases:
        print(f"  {n:<44} {'PASS' if ok else 'FAIL'}" + ("" if ok else f"  got {got!r}"))
    print(f"\nthomas_free --selftest RESULT: {f'FAIL -- {bad} case(s)' if bad else f'PASS -- {len(cases)} cases'}")
    return 1 if bad else 0


if __name__ == "__main__":
    import sys

    sys.exit(selftest() if "--selftest" in sys.argv else 0)
