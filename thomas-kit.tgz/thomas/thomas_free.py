""

import json
import os
import urllib.error
import urllib.request

DEFAULT_API = "https://openrouter.ai/api/v1"


def api_base(env=None):
    ""
    v = (os.environ if env is None else env).get("THOMAS_FREE_API", "")
    if v.startswith(("https://", "http://127.0.0.1:", "http://localhost:")):
        return v.rstrip("/")
    return DEFAULT_API


API = api_base()
KEY_FILE = os.path.expanduser("~/.thomas/openrouter.key")
FALLBACKS = 3  # OpenRouter's `models` list: the first plus this many - 1 fallbacks
PROBE_TIMEOUT = 25  # seconds per model at login; a slow free model is skipped, not waited on
NOT_CHAT = ("content-safety", "guard", "embed", "-code", "coder", "omni", "vision")


def read_key(path=KEY_FILE, env=None):
    ""
    env = os.environ if env is None else env
    if env.get("OPENROUTER_API_KEY"):
        return env["OPENROUTER_API_KEY"].strip()
    try:
        with open(path, encoding="utf-8") as fh:
            return fh.read().strip()
    except OSError:
        return ""


def save_key(key, path=KEY_FILE):
    ""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    os.fchmod(fd, 0o600)  # the mode on os.open applies only at creation; a stale looser .tmp must be tightened too
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(key.strip() + "\n")
    os.replace(tmp, path)


def _http(method, url, key, body=None, timeout=60):
    ""
    data = json.dumps(body).encode() if body is not None else None
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json",
               "X-Title": "Thomas"}
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except ValueError:
            return e.code, {}
    except (urllib.error.URLError, OSError, ValueError) as e:
        reason = getattr(e, "reason", e)
        return 0, {"error": f"{type(reason).__name__}: {reason}"}


def pick_models(models, n=FALLBACKS):
    ""
    free = []
    for m in models:
        mid = m.get("id", "")
        if not mid.endswith(":free") or any(t in mid for t in NOT_CHAT):
            continue
        arch = m.get("architecture") or {}
        if "text" not in (arch.get("output_modalities") or ["text"]):
            continue
        free.append((-(m.get("context_length") or 0), mid))
    return [mid for _c, mid in sorted(free)[:n]]


def explain(status, payload):
    ""
    err = (payload or {}).get("error") or {}
    msg = err.get("message", "") if isinstance(err, dict) else str(err)
    if status == 401:
        return "OpenRouter did not accept that key. Make a new one at openrouter.ai/keys and run `thomas login --free` again."
    if status == 402:
        return ("OpenRouter refused for lack of credit: an account with a negative balance cannot use free models"
                " either. Check openrouter.ai/credits.")
    if status == 404 and "data policy" in msg:
        return ("OpenRouter's privacy settings block every free model. Free models need you to allow providers that"
                " may train on or publish what you send: openrouter.ai/settings/privacy. Then run"
                " `thomas login --free` again.")
    if status == 404:
        return (f"OpenRouter answered 404: {msg[:160] or 'not found'}. Free models come and go -- run"
                " `thomas login --free` again to pick ones that answer today.")
    if status == 429:
        return ("The free models are busy, or you have used today's free requests. Try again in a minute; the daily"
                " limit resets at midnight UTC.")
    if status == 0:
        return f"Could not reach OpenRouter ({msg[:160]}) -- check your internet connection."
    return f"OpenRouter answered {status}: {msg[:200] or 'no detail'}"


PROBES = 8  # how many listed free models login may try before giving up


def check_key(key, http=_http, say=None):
    ""
    status, payload = http("GET", f"{API}/key", key)
    if status != 200:
        return [], explain(status, payload)
    status, payload = http("GET", f"{API}/models", key)
    if status != 200:
        return [], explain(status, payload)
    say = say or _say
    working, last_err = [], ""
    for mid in pick_models(payload.get("data") or [], n=PROBES):
        say(f"  trying {mid} ...")
        rc, _text, err, _used = _call("Reply with the single word: ready", key, [mid], http, timeout=PROBE_TIMEOUT)
        if rc == 0:
            working.append(mid)
            if len(working) == FALLBACKS:
                break
        else:
            last_err = err
    if working:
        return working, ""
    return [], last_err or "No free model answered just now; try `thomas login --free` again in a minute."


def _say(line):
    print(line, flush=True)


def _call(prompt, key, models, http, timeout=120):
    ""
    body = {"models": models, "messages": [{"role": "user", "content": prompt}]}
    status, payload = http("POST", f"{API}/chat/completions", key, body, timeout=timeout)
    if status != 200:
        return 1, "", explain(status, payload), ""
    choice = (payload.get("choices") or [{}])[0]
    text = ((choice.get("message") or {}).get("content") or "").strip()
    used = payload.get("model", "")
    if not text:
        return 1, "", "The free model returned no text; try again.", used
    return 0, text, "", used


def ask(prompt, key, models, http=_http):
    ""
    models = [m for m in models if m]
    if not models:
        return 1, "", "no free model chosen yet: run `thomas login --free`"
    err = ""
    while models:
        rc, text, err, used = _call(prompt, key, models, http)
        if rc == 0:
            return 0, text, ""
        if used not in models:  # a real error (no model named): retrying the same list would not help
            return 1, "", err
        models = [m for m in models if m != used]
    return 1, "", err


def selftest():
    cases = []

    def ck(n, got, want):
        cases.append((n, got == want, got))

    models = [
        {"id": "nvidia/nemotron-3-super-120b-a12b:free", "context_length": 262144},
        {"id": "big/model:free", "context_length": 1000000},
        {"id": "nvidia/nemotron-3.5-content-safety:free", "context_length": 2000000},
        {"id": "cohere/north-mini-code:free", "context_length": 3000000},
        {"id": "paid/model", "context_length": 9000000},
        {"id": "img/out:free", "context_length": 5000000, "architecture": {"output_modalities": ["image"]}},
        {"id": "small/one:free", "context_length": 65536},
    ]
    ck("pick-free-chat-by-context", pick_models(models),
       ["big/model:free", "nvidia/nemotron-3-super-120b-a12b:free", "small/one:free"])
    ck("pick-none", pick_models(models[2:6]), [])
    ck("explain-bad-key-is-plain", "openrouter.ai/keys" in explain(401, {"error": {"message": "No auth"}}), True)
    ck("explain-busy", "busy" in explain(429, {}), True)
    seen = []

    def fake(method, url, key, body=None, timeout=60):
        seen.append((method, url, key, body))
        if url.endswith("/key"):
            return 200, {"data": {"label": "x"}}
        if url.endswith("/models"):
            return 200, {"data": models}
        return 200, {"choices": [{"message": {"content": "hi there"}}]}

    ck("check-key-lists-models", check_key("K", say=lambda _l: None, http=fake)[0][0], "big/model:free")
    ck("ask-returns-text", ask("hello", "K", ["a:free", "b:free"], http=fake), (0, "hi there", ""))
    ck("ask-sends-fallback-list", seen[-1][3]["models"], ["a:free", "b:free"])
    ck("key-never-in-url", all("K" not in u for _m, u, _k, _b in seen), True)
    ck("bad-key-stops-before-models", check_key("K", say=lambda _l: None, http=lambda *a, **k: (401, {}))[0], [])

    def gated(method, url, key, body=None, timeout=60):  # the first model answers 200 with no text
        if url.endswith("/key"):
            return 200, {}
        if url.endswith("/models"):
            return 200, {"data": models}
        first = body["models"][0]
        if first == "big/model:free":
            return 200, {"model": first, "choices": [{"message": {"content": ""}}]}
        return 200, {"model": first, "choices": [{"message": {"content": "ok from " + first}}]}

    ck("login-keeps-only-models-that-answer", check_key("K", say=lambda _l: None, http=gated)[0],
       ["nvidia/nemotron-3-super-120b-a12b:free", "small/one:free"])
    ck("empty-reply-drops-that-model-and-retries",
       ask("q", "K", ["big/model:free", "small/one:free"], http=gated), (0, "ok from small/one:free", ""))
    ck("ask-error-plain", ask("x", "K", ["m"], http=lambda *a, **k: (429, {}))[0:2], (1, ""))
    policy = {"error": {"message": "No endpoints available matching your guardrail restrictions and data policy."}}
    ck("login-shows-the-real-probe-error-data-policy",
       "settings/privacy" in check_key("K", say=lambda _l: None, http=lambda m, u, *a, **k: (200, {"data": models}) if m == "GET"
                                          else (404, policy))[1], True)
    ck("402-points-at-credits-not-relogin", "openrouter.ai/credits" in explain(402, {}), True)
    ck("api-override-only-https-or-localhost",
       (api_base({"THOMAS_FREE_API": "http://evil.example/v1"}), api_base({"THOMAS_FREE_API": "http://127.0.0.1:9/v1"}),
        api_base({"THOMAS_FREE_API": "https://x.example/v1/"})),
       (DEFAULT_API, "http://127.0.0.1:9/v1", "https://x.example/v1"))
    import tempfile

    d = tempfile.mkdtemp()
    p = os.path.join(d, "k")
    save_key("abc", p)
    ck("save-key-0600-and-read", (oct(os.stat(p).st_mode & 0o777), read_key(p, env={})), ("0o600", "abc"))
    ck("env-key-wins", read_key(p, env={"OPENROUTER_API_KEY": "env"}), "env")
    bad = sum(not ok for _n, ok, _g in cases)
    for n, ok, got in cases:
        print(f"  {n:<44} {'PASS' if ok else 'FAIL'}" + ("" if ok else f"  got {got!r}"))
    print(f"\nthomas_free --selftest RESULT: {f'FAIL -- {bad} case(s)' if bad else f'PASS -- {len(cases)} cases'}")
    return 1 if bad else 0


if __name__ == "__main__":
    import sys

    sys.exit(selftest() if "--selftest" in sys.argv else 0)
