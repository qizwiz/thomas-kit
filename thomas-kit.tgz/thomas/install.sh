#!/bin/sh
# install.sh -- set up Thomas in this folder: a private Python venv, the brain adapter, then a health check.
set -e
here=$(cd "$(dirname "$0")" && pwd)
# the venv's tools and the entry scripts carry this path in a shebang, which cannot hold a space
case "$here" in *" "*) echo "Thomas cannot be installed in a folder whose path has a space: $here"; exit 1 ;; esac
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' \
  || { echo "Thomas needs Python 3.10 or newer."; exit 1; }
python3 -c 'import venv, ensurepip' 2>/dev/null \
  || { echo "Python's venv module is missing (on Debian/Ubuntu: sudo apt install python3-venv)."; exit 1; }
python3 -m venv "$here/.venv"
"$here/.venv/bin/pip" install -q -r "$here/requirements.txt"
# point the two entry scripts at the venv (python rewrites line 1, so no path character can corrupt it)
for s in thomas acp-probe; do
  "$here/.venv/bin/python3" -c 'import sys
path, line = sys.argv[1], sys.argv[2]
rest = open(path).read().split("\n", 1)[1]
open(path, "w").write(line + "\n" + rest)' "$here/$s" "#!$here/.venv/bin/python3"
  chmod +x "$here/$s"
done
if command -v node >/dev/null 2>&1 && [ "$(node -e 'process.stdout.write(process.versions.node.split(".")[0])')" -ge 22 ]; then
  if ! command -v claude-agent-acp >/dev/null 2>&1; then
    echo "Installing the Claude brain adapter with npm into npm's global folder (npm install -g). It took about"
    echo "3 minutes in our tests;"
    echo "npm's progress lines follow, so a quiet minute is the download, not a hang."
    # IPv4 first: npm can stall on idle IPv6 connections to the registry. Only the order changes; IPv6 still works.
    NODE_OPTIONS="--dns-result-order=ipv4first ${NODE_OPTIONS:-}" \
      npm install -g --loglevel=http @agentclientprotocol/claude-agent-acp || echo "  (npm install failed -- see 'thomas doctor' below)"
  fi
else
  echo "Node 22 or newer is needed for the Claude brain (nodejs.org, or: nvm install 22). Skipping the adapter."
fi
echo
"$here/thomas" doctor || true
echo
echo "Next: give your assistant a name with  $here/thomas persona set :name YourName"
echo "      log in to your brain (Claude: install Claude Code, then 'claude auth login'), then:"
echo "      $here/thomas ask \"hello\""
