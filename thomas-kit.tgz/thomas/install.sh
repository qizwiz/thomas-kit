#!/bin/sh
# install.sh -- set up Thomas in this folder: a private Python venv, the brain adapter, then a health check.
set -e
here=$(cd "$(dirname "$0")" && pwd)
# the venv's tools and the entry scripts carry this path in a shebang, which cannot hold a space
case "$here" in *" "*) echo "Thomas cannot be installed in a folder whose path has a space: $here"; exit 1 ;; esac
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' \
  || { echo "Thomas needs Python 3.10 or newer."; exit 1; }
python3 -c 'import venv, ensurepip' 2>/dev/null \
  || { echo "Python's venv module is missing (on Debian/Ubuntu: sudo apt install python3-venv)."; exit 1; }
python3 -m venv "$here/.venv"
"$here/.venv/bin/pip" install -q -r "$here/requirements.txt"
# point the two entry scripts at the venv (python rewrites line 1, so no path character can corrupt it)
for s in thomas acp-probe; do
  "$here/.venv/bin/python3" -c 'import sys
path, line = sys.argv[1], sys.argv[2]
rest = open(path).read().split("\n", 1)[1]
open(path, "w").write(line + "\n" + rest)' "$here/$s" "#!$here/.venv/bin/python3"
  chmod +x "$here/$s"
done
# NODE 22+ FOR THE CLAUDE BRAIN'S ADAPTER, WITH NO ADMIN RIGHTS AND NOTHING OUTSIDE THIS FOLDER. Node is fetched here
# because the adapter needs Node 22 and a new user rarely has it or the rights to install it. So: use the system Node if
# it is new enough, else
# fetch Node 22 into $here/node, checked against nodejs.org's published SHA-256 list; the adapter always goes into
# $here/adapter via `npm --prefix`, never -g. `thomas` puts both folders first on its own PATH.
if command -v sha256sum >/dev/null 2>&1; then sha() { sha256sum "$1" | cut -d' ' -f1; }
else sha() { shasum -a 256 "$1" | cut -d' ' -f1; }; fi
PATH="$here/adapter/node_modules/.bin:$here/node/bin:$PATH"; export PATH
node_ok() { command -v node >/dev/null 2>&1 && [ "$(node -e 'process.stdout.write(process.versions.node.split(".")[0])')" -ge 22 ]; }
if ! node_ok; then
  case "$(uname -s)" in Darwin) os=darwin ;; Linux) os=linux ;; *) os="" ;; esac
  case "$(uname -m)" in x86_64 | amd64) arch=x64 ;; arm64 | aarch64) arch=arm64 ;; *) arch="" ;; esac
  if [ -n "$os" ] && [ -n "$arch" ]; then
    echo "Fetching Node 22 into $here/node (no admin rights needed; a download of about 50 MB) ..."
    nd=$(mktemp -d)
    # set -e exits on a failed tar or mkdir below; the trap still removes the download folder
    trap 'rm -rf "$nd"' EXIT
    nbase=https://nodejs.org/dist/latest-v22.x
    line=""
    if curl -fsSL "$nbase/SHASUMS256.txt" -o "$nd/sums"; then
      line=$(grep -F -- "-$os-$arch.tar.gz" "$nd/sums" | head -1 || true)
    fi
    if [ -n "$line" ]; then
      want=${line%% *}
      file=${line##* }
      if curl -fsSL "$nbase/$file" -o "$nd/node.tgz" && [ "$(sha "$nd/node.tgz")" = "$want" ]; then
        rm -rf "$here/node"
        mkdir -p "$here/node"
        tar xzf "$nd/node.tgz" -C "$here/node" --strip-components 1
        # the shell cached the OLD node's location when node_ok first ran; without this the re-check below still
        # runs the system Node 18 and the adapter is silently skipped
        hash -r 2>/dev/null || true
      else
        echo "  (the Node download failed or did not match nodejs.org's checksum -- see 'thomas doctor' below)"
      fi
    else
      echo "  (could not read nodejs.org's checksum list -- see 'thomas doctor' below)"
    fi
    rm -rf "$nd"
    trap - EXIT
  else
    echo "No Node 22 build for $(uname -s) $(uname -m) here; install Node 22 or newer from nodejs.org."
  fi
fi
# the KIT's own adapter, not any adapter on the PATH: a global claude-agent-acp without its platform package carries
# no `claude` to sign in with, and skipping on it left login with no bundled binary.
# `thomas` puts this folder's adapter first on its PATH, so the kit's copy is the one used once it exists.
if node_ok && ! [ -x "$here/adapter/node_modules/.bin/claude-agent-acp" ]; then
  echo "Installing the Claude brain adapter into $here/adapter (no admin rights needed). This can take a few"
  echo "minutes; npm's progress lines follow, so a quiet minute is the download, not a hang."
  # IPv4 first: npm can stall on idle IPv6 connections to the registry. Only the order changes; IPv6 still works.
  NODE_OPTIONS="--dns-result-order=ipv4first ${NODE_OPTIONS:-}" \
    npm install --prefix "$here/adapter" --no-fund --no-audit --no-update-notifier --loglevel=http @agentclientprotocol/claude-agent-acp \
    || echo "  (npm install failed -- see 'thomas doctor' below)"
fi
echo
# --next: the Next lines come from the same checks doctor just printed, so a signed-in user is not told to sign in
"$here/thomas" doctor --next || true
